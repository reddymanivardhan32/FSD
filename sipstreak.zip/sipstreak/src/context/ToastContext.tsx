import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { apiRequest } from '../lib/api';
import { RankTransition, ReminderSettings } from '../types';
import { useAuth } from './AuthContext';

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  tone: 'info' | 'success' | 'warning' | 'error';
}

const NUDGE_MESSAGES = [
  'Hey HydroHero! Time to take a refreshing sip!',
  'Your squad is counting on you. Drink some water!',
  'Small sips, big streaks. Keep going!',
];

interface ToastContextValue {
  toasts: ToastMessage[];
  pushToast: (toast: Omit<ToastMessage, 'id'>) => void;
  dismissToast: (id: string) => void;
  celebration: RankTransition | null;
  triggerCelebration: (transition: RankTransition) => void;
  clearCelebration: () => void;
  reminderSettings: ReminderSettings | null;
  refreshReminders: () => Promise<void>;
  triggerHydrationNudge: (options?: { forceTest?: boolean; simulateHour?: number }) => Promise<{
    delivered: boolean;
    reason: string;
    channel: 'browser' | 'in-app' | 'suppressed';
  }>;
}

const ToastContext = createContext<ToastContextValue | null>(null);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [celebration, setCelebration] = useState<RankTransition | null>(null);
  const [reminderSettings, setReminderSettings] = useState<ReminderSettings | null>(null);
  const nudgeIdxRef = useRef(0);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const pushToast = useCallback(
    (toast: Omit<ToastMessage, 'id'>) => {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setToasts((prev) => [...prev.slice(-3), { ...toast, id }]);
      window.setTimeout(() => {
        dismissToast(id);
      }, 4500);
    },
    [dismissToast],
  );

  const triggerCelebration = useCallback((transition: RankTransition) => {
    if (transition.improved) {
      setCelebration(transition);
    }
  }, []);

  const clearCelebration = useCallback(() => {
    setCelebration(null);
  }, []);

  const refreshReminders = useCallback(async () => {
    if (!user) {
      setReminderSettings(null);
      return;
    }
    try {
      const res = await apiRequest<{ settings: ReminderSettings }>('/api/reminders');
      setReminderSettings(res.settings);
    } catch {
      // Ignore if unauthenticated
    }
  }, [user]);

  useEffect(() => {
    refreshReminders();
  }, [refreshReminders]);

  const triggerHydrationNudge = useCallback(
    async (options?: { forceTest?: boolean; simulateHour?: number }) => {
      const forceTest = Boolean(options?.forceTest);
      const settings = reminderSettings ?? {
        enabled: 1,
        startHour: 8,
        endHour: 21,
        intervalMinutes: 60,
        lastNotifiedAt: null,
      };

      const activeHour =
        typeof options?.simulateHour === 'number' ? options.simulateHour : new Date().getHours();

      if (!settings.enabled && !forceTest) {
        return {
          delivered: false,
          reason: 'Hourly reminders are currently paused in settings.',
          channel: 'suppressed' as const,
        };
      }

      if (!forceTest && (activeHour < settings.startHour || activeHour >= settings.endHour)) {
        return {
          delivered: false,
          reason: `Suppressed outside daytime hours (${String(settings.startHour).padStart(2, '0')}:00–${String(settings.endHour).padStart(2, '0')}:00).`,
          channel: 'suppressed' as const,
        };
      }

      try {
        const res = await apiRequest<{ suppressed: boolean; lastNotifiedAt: string }>(
          '/api/reminders/notified',
          {
            method: 'POST',
            body: JSON.stringify({ forceTest }),
          },
        );
        setReminderSettings((prev) =>
          prev ? { ...prev, lastNotifiedAt: res.lastNotifiedAt } : prev,
        );
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Suppressed duplicate reminder.';
        if (forceTest) {
          // forceTest should not fail here; fallback gracefully
        } else {
          return { delivered: false, reason: msg, channel: 'suppressed' as const };
        }
      }

      const message = NUDGE_MESSAGES[nudgeIdxRef.current % NUDGE_MESSAGES.length];
      nudgeIdxRef.current += 1;

      if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
        try {
          new Notification('SipStreak — HydroHero Hunt', {
            body: message,
          });
          pushToast({
            title: 'Hydration Nudge Sent',
            description: message,
            tone: 'info',
          });
          return {
            delivered: true,
            reason: 'Browser notification and in-app nudge delivered.',
            channel: 'browser' as const,
          };
        } catch {
          // Fallback to in-app toast below
        }
      }

      pushToast({
        title: 'Hydration Reminder',
        description: message,
        tone: 'info',
      });
      return {
        delivered: true,
        reason: 'Browser notifications unavailable or not granted; delivered in-app toast fallback.',
        channel: 'in-app' as const,
      };
    },
    [pushToast, reminderSettings],
  );

  // Active background interval check while tab is open
  useEffect(() => {
    if (!user || !reminderSettings || !reminderSettings.enabled) return;
    const intervalMs = Math.max(60_000, reminderSettings.intervalMinutes * 60_000);
    const id = window.setInterval(() => {
      triggerHydrationNudge({ forceTest: false });
    }, intervalMs);
    return () => window.clearInterval(id);
  }, [user, reminderSettings, triggerHydrationNudge]);

  return (
    <ToastContext.Provider
      value={{
        toasts,
        pushToast,
        dismissToast,
        celebration,
        triggerCelebration,
        clearCelebration,
        reminderSettings,
        refreshReminders,
        triggerHydrationNudge,
      }}
    >
      {children}
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) {
    throw new Error('useToast must be used inside ToastProvider');
  }
  return ctx;
}
