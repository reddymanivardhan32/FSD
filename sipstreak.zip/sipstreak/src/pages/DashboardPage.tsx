import React, { useCallback, useEffect, useState } from 'react';
import {
  Coffee,
  Droplets,
  Flame,
  Plus,
  Sprout,
  Trash2,
  Trophy,
  Zap,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { AppShell } from '../components/AppShell';
import { HydrationRing } from '../components/HydrationRing';
import { PlantIllustration } from '../components/PlantIllustration';
import { WaterBottleGraphic } from '../components/WaterBottleGraphic';
import { useToast } from '../context/ToastContext';
import { ApiError, apiRequest } from '../lib/api';
import { DashboardPayload, LeaderboardResponse, RankTransition } from '../types';

const DRINK_LABELS: Record<string, string> = {
  cup: 'Cup',
  bottle: 'Water Bottle',
  tumbler: 'Tumbler',
  custom: 'Custom Sip',
  qr_bottle: 'QR Bottle Scan',
};

export default function DashboardPage() {
  const { pushToast, triggerCelebration } = useToast();
  const [data, setData] = useState<DashboardPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isLogging, setIsLogging] = useState(false);
  const [customMl, setCustomMl] = useState('');
  const [customError, setCustomError] = useState<string | null>(null);
  const [rippleKey, setRippleKey] = useState(0);

  const loadDashboard = useCallback(async () => {
    try {
      const res = await apiRequest<DashboardPayload>('/api/hydration/dashboard');
      setData(res);
      setError(null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to load dashboard.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  const logWater = async (amountMl: number, drinkType: string) => {
    if (isLogging) return;
    setIsLogging(true);
    setCustomError(null);
    const clientRequestId = `web-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    try {
      const res = await apiRequest<{
        todayStats: DashboardPayload['todayStats'];
        streak: { currentStreak: number; longestStreak: number };
        squad: DashboardPayload['squad'];
        plant: DashboardPayload['plant'];
        achievements: DashboardPayload['achievements'];
        leaderboard: LeaderboardResponse;
        rankTransition: RankTransition | null;
      }>('/api/hydration/log', {
        method: 'POST',
        body: JSON.stringify({ amountMl, drinkType, clientRequestId }),
      });

      setRippleKey((k) => k + 1);
      setData((prev) =>
        prev
          ? {
              ...prev,
              todayStats: res.todayStats,
              streak: { ...prev.streak, ...res.streak },
              squad: res.squad,
              plant: res.plant,
              achievements: res.achievements,
            }
          : prev,
      );

      pushToast({
        title: `Logged +${amountMl} ml`,
        description: `Personal progress is now ${res.todayStats.completionPct}% (${res.todayStats.totalIntakeMl.toLocaleString()} ml).`,
        tone: 'success',
      });

      if (res.rankTransition?.improved) {
        triggerCelebration(res.rankTransition);
      }
    } catch (err) {
      pushToast({
        title: 'Could not log water',
        description: err instanceof ApiError ? err.message : 'Unexpected error',
        tone: 'error',
      });
    } finally {
      setIsLogging(false);
    }
  };

  const handleCustomSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = Number(customMl);
    if (!Number.isInteger(parsed) || parsed < 10 || parsed > 3000) {
      setCustomError('Enter a whole number between 10 ml and 3000 ml.');
      return;
    }
    setCustomMl('');
    await logWater(parsed, 'custom');
  };

  const handleDeleteLog = async (logId: string) => {
    try {
      await apiRequest(`/api/hydration/log/${logId}`, { method: 'DELETE' });
      await loadDashboard();
      pushToast({ title: 'Drink entry removed', tone: 'info' });
    } catch (err) {
      pushToast({
        title: 'Delete failed',
        description: err instanceof ApiError ? err.message : 'Could not delete entry',
        tone: 'error',
      });
    }
  };

  const handleLogCaffeine = async (beverageType: 'coffee' | 'energy_drink') => {
    try {
      const res = await apiRequest<{ todayStats: DashboardPayload['todayStats'] }>(
        '/api/hydration/caffeine',
        {
          method: 'POST',
          body: JSON.stringify({ beverageType }),
        },
      );
      setData((prev) => (prev ? { ...prev, todayStats: res.todayStats } : prev));
      pushToast({
        title: beverageType === 'coffee' ? 'Coffee logged (+200 ml offset)' : 'Energy drink logged (+200 ml offset)',
        description: 'Compensatory water target increased by 200 ml (not counted as plain water).',
        tone: 'warning',
      });
    } catch (err) {
      pushToast({
        title: 'Failed to log caffeine',
        description: err instanceof ApiError ? err.message : 'Unexpected error',
        tone: 'error',
      });
    }
  };

  const handleDeleteCaffeine = async (id: string) => {
    try {
      const res = await apiRequest<{ todayStats: DashboardPayload['todayStats'] }>(
        `/api/hydration/caffeine/${id}`,
        { method: 'DELETE' },
      );
      setData((prev) => (prev ? { ...prev, todayStats: res.todayStats } : prev));
    } catch (err) {
      pushToast({
        title: 'Delete failed',
        description: err instanceof ApiError ? err.message : 'Error',
        tone: 'error',
      });
    }
  };

  if (loading) {
    return (
      <AppShell title="Personal Dashboard" subtitle="Loading hydration telemetry...">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="h-96 animate-pulse rounded-2xl border border-slate-200 bg-white lg:col-span-8" />
          <div className="h-96 animate-pulse rounded-2xl border border-slate-200 bg-white lg:col-span-4" />
        </div>
      </AppShell>
    );
  }

  if (error || !data) {
    return (
      <AppShell title="Personal Dashboard">
        <div className="rounded-xl border border-red-200 bg-red-50 p-6 text-sm text-red-800">
          {error ?? 'Dashboard data unavailable.'}
        </div>
      </AppShell>
    );
  }

  const { user, todayStats, streak, squad, plant, achievements } = data;

  return (
    <AppShell
      title="Personal Dashboard"
      subtitle={`${user.name} · Daily base target ${todayStats.baseGoalMl.toLocaleString()} ml`}
      action={
        <button
          type="button"
          disabled={isLogging}
          onClick={() => logWater(500, 'bottle')}
          className="inline-flex items-center gap-1.5 rounded-lg bg-sky-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-sky-700 disabled:opacity-60 whitespace-nowrap shrink-0"
        >
          <Plus className="h-3.5 w-3.5" />
          +500 ml Water Bottle
        </button>
      }
    >
      {/* Primary Hydration Hero Workspace */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-8">
          <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900">Today’s Hydration Progress</h2>
              <p className="mt-0.5 text-xs text-slate-500">
                General tracking estimate ({user.weightKg} kg × 35 ml = {todayStats.baseGoalMl.toLocaleString()} ml),
                not a medical prescription.
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs font-medium text-slate-600 tabular-nums">
              <span className="inline-flex items-center gap-1">
                <Flame className="h-4 w-4 text-amber-500" />
                {streak.currentStreak}-day streak
              </span>
              {todayStats.rawPct > 100 && (
                <span className="font-mono text-emerald-700">Raw intake: {todayStats.rawPct}%</span>
              )}
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 items-center gap-8 md:grid-cols-2">
            <HydrationRing
              percentage={todayStats.completionPct}
              intakeMl={todayStats.totalIntakeMl}
              targetMl={todayStats.baseGoalMl}
              remainingMl={todayStats.remainingBaseMl}
            />
            <WaterBottleGraphic
              percentage={todayStats.completionPct}
              intakeMl={todayStats.totalIntakeMl}
              targetMl={todayStats.baseGoalMl}
              rippleKey={rippleKey}
            />
          </div>

          {/* Quick-Tap Water Logging Controls */}
          <div className="mt-8 border-t border-slate-100 pt-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Quick-Tap Water Logging
              </h3>
              <span className="text-xs text-slate-400">Saves immediately to SQLite</span>
            </div>

            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <button
                type="button"
                disabled={isLogging}
                onClick={() => logWater(250, 'cup')}
                className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-left hover:border-sky-300 hover:bg-sky-50/60 transition-colors disabled:opacity-60"
              >
                <div>
                  <div className="font-display text-sm font-bold text-slate-900 tabular-nums">+250 ml</div>
                  <div className="text-xs text-slate-600">Cup</div>
                </div>
                <Droplets className="h-4 w-4 text-sky-600" />
              </button>

              <button
                type="button"
                disabled={isLogging}
                onClick={() => logWater(500, 'bottle')}
                className="flex items-center justify-between rounded-xl border border-sky-300 bg-sky-50 px-4 py-3 text-left hover:bg-sky-100/70 transition-colors disabled:opacity-60"
              >
                <div>
                  <div className="font-display text-sm font-bold text-sky-950 tabular-nums">+500 ml</div>
                  <div className="text-xs text-sky-800">Water Bottle</div>
                </div>
                <Droplets className="h-4 w-4 text-sky-600" />
              </button>

              <button
                type="button"
                disabled={isLogging}
                onClick={() => logWater(750, 'tumbler')}
                className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-left hover:border-sky-300 hover:bg-sky-50/60 transition-colors disabled:opacity-60"
              >
                <div>
                  <div className="font-display text-sm font-bold text-slate-900 tabular-nums">+750 ml</div>
                  <div className="text-xs text-slate-600">Tumbler</div>
                </div>
                <Droplets className="h-4 w-4 text-sky-600" />
              </button>
            </div>

            <form onSubmit={handleCustomSubmit} className="mt-4 flex flex-wrap items-start gap-3">
              <div className="flex-1 min-w-[180px]">
                <label htmlFor="custom-ml" className="sr-only">
                  Custom water amount in millilitres
                </label>
                <input
                  id="custom-ml"
                  type="number"
                  min={10}
                  max={3000}
                  step={1}
                  value={customMl}
                  onChange={(e) => {
                    setCustomMl(e.target.value);
                    setCustomError(null);
                  }}
                  placeholder="Custom amount in ml (10–3000)"
                  className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm text-slate-900 tabular-nums focus:border-sky-600 focus:outline-none"
                />
                {customError && <p className="mt-1 text-xs text-red-600">{customError}</p>}
              </div>
              <button
                type="submit"
                disabled={isLogging}
                className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-60 whitespace-nowrap"
              >
                Log Custom Amount
              </button>
            </form>
          </div>
        </section>

        {/* Right Column: Squad Snapshot + Caffeine Offset + Mini Plant */}
        <div className="space-y-6 lg:col-span-4">
          {/* Squad Card */}
          <section className="rounded-2xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-base font-bold text-slate-900">Hydration Squad</h2>
              <Trophy className="h-4 w-4 text-sky-600" />
            </div>
            {squad ? (
              <div className="mt-3">
                <div className="flex items-baseline justify-between">
                  <span className="font-display text-lg font-bold text-slate-900">{squad.teamName}</span>
                  <span className="font-mono text-xs font-semibold text-sky-700 tabular-nums">
                    {squad.rank ? `Rank #${squad.rank}` : 'Forming (<4)'}
                  </span>
                </div>
                <div className="mt-2 flex items-baseline justify-between text-xs text-slate-600 tabular-nums">
                  <span>Fair Squad Score: {squad.teamScore}%</span>
                  <span>{squad.memberCount}/8 members</span>
                </div>
                <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full bg-sky-600 transition-all duration-300"
                    style={{ width: `${Math.min(squad.teamScore, 100)}%` }}
                  />
                </div>
                <div className="mt-4 flex items-center gap-3">
                  <Link
                    to="/squad"
                    className="flex-1 rounded-lg border border-slate-200 px-3 py-2 text-center text-xs font-semibold text-slate-700 hover:bg-slate-50"
                  >
                    Squad Dashboard
                  </Link>
                  <Link
                    to="/leaderboard"
                    className="flex-1 rounded-lg bg-slate-900 px-3 py-2 text-center text-xs font-semibold text-white hover:bg-slate-800"
                  >
                    Leaderboard
                  </Link>
                </div>
              </div>
            ) : (
              <div className="mt-3">
                <p className="text-xs text-slate-600">
                  You are not in a hydration squad yet. Join via invite code or start a squad of 4–8 members.
                </p>
                <Link
                  to="/squad"
                  className="mt-3 inline-block rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800"
                >
                  Join or Create Squad
                </Link>
              </div>
            )}
          </section>

          {/* Caffeine Dehydration Offset Calculator */}
          <section className="rounded-2xl border border-slate-200 bg-white p-5">
            <h2 className="font-display text-base font-bold text-slate-900">
              Caffeine Offset Calculator
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              Coffee & energy drinks add +200 ml compensatory water demand and never count as plain water intake.
            </p>

            <div className="mt-3 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleLogCaffeine('coffee')}
                className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-amber-50 hover:border-amber-200"
              >
                <Coffee className="h-3.5 w-3.5 text-amber-700" />
                + Coffee
              </button>
              <button
                type="button"
                onClick={() => handleLogCaffeine('energy_drink')}
                className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-amber-50 hover:border-amber-200"
              >
                <Zap className="h-3.5 w-3.5 text-amber-700" />
                + Energy Drink
              </button>
            </div>

            <dl className="mt-4 space-y-1.5 border-t border-slate-100 pt-3 text-xs tabular-nums">
              <div className="flex justify-between">
                <dt className="text-slate-500">Caffeinated drinks today</dt>
                <dd className="font-semibold text-slate-900">{todayStats.caffeineCount}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-500">Compensatory offset</dt>
                <dd className="font-semibold text-amber-700">+{todayStats.caffeineOffsetMl} ml</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-500">Adjusted daily requirement</dt>
                <dd className="font-semibold text-slate-900">{todayStats.adjustedGoalMl.toLocaleString()} ml</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-500">Remaining (adjusted)</dt>
                <dd className="font-semibold text-sky-700">{todayStats.remainingAdjustedMl.toLocaleString()} ml</dd>
              </div>
            </dl>

            {todayStats.todayCaffeineLogs.length > 0 && (
              <div className="mt-3 space-y-1 border-t border-slate-100 pt-2">
                {todayStats.todayCaffeineLogs.map((c) => (
                  <div key={c.id} className="flex items-center justify-between text-xs text-slate-600">
                    <span>
                      {c.beverageType === 'coffee' ? 'Coffee' : 'Energy Drink'} (+200 ml) ·{' '}
                      {new Date(c.timestampUtc).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleDeleteCaffeine(c.id)}
                      aria-label="Remove caffeine entry"
                      className="rounded p-1 text-slate-400 hover:text-red-600"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Mini Virtual Plant Companion */}
          <section className="rounded-2xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-display text-base font-bold text-slate-900">Plant Companion</h2>
                <p className="text-xs text-slate-500">
                  {plant.title} · {plant.healthLabel}
                </p>
              </div>
              <Sprout className="h-4 w-4 text-emerald-600" />
            </div>
            <div className="mt-2 flex items-center gap-4">
              <PlantIllustration plant={plant} size="sm" />
              <div className="flex-1 text-xs text-slate-600">
                <p>{plant.statusMessage}</p>
                <Link
                  to="/plant"
                  className="mt-2 inline-block font-semibold text-sky-700 hover:text-sky-800"
                >
                  Open Plant View →
                </Link>
              </div>
            </div>
          </section>
        </div>
      </div>

      {/* Bottom Row: Today's Drink Log & Achievements */}
      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-12">
        <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-8">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h2 className="font-display text-base font-bold text-slate-900">Today’s Water Log</h2>
            <span className="text-xs text-slate-500 tabular-nums">
              {todayStats.todayLogs.length} entries · {todayStats.totalIntakeMl.toLocaleString()} ml total
            </span>
          </div>

          {todayStats.todayLogs.length === 0 ? (
            <div className="py-10 text-center text-sm text-slate-500">
              No water logged today yet. Tap +250 ml, +500 ml, or +750 ml above to start.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {todayStats.todayLogs.map((entry) => (
                <div key={entry.id} className="flex items-center justify-between py-3 text-sm">
                  <div className="flex items-center gap-3">
                    <Droplets className="h-4 w-4 text-sky-600 shrink-0" />
                    <div>
                      <div className="font-medium text-slate-900">
                        {DRINK_LABELS[entry.drinkType] ?? 'Water Log'}
                      </div>
                      <div className="text-xs text-slate-500 tabular-nums">
                        {new Date(entry.timestampUtc).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-sm font-semibold text-slate-900 tabular-nums">
                      +{entry.amountMl} ml
                    </span>
                    <button
                      type="button"
                      onClick={() => handleDeleteLog(entry.id)}
                      aria-label={`Delete ${entry.amountMl} ml entry`}
                      className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-red-600"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-4">
          <h2 className="font-display text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
            Unlocked Milestones
          </h2>
          {achievements.length === 0 ? (
            <p className="mt-4 text-xs text-slate-500">
              Log your first drink or reach 100% of your daily target to unlock milestones.
            </p>
          ) : (
            <div className="mt-3 space-y-3">
              {achievements.map((a) => (
                <div key={a.id} className="rounded-xl border border-slate-100 bg-slate-50 p-3">
                  <div className="text-xs font-semibold text-slate-900">{a.title}</div>
                  <div className="mt-0.5 text-xs text-slate-600">{a.description}</div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </AppShell>
  );
}
