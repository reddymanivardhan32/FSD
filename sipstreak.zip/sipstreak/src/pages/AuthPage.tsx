import React, { useMemo, useState } from 'react';
import { ArrowRight, Droplets } from 'lucide-react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ApiError } from '../lib/api';

const DEMO_ACCOUNTS = [
  {
    name: 'Rohan Verma',
    team: 'Hostel Block B (Presenter Demo · Rank #2)',
    email: 'rohan@sipstreak.edu',
  },
  {
    name: 'Aarav Mehta',
    team: 'Hostel Block A (Rank #1)',
    email: 'aarav@sipstreak.edu',
  },
  {
    name: 'Vikram Patel',
    team: 'Aqua Knights (Rank #3)',
    email: 'vikram@sipstreak.edu',
  },
  {
    name: 'Arjun Reddy',
    team: 'Hydration Homies (Rank #4)',
    email: 'arjun@sipstreak.edu',
  },
];

export default function AuthPage() {
  const [searchParams] = useSearchParams();
  const initialMode = searchParams.get('mode') === 'register' ? 'register' : 'login';
  const redirectTarget = searchParams.get('redirect') || '/dashboard';

  const { login, register, demoLogin } = useAuth();
  const navigate = useNavigate();

  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [weightKg, setWeightKg] = useState('60');
  const [inviteCode, setInviteCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const previewTargetMl = useMemo(() => {
    const w = Number(weightKg);
    if (!Number.isFinite(w) || w < 25 || w > 250) return null;
    return Math.round(w * 35);
  }, [weightKg]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      if (mode === 'login') {
        await login(email, password);
      } else {
        await register({
          name,
          email,
          password,
          weightKg: Number(weightKg),
          inviteCode: inviteCode.trim() || undefined,
        });
      }
      navigate(redirectTarget, { replace: true });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Unable to complete authentication.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDemoAccount = async (demoEmail: string) => {
    setError(null);
    setSubmitting(true);
    try {
      await demoLogin(demoEmail);
      navigate(redirectTarget === '/dashboard' && demoEmail === 'rohan@sipstreak.edu' ? '/squad' : redirectTarget, {
        replace: true,
      });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Demo login failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 px-4 py-10 sm:px-8">
      <div className="mx-auto max-w-5xl">
        <div className="mb-8 flex items-center justify-between">
          <Link to="/" className="inline-flex items-center gap-2 font-display text-lg font-bold text-slate-900">
            <Droplets className="h-5 w-5 text-sky-600" />
            SipStreak
          </Link>
          <Link to="/" className="text-sm font-medium text-slate-600 hover:text-slate-900">
            Back to Overview
          </Link>
        </div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 items-start">
          {/* Login / Registration Card */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 lg:col-span-7">
            <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError(null);
                }}
                className={`flex-1 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                  mode === 'login' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setError(null);
                }}
                className={`flex-1 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                  mode === 'register' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Create Account
              </button>
            </div>

            <h1 className="mt-6 font-display text-2xl font-bold text-slate-900">
              {mode === 'login' ? 'Welcome back, HydroHero' : 'Create your HydroHero profile'}
            </h1>
            <p className="mt-1 text-sm text-slate-600">
              {mode === 'login'
                ? 'Sign in to log water intake, check your squad rank, and keep your streak alive.'
                : 'Your personalized daily hydration target is calculated using Weight (kg) × 35 ml.'}
            </p>

            {error && (
              <div
                role="alert"
                className="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
              >
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              {mode === 'register' && (
                <div>
                  <label htmlFor="auth-name" className="block text-xs font-semibold text-slate-700">
                    Full Name
                  </label>
                  <input
                    id="auth-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g., Maya Lin"
                    className="mt-1.5 w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-sky-600 focus:outline-none"
                  />
                </div>
              )}

              <div>
                <label htmlFor="auth-email" className="block text-xs font-semibold text-slate-700">
                  Campus or Work Email
                </label>
                <input
                  id="auth-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@sipstreak.edu"
                  className="mt-1.5 w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-sky-600 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="auth-password" className="block text-xs font-semibold text-slate-700">
                  Password
                </label>
                <input
                  id="auth-password"
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 6 characters"
                  className="mt-1.5 w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-sky-600 focus:outline-none"
                />
              </div>

              {mode === 'register' && (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label htmlFor="auth-weight" className="block text-xs font-semibold text-slate-700">
                      Body Weight (kg)
                    </label>
                    <input
                      id="auth-weight"
                      type="number"
                      required
                      min={25}
                      max={250}
                      step="0.5"
                      value={weightKg}
                      onChange={(e) => setWeightKg(e.target.value)}
                      className="mt-1.5 w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 tabular-nums focus:border-sky-600 focus:outline-none"
                    />
                    {previewTargetMl !== null && (
                      <p className="mt-1 text-xs text-sky-700 tabular-nums">
                        Estimated target: {previewTargetMl.toLocaleString()} ml/day
                      </p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="auth-invite" className="block text-xs font-semibold text-slate-700">
                      Squad Invite Code (Optional)
                    </label>
                    <input
                      id="auth-invite"
                      type="text"
                      value={inviteCode}
                      onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
                      placeholder="e.g., HBLB26"
                      className="mt-1.5 w-full rounded-lg border border-slate-300 px-3.5 py-2.5 font-mono text-sm uppercase text-slate-900 focus:border-sky-600 focus:outline-none"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-60"
              >
                {submitting
                  ? 'Please wait...'
                  : mode === 'login'
                    ? 'Sign In to SipStreak'
                    : 'Create HydroHero Account'}
                <ArrowRight className="h-4 w-4" />
              </button>
            </form>
          </div>

          {/* Instant Demo Panel */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-5">
            <h2 className="font-display text-lg font-bold text-slate-900">
              Instant Demo Accounts
            </h2>
            <p className="mt-1 text-xs text-slate-600 leading-relaxed">
              Evaluators can jump straight into any seeded squad without registering. Password for all
              demo accounts: <code className="font-mono font-semibold text-slate-900">HydroHero2026!</code>
            </p>

            <div className="mt-5 space-y-2.5">
              {DEMO_ACCOUNTS.map((acct, index) => (
                <button
                  key={acct.email}
                  type="button"
                  disabled={submitting}
                  onClick={() => handleDemoAccount(acct.email)}
                  className={`flex w-full items-center justify-between rounded-xl border px-4 py-3 text-left transition-colors ${
                    index === 0
                      ? 'border-sky-200 bg-sky-50/70 hover:bg-sky-50'
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/70'
                  }`}
                >
                  <div className="min-w-0 pr-3">
                    <div className="text-sm font-semibold text-slate-900 truncate">{acct.name}</div>
                    <div className="text-xs text-slate-600 truncate">{acct.team}</div>
                    <div className="mt-0.5 font-mono text-[11px] text-slate-500 truncate">{acct.email}</div>
                  </div>
                  <ArrowRight className="h-4 w-4 shrink-0 text-sky-700" />
                </button>
              ))}
            </div>

            <div className="mt-5 border-t border-slate-200 pt-4 text-xs text-slate-500 leading-relaxed">
              Target estimate formula (<span className="font-mono">WeightKg × 35 ml</span>) is a general
              hydration tracking guide, not a medical prescription.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
