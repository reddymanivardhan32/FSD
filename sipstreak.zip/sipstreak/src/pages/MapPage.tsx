import React, { useEffect, useMemo, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { ExternalLink, MapPin, Search } from 'lucide-react';
import { MapContainer, Marker, Popup, TileLayer, useMap } from 'react-leaflet';
import { Link } from 'react-router-dom';
import { AppShell } from '../components/AppShell';
import { useAuth } from '../context/AuthContext';
import { apiRequest } from '../lib/api';
import { FountainLocation } from '../types';

function createFountainIcon(active: boolean, selected: boolean) {
  const color = !active ? '#D97706' : selected ? '#0B1F3A' : '#0284C7';
  const size = selected ? 30 : 24;
  return L.divIcon({
    className: 'custom-fountain-marker',
    html: `<div style="width:${size}px;height:${size}px;border-radius:9999px;background:${color};border:3px solid #ffffff;box-shadow:0 2px 6px rgba(15,23,42,0.35);"></div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -14],
  });
}

function MapFocusController({ center }: { center: [number, number] | null }) {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.flyTo(center, 17, { duration: 0.5 });
    }
  }, [center, map]);
  return null;
}

const WATER_TYPE_LABELS: Record<string, string> = {
  chilled_filtered: 'Chilled & Filtered',
  bottle_refill: 'Bottle Refill',
  standard: 'Standard Tap',
};

export default function MapPage() {
  const { user } = useAuth();
  const [fountains, setFountains] = useState<FountainLocation[]>([]);
  const [datasetNotice, setDatasetNotice] = useState('');
  const [search, setSearch] = useState('');
  const [waterType, setWaterType] = useState('all');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const params = new URLSearchParams();
    if (search.trim()) params.set('q', search.trim());
    if (waterType !== 'all') params.set('waterType', waterType);

    apiRequest<{ datasetNotice: string; fountains: FountainLocation[] }>(
      `/api/fountains?${params.toString()}`,
    )
      .then((res) => {
        setFountains(res.fountains);
        setDatasetNotice(res.datasetNotice);
      })
      .finally(() => setLoading(false));
  }, [search, waterType]);

  const selectedFountain = useMemo(
    () => fountains.find((f) => f.id === selectedId) ?? null,
    [fountains, selectedId],
  );

  const mapCenter: [number, number] = [37.4275, -122.1697];

  const body = (
    <div className="space-y-5">
      {/* Sample Dataset Transparency Banner */}
      <div className="rounded-xl border border-sky-200 bg-sky-50/70 px-4 py-3 text-xs text-sky-950">
        <strong className="font-semibold">Demonstration Campus Dataset:</strong>{' '}
        {datasetNotice ||
          'Sample refill station coordinates displayed for hackathon demonstration until independently verified on campus.'}
      </div>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search fountain name, building, or floor..."
            className="w-full rounded-lg border border-slate-300 py-2 pl-9 pr-3 text-sm text-slate-900 focus:border-sky-600 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1 overflow-x-auto">
          {[
            { value: 'all', label: 'All' },
            { value: 'chilled_filtered', label: 'Chilled & Filtered' },
            { value: 'bottle_refill', label: 'Bottle Refill' },
            { value: 'standard', label: 'Standard' },
          ].map((opt) => (
            <button
              key={opt.value}
              type="button"
              onClick={() => setWaterType(opt.value)}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                waterType === opt.value
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Interactive Leaflet Map */}
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white lg:col-span-8 h-[460px]">
          <MapContainer
            center={mapCenter}
            zoom={15}
            scrollWheelZoom={true}
            className="h-full w-full z-0"
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <MapFocusController
              center={
                selectedFountain
                  ? [selectedFountain.latitude, selectedFountain.longitude]
                  : null
              }
            />
            {fountains.map((fountain) => (
              <Marker
                key={fountain.id}
                position={[fountain.latitude, fountain.longitude]}
                icon={createFountainIcon(
                  fountain.status === 'sample_active',
                  selectedId === fountain.id,
                )}
                eventHandlers={{
                  click: () => setSelectedId(fountain.id),
                }}
              >
                <Popup>
                  <div className="min-w-[200px] space-y-1.5 text-xs">
                    <div className="font-bold text-slate-900">{fountain.name}</div>
                    <div className="text-slate-600">
                      {fountain.building} · {fountain.floor}
                    </div>
                    <div className="text-slate-700">
                      Type: {WATER_TYPE_LABELS[fountain.waterType] ?? fountain.waterType}
                    </div>
                    <div className="text-slate-600">{fountain.notes}</div>
                    <div className="pt-1 text-[11px] font-medium text-sky-700">
                      Sample dataset ·{' '}
                      {fountain.status === 'sample_active'
                        ? 'Operational (Sample)'
                        : 'Maintenance (Sample)'}
                    </div>
                    <a
                      href={`https://www.openstreetmap.org/directions?to=${fountain.latitude},${fountain.longitude}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-1 inline-flex items-center gap-1 font-semibold text-sky-700 hover:underline"
                    >
                      Open Directions
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>

        {/* Fountain Directory List */}
        <div className="rounded-2xl border border-slate-200 bg-white lg:col-span-4 flex flex-col max-h-[460px]">
          <div className="border-b border-slate-200 px-5 py-3.5 flex items-center justify-between">
            <h2 className="font-display text-sm font-bold text-slate-900">
              Sample Stations ({fountains.length})
            </h2>
            <MapPin className="h-4 w-4 text-sky-600" />
          </div>

          <div className="flex-1 divide-y divide-slate-100 overflow-y-auto">
            {loading ? (
              <div className="p-6 text-xs text-slate-500">Loading station directory...</div>
            ) : fountains.length === 0 ? (
              <div className="p-6 text-xs text-slate-500">
                No refill stations matched your current filter.
              </div>
            ) : (
              fountains.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setSelectedId(f.id)}
                  className={`w-full px-5 py-3.5 text-left transition-colors hover:bg-slate-50 ${
                    selectedId === f.id ? 'bg-sky-50/70' : ''
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="font-semibold text-sm text-slate-900">{f.name}</div>
                  </div>
                  <div className="mt-0.5 text-xs text-slate-600">
                    {f.building} · {f.floor}
                  </div>
                  <div className="mt-1 flex items-center justify-between text-[11px]">
                    <span className="text-sky-700 font-medium">
                      {WATER_TYPE_LABELS[f.waterType] ?? f.waterType}
                    </span>
                    <span
                      className={
                        f.status === 'sample_active' ? 'text-emerald-700' : 'text-amber-700'
                      }
                    >
                      {f.status === 'sample_active' ? 'Active (Sample)' : 'Maintenance (Sample)'}
                    </span>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );

  if (user) {
    return (
      <AppShell
        title="Campus Water Fountain Map"
        subtitle="Locate clean drinking water refill stations across campus (sample demonstration data)"
      >
        {body}
      </AppShell>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-4 sm:px-8">
          <Link to="/" className="font-display text-lg font-bold text-slate-900 whitespace-nowrap">
            SipStreak
          </Link>
          <div className="flex items-center gap-4">
            <Link to="/leaderboard" className="text-sm font-medium text-slate-600 hover:text-slate-900">
              Leaderboard
            </Link>
            <Link
              to="/auth"
              className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 whitespace-nowrap"
            >
              Sign In
            </Link>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-8">
        <h1 className="mb-5 font-display text-2xl font-bold text-slate-900">
          Campus Water Fountain Map
        </h1>
        {body}
      </main>
    </div>
  );
}
