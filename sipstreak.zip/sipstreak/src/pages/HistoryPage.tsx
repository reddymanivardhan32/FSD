import React, { useEffect, useState } from 'react';
import {
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Legend,
  LinearScale,
  Title,
  Tooltip,
} from 'chart.js';
import { Flame } from 'lucide-react';
import { Bar } from 'react-chartjs-2';
import { AppShell } from '../components/AppShell';
import { ApiError, apiRequest } from '../lib/api';
import { HistoryPayload } from '../types';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

export default function HistoryPage() {
  const [history, setHistory] = useState<HistoryPayload | null>(null);
  const [view, setView] = useState<'personal' | 'team'>('personal');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiRequest<HistoryPayload>('/api/hydration/history')
      .then((res) => {
        setHistory(res);
        setError(null);
      })
      .catch((err) => {
        setError(err instanceof ApiError ? err.message : 'Could not load 7-day history.');
      })
      .finally(() => setLoading(false));
  }, []);

  const formatShortDate = (dateStr: string) => {
    const [y, m, d] = dateStr.split('-').map(Number);
    return new Date(Date.UTC(y, m - 1, d, 12)).toLocaleDateString(undefined, {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });
  };

  if (loading) {
    return (
      <AppShell title="7-Day Hydration History" subtitle="Loading weekly SQLite history...">
        <div className="h-96 animate-pulse rounded-2xl border border-slate-200 bg-white" />
      </AppShell>
    );
  }

  if (error || !history) {
    return (
      <AppShell title="7-Day Hydration History">
        <div className="rounded-xl border border-red-200 bg-red-50 p-6 text-sm text-red-800">
          {error ?? 'No history available.'}
        </div>
      </AppShell>
    );
  }

  const { personal, squad } = history;
  const activeSquadHistory = squad?.history ?? [];
  const teamWeeklyAvgPct =
    activeSquadHistory.length > 0
      ? Math.round(activeSquadHistory.reduce((s, d) => s + d.teamScore, 0) / activeSquadHistory.length)
      : 0;

  const personalChartData = {
    labels: personal.days.map((d) => formatShortDate(d.date)),
    datasets: [
      {
        label: 'Water Consumed (ml)',
        data: personal.days.map((d) => d.intakeMl),
        backgroundColor: personal.days.map((d) => (d.metGoal ? '#059669' : '#0284C7')),
        borderRadius: 6,
      },
      {
        label: 'Daily Goal (ml)',
        data: personal.days.map((d) => d.goalMl),
        backgroundColor: '#CBD5E1',
        borderRadius: 6,
      },
    ],
  };

  const teamChartData = {
    labels: activeSquadHistory.map((d) => formatShortDate(d.date)),
    datasets: [
      {
        label: 'Fair Squad Score (%)',
        data: activeSquadHistory.map((d) => d.teamScore),
        backgroundColor: '#0284C7',
        borderRadius: 6,
      },
    ],
  };

  return (
    <AppShell
      title="7-Day Hydration History"
      subtitle="Personal and squad trends computed directly from persisted local-timezone records"
      action={
        <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setView('personal')}
            className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
              view === 'personal' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Personal History
          </button>
          <button
            type="button"
            onClick={() => setView('team')}
            className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
              view === 'team' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Team History
          </button>
        </div>
      }
    >
      {/* Weekly Metrics */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">
            {view === 'personal' ? 'Active Personal Streak' : 'Squad Streak (≥70%)'}
          </div>
          <div className="mt-1 flex items-center gap-2 font-display text-3xl font-extrabold text-slate-900 tabular-nums">
            <Flame className="h-6 w-6 text-amber-500" />
            {view === 'personal' ? `${personal.currentStreak} days` : `${squad?.teamStreak ?? 0} days`}
          </div>
          <div className="mt-1 text-xs text-slate-500 tabular-nums">
            {view === 'personal'
              ? `Longest recorded: ${personal.longestStreak} days`
              : squad
                ? squad.teamName
                : 'No squad joined'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">7-Day Average Completion</div>
          <div className="mt-1 font-display text-3xl font-extrabold text-sky-700 tabular-nums">
            {view === 'personal' ? `${personal.weeklyAvgPct}%` : `${teamWeeklyAvgPct}%`}
          </div>
          <div className="mt-1 text-xs text-slate-500">
            Across the past 7 local calendar days
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">7-Day Cumulative Volume</div>
          <div className="mt-1 font-display text-3xl font-extrabold text-slate-900 tabular-nums">
            {view === 'personal'
              ? `${(personal.weeklyTotalMl / 1000).toFixed(1)} L`
              : `${(activeSquadHistory.reduce((s, d) => s + d.totalIntakeMl, 0) / 1000).toFixed(1)} L`}
          </div>
          <div className="mt-1 text-xs text-slate-500 tabular-nums">
            {view === 'personal'
              ? `${personal.weeklyTotalMl.toLocaleString()} ml consumed`
              : 'Combined squad water intake'}
          </div>
        </div>
      </div>

      {/* Chart.js Visualization */}
      <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-6">
        <h2 className="font-display text-lg font-bold text-slate-900">
          {view === 'personal'
            ? 'Daily Water Intake vs. Personal Goal (ml)'
            : `${squad?.teamName ?? 'Squad'} Daily Fair-Participation Score (%)`}
        </h2>

        {view === 'team' && !squad ? (
          <div className="py-12 text-center text-sm text-slate-500">
            Join or create a squad to view 7-day team hydration history.
          </div>
        ) : (
          <div className="mt-4 h-80">
            <Bar
              data={view === 'personal' ? personalChartData : teamChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { position: 'top' },
                  tooltip: {
                    callbacks: {
                      afterBody: (items) => {
                        if (view === 'personal' && items[0]) {
                          const day = personal.days[items[0].dataIndex];
                          return `Completion: ${day.percentage}% (${day.rawPercentage}% raw)`;
                        }
                        if (view === 'team' && items[0]) {
                          const day = activeSquadHistory[items[0].dataIndex];
                          return `Collective intake: ${day.totalIntakeMl.toLocaleString()} ml`;
                        }
                        return '';
                      },
                    },
                  },
                },
                scales: {
                  y: {
                    beginAtZero: true,
                    max: view === 'team' ? 100 : undefined,
                  },
                },
              }}
            />
          </div>
        )}
      </section>

      {/* Daily Breakdown Table */}
      <section className="mt-6 rounded-2xl border border-slate-200 bg-white overflow-hidden">
        <div className="border-b border-slate-200 px-6 py-4">
          <h3 className="font-display text-base font-bold text-slate-900">Daily Breakdown</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
              <tr>
                <th className="px-6 py-3">Local Calendar Day</th>
                <th className="px-6 py-3 text-right">Intake (ml)</th>
                <th className="px-6 py-3 text-right">
                  {view === 'personal' ? 'Daily Target (ml)' : 'Fair Score (%)'}
                </th>
                <th className="px-6 py-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 tabular-nums">
              {view === 'personal'
                ? personal.days.map((d) => (
                    <tr key={d.date} className="hover:bg-slate-50/70">
                      <td className="px-6 py-3 font-medium text-slate-900">
                        {formatShortDate(d.date)} <span className="text-xs text-slate-400">({d.date})</span>
                      </td>
                      <td className="px-6 py-3 text-right font-mono">{d.intakeMl.toLocaleString()} ml</td>
                      <td className="px-6 py-3 text-right font-mono">{d.goalMl.toLocaleString()} ml</td>
                      <td className="px-6 py-3 text-right">
                        <span className={d.metGoal ? 'font-semibold text-emerald-700' : 'text-slate-600'}>
                          {d.percentage}% {d.metGoal ? '· Goal Met' : ''}
                        </span>
                      </td>
                    </tr>
                  ))
                : activeSquadHistory.map((d) => (
                    <tr key={d.date} className="hover:bg-slate-50/70">
                      <td className="px-6 py-3 font-medium text-slate-900">
                        {formatShortDate(d.date)} <span className="text-xs text-slate-400">({d.date})</span>
                      </td>
                      <td className="px-6 py-3 text-right font-mono">{d.totalIntakeMl.toLocaleString()} ml</td>
                      <td className="px-6 py-3 text-right font-mono">{d.teamScore}%</td>
                      <td className="px-6 py-3 text-right">
                        <span className={d.teamScore >= 70 ? 'font-semibold text-emerald-700' : 'text-slate-600'}>
                          {d.teamScore >= 70 ? 'Strong Squad Day' : 'Building'}
                        </span>
                      </td>
                    </tr>
                  ))}
            </tbody>
          </table>
        </div>
      </section>
    </AppShell>
  );
}
