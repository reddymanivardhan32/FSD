import React, { useEffect, useState } from 'react';
import { ArrowRight, Droplets, MapPin, QrCode, Sprout, Trophy, Users } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { apiRequest } from '../lib/api';
import { LeaderboardResponse } from '../types';

export default function LandingPage() {
  const { user, demoLogin } = useAuth();
  const navigate = useNavigate();
  const [leaderboard, setLeaderboard] = useState<LeaderboardResponse | null>(null);
  const [demoLoading, setDemoLoading] = useState(false);
  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [bottleImgFailed, setBottleImgFailed] = useState(false);

  useEffect(() => {
    apiRequest<LeaderboardResponse>('/api/squads/leaderboard')
      .then(setLeaderboard)
      .catch(() => {});
  }, []);

  const handleInstantDemo = async () => {
    setDemoLoading(true);
    try {
      await demoLogin();
      navigate('/squad');
    } finally {
      setDemoLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-xs">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-4 sm:px-8">
          <Link
            to="/"
            className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            SipStreak
          </Link>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
            <a href="#features" className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0">
              Features
            </a>
            <a href="#standings" className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0">
              Leaderboard
            </a>
            <Link to="/map" className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0">
              Campus Map
            </Link>
            <a href="#demo-guide" className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0">
              Demo Guide
            </a>
          </nav>

          <div className="flex items-center shrink-0">
            {user ? (
              <Link
                to="/dashboard"
                className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
              >
                Open Dashboard
              </Link>
            ) : (
              <Link
                to="/auth"
                className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
              >
                Sign In
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-8 lg:py-16">
        <div className="grid grid-cols-1 items-stretch gap-8 lg:grid-cols-12">
          <div className="flex flex-col justify-between lg:col-span-6 py-2">
            <div>
              <p className="text-xs font-semibold tracking-wide text-sky-700">
                HydroHero Hunt · Campus Team Hydration Challenge
              </p>
              <h1
                className="mt-3 font-display font-extrabold tracking-tight text-slate-900"
                style={{ fontSize: 'clamp(2.25rem, 4vw, 3.5rem)', lineHeight: 1.08, textWrap: 'balance' }}
              >
                Turn daily water goals into a shared squad streak.
              </h1>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-slate-600">
                SipStreak replaces ignored solo water reminders with collaborative hostel and classroom squads,
                fair-participation scoring capped at 100% per teammate, live campus rankings, and one-tap logging.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={handleInstantDemo}
                  disabled={demoLoading}
                  className="inline-flex items-center gap-2 rounded-lg bg-sky-600 px-5 py-3 text-sm font-semibold text-white hover:bg-sky-700 transition-colors disabled:opacity-60 whitespace-nowrap shrink-0"
                >
                  {demoLoading ? 'Launching Demo...' : 'Launch Hostel Block B Demo'}
                  <ArrowRight className="h-4 w-4" />
                </button>
                <Link
                  to="/auth?mode=register"
                  className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-800 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
                >
                  Create Account
                </Link>
              </div>
            </div>

            <div className="mt-10 grid grid-cols-3 gap-6 border-t border-slate-200 pt-6">
              <div>
                <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">35 ml/kg</div>
                <div className="mt-0.5 text-xs text-slate-500">Personalized daily estimate</div>
              </div>
              <div>
                <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">4–8</div>
                <div className="mt-0.5 text-xs text-slate-500">Members per ranked squad</div>
              </div>
              <div>
                <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">100% Cap</div>
                <div className="mt-0.5 text-xs text-slate-500">Fair contribution rule</div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="relative h-full min-h-[300px] overflow-hidden rounded-2xl border border-slate-200 bg-slate-900">
              {!heroImgFailed ? (
                <img
                  src="/src/assets/images/hero_hydration_campus_1795147851909.jpg"
                  alt="University students walking across a sunlit campus carrying reusable stainless steel water bottles"
                  referrerPolicy="no-referrer"
                  onError={() => setHeroImgFailed(true)}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full w-full flex-col items-center justify-center bg-linear-to-br from-sky-900 to-slate-900 p-8 text-center text-white">
                  <Droplets className="h-12 w-12 text-sky-400" />
                  <p className="mt-3 font-display text-lg font-semibold">Campus Hydration Challenge</p>
                </div>
              )}
              <div className="absolute inset-x-0 bottom-0 bg-linear-to-t from-slate-950/85 via-slate-950/40 to-transparent p-6 text-white">
                <div className="text-xs font-medium text-sky-300">Live Campus Participation</div>
                <div className="mt-1 font-display text-lg font-semibold">
                  Hostel wings, project teams, and classrooms competing daily.
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Live Campus Standings Preview */}
      <section id="standings" className="border-y border-slate-200 bg-white py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="font-display text-2xl font-bold text-slate-900">
                Live Campus Squad Standings
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                Calculated live from SQLite hydration logs using the fair 100%-capped team average formula.
              </p>
            </div>
            <Link
              to="/leaderboard"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-sky-700 hover:text-sky-800 whitespace-nowrap"
            >
              Open Full Leaderboard
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {(leaderboard?.rankedTeams ?? []).map((team) => (
              <div
                key={team.squadId}
                className="rounded-xl border border-slate-200 bg-slate-50/70 p-5"
              >
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span className="font-mono font-semibold text-slate-900 tabular-nums">
                    Rank #{team.rank}
                  </span>
                  <span className="tabular-nums">{team.memberCount} members</span>
                </div>
                <h3 className="mt-2 font-display text-lg font-bold text-slate-900 truncate">
                  {team.teamName}
                </h3>
                <div className="mt-3 flex items-baseline justify-between">
                  <span className="font-display text-3xl font-extrabold text-sky-700 tabular-nums">
                    {team.teamScore}%
                  </span>
                  <span className="font-mono text-xs text-slate-500 tabular-nums">
                    {team.totalIntakeMl.toLocaleString()} ml
                  </span>
                </div>
                <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-200">
                  <div
                    className="h-full rounded-full bg-sky-600 transition-all duration-300"
                    style={{ width: `${Math.min(team.teamScore, 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Editorial Numbered Capabilities */}
      <section id="features" className="mx-auto max-w-7xl px-4 py-14 sm:px-8">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 items-start">
          <div className="lg:col-span-5">
            <h2 className="font-display text-3xl font-bold tracking-tight text-slate-900">
              Built for real campus accountability, not ignored alerts.
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-slate-600">
              Every intake tap updates personal progress, recalculates team averages, grows your virtual
              seedling, and adjusts for caffeinated drinks in real time.
            </p>
            <div className="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-white">
              {!bottleImgFailed ? (
                <img
                  src="/src/assets/images/squad_challenge_bottle_1795147851027.jpg"
                  alt="Matte deep-navy insulated reusable water bottle with condensation on limestone"
                  referrerPolicy="no-referrer"
                  onError={() => setBottleImgFailed(true)}
                  className="aspect-4/3 w-full object-cover"
                />
              ) : (
                <div className="flex aspect-4/3 items-center justify-center bg-slate-100 text-slate-500">
                  <Droplets className="h-10 w-10 text-sky-600" />
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-7 divide-y divide-slate-200 border-y border-slate-200 bg-white rounded-2xl border px-6">
            <div className="py-5 flex gap-4">
              <Trophy className="h-5 w-5 text-sky-600 shrink-0 mt-0.5" />
              <div>
                <h3 className="font-display text-base font-bold text-slate-900">
                  01. Fair-Participation Squad Leaderboard
                </h3>
                <p className="mt-1 text-sm text-slate-600">
                  Each member’s contribution is capped at 100% of their personal goal so one heavy drinker
                  cannot carry a 4–8 member squad.
                </p>
              </div>
            </div>

            <div className="py-5 flex gap-4">
              <QrCode className="h-5 w-5 text-sky-600 shrink-0 mt-0.5" />
              <div>
                <h3 className="font-display text-base font-bold text-slate-900">
                  02. Quick-Tap & Printable Bottle QR Logging
                </h3>
                <p className="mt-1 text-sm text-slate-600">
                  Log +250 ml, +500 ml, +750 ml, custom amounts, or scan your personal printable bottle QR
                  sticker with built-in duplicate-tap protection.
                </p>
              </div>
            </div>

            <div className="py-5 flex gap-4">
              <Sprout className="h-5 w-5 text-sky-600 shrink-0 mt-0.5" />
              <div>
                <h3 className="font-display text-base font-bold text-slate-900">
                  03. Virtual Plant Companion & Caffeine Offset
                </h3>
                <p className="mt-1 text-sm text-slate-600">
                  Watch your botanical companion react to real hydration consistency, and automatically
                  add +200 ml compensatory water targets when logging coffee or energy drinks.
                </p>
              </div>
            </div>

            <div className="py-5 flex gap-4">
              <MapPin className="h-5 w-5 text-sky-600 shrink-0 mt-0.5" />
              <div>
                <h3 className="font-display text-base font-bold text-slate-900">
                  04. Campus Refill Map & Daytime Nudge Simulator
                </h3>
                <p className="mt-1 text-sm text-slate-600">
                  Locate sample campus refill stations on an interactive Leaflet map and schedule
                  daytime browser notifications without spam outside active hours.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Hackathon Demo Quick Walkthrough */}
      <section id="demo-guide" className="border-t border-slate-200 bg-white py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-8">
          <div className="flex flex-col justify-between gap-6 rounded-2xl border border-slate-200 bg-slate-900 p-8 text-white lg:flex-row lg:items-center">
            <div className="max-w-2xl">
              <div className="text-xs font-semibold text-sky-300">Hackathon Evaluation Walkthrough</div>
              <h2 className="mt-2 font-display text-2xl font-bold">
                Test the live Hostel Block B overtake scenario
              </h2>
              <p className="mt-2 text-sm text-slate-300 leading-relaxed">
                Sign in as demo presenter Rohan Verma (Hostel Block B, currently Rank #2 at 72%).
                Click &ldquo;+500 ml Water Bottle&rdquo; to watch personal completion hit 88%, team
                score climb to 78%, and Hostel Block B overtake Hostel Block A for 1st place.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={handleInstantDemo}
                disabled={demoLoading}
                className="inline-flex items-center gap-2 rounded-lg bg-sky-500 px-5 py-3 text-sm font-semibold text-white hover:bg-sky-400 transition-colors whitespace-nowrap"
              >
                <Users className="h-4 w-4" />
                {demoLoading ? 'Signing In...' : 'Start Demo Flow'}
              </button>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-slate-200 bg-slate-50 py-8">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-4 px-4 text-xs text-slate-500 sm:flex-row sm:items-center sm:px-8">
          <div>SipStreak — HydroHero Hunt. Hydration targets (Weight × 35 ml) are general tracking estimates, not medical prescriptions.</div>
          <div className="flex items-center gap-5">
            <Link to="/leaderboard" className="hover:text-slate-900">Leaderboard</Link>
            <Link to="/map" className="hover:text-slate-900">Campus Map</Link>
            <Link to="/auth" className="hover:text-slate-900">Sign In</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
