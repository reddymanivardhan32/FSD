import React, { useCallback, useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { Camera, CheckCircle2, Droplets, Printer, QrCode, Upload, XCircle } from 'lucide-react';
import QRCode from 'qrcode';
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { AppShell } from '../components/AppShell';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { ApiError, apiRequest } from '../lib/api';
import { RankTransition } from '../types';

export default function QrPage() {
  const { user, loading: authLoading } = useAuth();
  const { pushToast, triggerCelebration } = useToast();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();

  const qrAction = searchParams.get('action');
  const qrUid = searchParams.get('uid');
  const qrSig = searchParams.get('sig');
  const hasScannedRouteParams = qrAction === 'bottle500' && Boolean(qrUid);

  const [qrUrl, setQrUrl] = useState('');
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [loadingQr, setLoadingQr] = useState(true);
  const [confirmingScan, setConfirmingScan] = useState(false);
  const [scanSuccessMsg, setScanSuccessMsg] = useState<string | null>(null);
  const [scanErrorMsg, setScanErrorMsg] = useState<string | null>(null);

  const [cameraActive, setCameraActive] = useState(false);
  const [decodedText, setDecodedText] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);

  // If a user scans a bottle QR while signed out, require authentication first and preserve the route
  useEffect(() => {
    if (!authLoading && !user && hasScannedRouteParams) {
      const fullPath = `${location.pathname}${location.search}`;
      navigate(`/auth?redirect=${encodeURIComponent(fullPath)}`, { replace: true });
    }
  }, [authLoading, user, hasScannedRouteParams, location.pathname, location.search, navigate]);

  useEffect(() => {
    if (!user) return;
    apiRequest<{ qrUrl: string }>('/api/qr/payload')
      .then(async (res) => {
        setQrUrl(res.qrUrl);
        const dataUrl = await QRCode.toDataURL(res.qrUrl, {
          width: 240,
          margin: 2,
          color: {
            dark: '#0B1F3A',
            light: '#FFFFFF',
          },
        });
        setQrDataUrl(dataUrl);
      })
      .finally(() => setLoadingQr(false));
  }, [user]);

  const stopCamera = useCallback(() => {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  }, []);

  useEffect(() => {
    return () => stopCamera();
  }, [stopCamera]);

  const processDecodedQr = useCallback(
    (rawPayload: string) => {
      setDecodedText(rawPayload);
      stopCamera();
      try {
        const parsed = new URL(rawPayload, window.location.origin);
        const action = parsed.searchParams.get('action');
        const uid = parsed.searchParams.get('uid');
        const sig = parsed.searchParams.get('sig');
        if (action === 'bottle500' && uid) {
          navigate(`/qr?action=bottle500&uid=${encodeURIComponent(uid)}&sig=${encodeURIComponent(sig || '')}`);
        } else {
          setScanErrorMsg('QR code decoded, but it is not a SipStreak +500 ml bottle tag.');
        }
      } catch {
        setScanErrorMsg('Scanned QR code does not contain a valid SipStreak URL.');
      }
    },
    [navigate, stopCamera],
  );

  const startCameraScanner = async () => {
    setScanErrorMsg(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setScanErrorMsg('Camera access is unavailable in this browser. Upload a QR image instead.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      streamRef.current = stream;
      setCameraActive(true);

      const scanFrame = () => {
        const video = videoRef.current;
        const canvas = canvasRef.current;
        if (video && canvas && video.readyState === video.HAVE_ENOUGH_DATA) {
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const code = jsQR(imgData.data, imgData.width, imgData.height);
            if (code?.data) {
              processDecodedQr(code.data);
              return;
            }
          }
        }
        rafRef.current = requestAnimationFrame(scanFrame);
      };

      window.setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
          rafRef.current = requestAnimationFrame(scanFrame);
        }
      }, 80);
    } catch {
      setScanErrorMsg('Camera permission denied or no camera detected. You can upload a QR image below.');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setScanErrorMsg(null);

    const img = new Image();
    const reader = new FileReader();
    reader.onload = () => {
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);
        if (code?.data) {
          processDecodedQr(code.data);
        } else {
          setScanErrorMsg('No readable QR code found in that image.');
        }
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const confirmBottleQrLog = async () => {
    if (confirmingScan) return;
    setConfirmingScan(true);
    setScanErrorMsg(null);
    setScanSuccessMsg(null);

    const scanNonce = `${qrUid}-${qrSig || 'tag'}-${Math.floor(Date.now() / 10000)}`;
    try {
      const res = await apiRequest<{
        todayStats: { totalIntakeMl: number; completionPct: number };
        rankTransition: RankTransition | null;
      }>('/api/qr/scan-log', {
        method: 'POST',
        body: JSON.stringify({
          scanNonce,
          scannedUserId: qrUid,
        }),
      });
      setScanSuccessMsg(
        `Logged +500 ml from your bottle QR sticker! Today’s intake: ${res.todayStats.totalIntakeMl.toLocaleString()} ml (${res.todayStats.completionPct}%).`,
      );
      pushToast({
        title: 'QR Bottle Logged (+500 ml)',
        description: `Progress updated to ${res.todayStats.completionPct}%.`,
        tone: 'success',
      });
      if (res.rankTransition?.improved) {
        triggerCelebration(res.rankTransition);
      }
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Could not log QR scan.';
      setScanErrorMsg(msg);
      pushToast({ title: 'QR Scan Notice', description: msg, tone: 'warning' });
    } finally {
      setConfirmingScan(false);
    }
  };

  if (authLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 text-sm text-slate-600">
        Checking HydroHero session...
      </div>
    );
  }

  return (
    <AppShell
      title="Water Bottle QR Sticker & Scanner"
      subtitle="Generate printable +500 ml bottle stickers and scan to log hydration"
    >
      {/* Preselected +500 ml QR Action Confirmation Panel */}
      {hasScannedRouteParams && (
        <section className="mb-6 rounded-2xl border border-sky-300 bg-sky-50/70 p-6">
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
            <div>
              <div className="text-xs font-semibold text-sky-800">QR Bottle Action Detected</div>
              <h2 className="mt-1 font-display text-xl font-bold text-slate-900">
                Confirm +500 ml Water Bottle Refill
              </h2>
              <p className="mt-1 text-xs text-slate-600">
                Authenticated as <strong>{user.name}</strong>. Repeated scans within 10 seconds are
                automatically blocked to prevent duplicate logs.
              </p>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <button
                type="button"
                disabled={confirmingScan}
                onClick={confirmBottleQrLog}
                className="inline-flex items-center gap-2 rounded-lg bg-sky-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-sky-700 disabled:opacity-60"
              >
                <Droplets className="h-4 w-4" />
                {confirmingScan ? 'Logging...' : 'Confirm +500 ml Bottle'}
              </button>
              <Link
                to="/qr"
                className="rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50"
              >
                Dismiss
              </Link>
            </div>
          </div>

          {scanSuccessMsg && (
            <div className="mt-4 flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-medium text-emerald-900">
              <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
              {scanSuccessMsg}
            </div>
          )}

          {scanErrorMsg && (
            <div className="mt-4 flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs font-medium text-red-800">
              <XCircle className="h-4 w-4 text-red-600 shrink-0" />
              {scanErrorMsg}
            </div>
          )}
        </section>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Printable Bottle Sticker */}
        <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900">
                Your Printable Bottle QR Sticker
              </h2>
              <p className="text-xs text-slate-500">
                Opens SipStreak with +500 ml Water Bottle preselected.
              </p>
            </div>
            <QrCode className="h-5 w-5 text-sky-600" />
          </div>

          <div className="mt-6 flex justify-center">
            <div
              id="printable-qr-sticker"
              className="w-full max-w-xs rounded-2xl border-2 border-slate-900 bg-white p-6 text-center shadow-xs"
            >
              <div className="flex items-center justify-center gap-1.5 font-display text-base font-extrabold text-slate-900">
                <Droplets className="h-4 w-4 text-sky-600" />
                SipStreak
              </div>
              <div className="mt-0.5 text-[11px] font-medium text-slate-500">
                HydroHero Hunt · Bottle Tag
              </div>

              <div className="my-4 flex justify-center">
                {loadingQr || !qrDataUrl ? (
                  <div className="h-48 w-48 animate-pulse rounded-xl bg-slate-100" />
                ) : (
                  <img
                    src={qrDataUrl}
                    alt={`Personal +500 ml bottle QR code for ${user.name}`}
                    className="h-48 w-48 rounded-lg border border-slate-100"
                  />
                )}
              </div>

              <div className="font-display text-sm font-bold text-slate-900">{user.name}</div>
              <div className="mt-0.5 font-mono text-xs font-semibold text-sky-700">
                Scan to Log +500 ml Bottle
              </div>
            </div>
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-semibold text-white hover:bg-slate-800"
            >
              <Printer className="h-4 w-4" />
              Print Bottle Sticker
            </button>
            {qrUrl && (
              <button
                type="button"
                onClick={() => processDecodedQr(qrUrl)}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-xs font-semibold text-slate-800 hover:bg-slate-50"
              >
                Simulate Scanning My Sticker
              </button>
            )}
          </div>
        </section>

        {/* Built-In QR Scanner */}
        <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-6">
          <h2 className="font-display text-lg font-bold text-slate-900">Scan Bottle QR Code</h2>
          <p className="mt-1 text-xs text-slate-500">
            Use your webcam or upload a saved QR sticker image to trigger the +500 ml bottle log flow.
          </p>

          <div className="mt-5 flex flex-wrap gap-3">
            {!cameraActive ? (
              <button
                type="button"
                onClick={startCameraScanner}
                className="inline-flex items-center gap-2 rounded-lg bg-sky-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-sky-700"
              >
                <Camera className="h-4 w-4" />
                Start Camera Scanner
              </button>
            ) : (
              <button
                type="button"
                onClick={stopCamera}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-xs font-semibold text-slate-800 hover:bg-slate-50"
              >
                Stop Camera
              </button>
            )}

            <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-xs font-semibold text-slate-800 hover:bg-slate-50">
              <Upload className="h-4 w-4" />
              Upload QR Image
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="sr-only"
              />
            </label>
          </div>

          {cameraActive && (
            <div className="mt-5 overflow-hidden rounded-xl border border-slate-200 bg-slate-950">
              <video ref={videoRef} className="w-full max-h-64 object-cover" muted playsInline />
              <canvas ref={canvasRef} className="hidden" />
            </div>
          )}

          {decodedText && (
            <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-700 break-all">
              <span className="font-semibold text-slate-900">Decoded QR URL:</span> {decodedText}
            </div>
          )}

          {!hasScannedRouteParams && scanErrorMsg && (
            <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-xs text-red-800">
              {scanErrorMsg}
            </div>
          )}

          <div className="mt-6 rounded-xl border border-slate-100 bg-slate-50 p-4 text-xs text-slate-600 space-y-1.5">
            <div className="font-semibold text-slate-900">How duplicate scan protection works</div>
            <p>
              Each QR scan binds to your signed-in account and sends a unique scan nonce plus a
              10-second server-side cooldown, preventing accidental double-scans from inflating intake.
            </p>
          </div>
        </section>
      </div>
    </AppShell>
  );
}
