import React, { useCallback, useEffect, useState } from 'react';
import { ArrowDown, ArrowUp, ChevronDown, ChevronUp, RotateCcw, Trophy } from 'lucide-react';
import { Link } from 'react-router-dom';
import { AppShell } from '../components/AppShell';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { apiRequest } from '../lib/api';
import { LeaderboardResponse, User } from '../types';

export default function LeaderboardPage() {
  const { user, applySession } = useAuth();
  const { pushToast } = useToast();
  const [data, setData] = useState<LeaderboardResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedSquadId, setExpandedSquadId] = useState<string | null>(null);
  const [resetting, setResetting] = useState(false);

  const loadLeaderboard = useCallback(async () => {
    try {
      const res = await apiRequest<LeaderboardResponse>('/api/squads/leaderboard');
      setData(res);
      if (res.mySquadId) {
        setExpandedSquadId((prev) => prev ?? res.mySquadId);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadLeaderboard();
  }, [loadLeaderboard]);

  const handleResetDemo = async () => {
    setResetting(true);
    try {
      const res = await apiRequest<{
        token: string;
        user: User;
        leaderboard: LeaderboardResponse;
      }>('/api/demo/reset', { method: 'POST' });
      applySession(res.token, res.user);
      setData(res.leaderboard);
      pushToast({
        title: 'Hackathon Demo Reset',
        description: 'Hostel Block B is back at #2 (72%) behind Hostel Block A (#1, 75%).',
        tone: 'info',
      });
    } finally {
      setResetting(false);
    }
  };

  const content = (
    <div className="space-y-6">
      {/* Formula Transparency Header */}
      <div className="flex flex-col justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-6 lg:flex-row lg:items-center">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Fair-Participation Team Scoring
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Every squad’s score is the average of its members’ capped daily completion percentages.
            Individual contributions cap at <strong className="font-semibold text-slate-900">100%</strong> so
            one heavy drinker cannot carry an entire team.
          </p>
          <p className="mt-2 font-mono text-xs text-sky-800">
            TeamScore = (sum(min(Member_Intake / Member_Goal, 1)) / Team_Size) × 100
          </p>
        </div>
        <button
          type="button"
          onClick={handleResetDemo}
          disabled={resetting}
          className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          {resetting ? 'Resetting...' : 'Reset Demo Standings'}
        </button>
      </div>

      {loading || !data ? (
        <div className="h-80 animate-pulse rounded-2xl border border-slate-200 bg-white" />
      ) : (
        <>
          {/* Top 3 Podium Cards */}
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            {data.rankedTeams.slice(0, 3).map((team) => {
              const isMine = data.mySquadId === team.squadId;
              return (
                <div
                  key={team.squadId}
                  className={`rounded-2xl border p-6 transition-colors ${
                    team.rank === 1
                      ? 'border-sky-300 bg-sky-50/70'
                      : isMine
                        ? 'border-sky-200 bg-white'
                        : 'border-slate-200 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono font-bold text-slate-900 tabular-nums">
                      Rank #{team.rank}
                    </span>
                    <span className="text-slate-500 tabular-nums">
                      {isMine ? 'Your Squad' : `${team.memberCount} members`}
                    </span>
                  </div>
                  <h3 className="mt-2 font-display text-xl font-bold text-slate-900">
                    {team.teamName}
                  </h3>
                  <div className="mt-3 flex items-baseline justify-between">
                    <span className="font-display text-4xl font-extrabold text-sky-700 tabular-nums">
                      {team.teamScore}%
                    </span>
                    <span className="font-mono text-xs text-slate-600 tabular-nums">
                      {team.totalIntakeMl.toLocaleString()} ml
                    </span>
                  </div>
                  <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-200">
                    <div
                      className="h-full rounded-full bg-sky-600 transition-all duration-300"
                      style={{ width: `${Math.min(team.teamScore, 100)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Full Ranked Leaderboard Table with Expandable Member Contributions */}
          <section className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
            <div className="border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <h3 className="font-display text-base font-bold text-slate-900">
                Qualifying Squads (4–8 Members)
              </h3>
              <span className="text-xs text-slate-500 tabular-nums">Date: {data.date}</span>
            </div>

            <div className="divide-y divide-slate-200">
              {data.rankedTeams.map((team) => {
                const isMine = data.mySquadId === team.squadId;
                const isExpanded = expandedSquadId === team.squadId;
                return (
                  <div key={team.squadId} className={isMine ? 'bg-sky-50/40' : 'bg-white'}>
                    <button
                      type="button"
                      onClick={() => setExpandedSquadId(isExpanded ? null : team.squadId)}
                      className="flex w-full items-center justify-between gap-4 px-6 py-4 text-left hover:bg-slate-50/70 transition-colors"
                    >
                      <div className="flex items-center gap-4 min-w-0">
                        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-900 font-mono text-sm font-bold text-white tabular-nums shrink-0">
                          #{team.rank}
                        </span>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-display text-base font-bold text-slate-900 truncate">
                              {team.teamName}
                            </span>
                            {isMine && (
                              <span className="text-xs font-semibold text-sky-700">· Your Squad</span>
                            )}
                          </div>
                          <div className="mt-0.5 text-xs text-slate-500 tabular-nums">
                            {team.memberCount} members · {team.totalIntakeMl.toLocaleString()} ml total ·
                            Code {team.inviteCode}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-5 shrink-0">
                        <div className="text-right">
                          <div className="font-display text-xl font-bold text-slate-900 tabular-nums">
                            {team.teamScore}%
                          </div>
                          <div className="flex items-center justify-end gap-1 text-xs tabular-nums">
                            {team.rankDelta > 0 ? (
                              <span className="inline-flex items-center text-emerald-700 font-medium">
                                <ArrowUp className="h-3 w-3" />+{team.rankDelta} vs yesterday
                              </span>
                            ) : team.rankDelta < 0 ? (
                              <span className="inline-flex items-center text-amber-700 font-medium">
                                <ArrowDown className="h-3 w-3" />
                                {team.rankDelta} vs yesterday
                              </span>
                            ) : (
                              <span className="text-slate-400">No rank change</span>
                            )}
                          </div>
                        </div>
                        {isExpanded ? (
                          <ChevronUp className="h-4 w-4 text-slate-400" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-slate-400" />
                        )}
                      </div>
                    </button>

                    {isExpanded && (
                      <div className="border-t border-slate-100 bg-slate-50/70 px-6 py-4">
                        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                          {team.members.map((m) => (
                            <div
                              key={m.id}
                              className="rounded-xl border border-slate-200 bg-white p-3.5 text-xs"
                            >
                              <div className="font-semibold text-slate-900 truncate">{m.name}</div>
                              <div className="mt-1 font-mono text-slate-600 tabular-nums">
                                {m.intakeMl.toLocaleString()} / {m.goalMl.toLocaleString()} ml
                              </div>
                              <div className="mt-2 flex items-center justify-between tabular-nums">
                                <span className="text-slate-500">Capped score</span>
                                <span className="font-bold text-sky-700">
                                  {m.cappedContributionPct}%
                                  {m.rawPct > 100 ? ` (${m.rawPct}% raw)` : ''}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>

          {/* Forming Squads (<4 members) */}
          {data.formingTeams.length > 0 && (
            <section className="rounded-2xl border border-slate-200 bg-white p-6">
              <h3 className="font-display text-base font-bold text-slate-900">
                Forming Squads (Below 4-Member Minimum)
              </h3>
              <p className="mt-1 text-xs text-slate-500">
                Squads must have 4–8 members to qualify for ranked team challenges.
              </p>
              <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {data.formingTeams.map((t) => (
                  <div
                    key={t.squadId}
                    className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm"
                  >
                    <div>
                      <div className="font-semibold text-slate-900">{t.teamName}</div>
                      <div className="text-xs text-slate-500 tabular-nums">
                        {t.memberCount}/4 minimum members · Code {t.inviteCode}
                      </div>
                    </div>
                    <span className="font-mono text-xs text-slate-500">Unranked</span>
                  </div>
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </div>
  );

  if (user) {
    return (
      <AppShell
        title="HydroHero Team Leaderboard"
        subtitle="Live rankings updated on every water log with 100%-capped fair participation"
      >
        {content}
      </AppShell>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-4 sm:px-8">
          <Link to="/" className="font-display text-lg font-bold text-slate-900 whitespace-nowrap">
            SipStreak
          </Link>
          <div className="flex items-center gap-4">
            <Link to="/map" className="text-sm font-medium text-slate-600 hover:text-slate-900">
              Campus Map
            </Link>
            <Link
              to="/auth"
              className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 whitespace-nowrap"
            >
              Sign In
            </Link>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-8">
        <div className="mb-6 flex items-center gap-2">
          <Trophy className="h-5 w-5 text-sky-600" />
          <h1 className="font-display text-2xl font-bold text-slate-900">
            HydroHero Team Leaderboard
          </h1>
        </div>
        {content}
      </main>
    </div>
  );
}
