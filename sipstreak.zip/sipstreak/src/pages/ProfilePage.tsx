import React, { useEffect, useState } from 'react';
import { Bell, BellOff, RotateCcw, Save } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { AppShell } from '../components/AppShell';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { ApiError, apiRequest } from '../lib/api';
import { ReminderSettings, User } from '../types';

export default function ProfilePage() {
  const { user, refreshUser, applySession } = useAuth();
  const { pushToast, reminderSettings, refreshReminders, triggerHydrationNudge } = useToast();
  const navigate = useNavigate();

  const [name, setName] = useState(user?.name ?? '');
  const [weightKg, setWeightKg] = useState(String(user?.weightKg ?? 60));
  const [savingProfile, setSavingProfile] = useState(false);

  const [enabled, setEnabled] = useState(true);
  const [startHour, setStartHour] = useState(8);
  const [endHour, setEndHour] = useState(21);
  const [intervalMinutes, setIntervalMinutes] = useState(60);
  const [savingReminders, setSavingReminders] = useState(false);
  const [nudgeResult, setNudgeResult] = useState<string | null>(null);
  const [notifPermission, setNotifPermission] = useState<string>(() =>
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'unsupported',
  );
  const [resettingDemo, setResettingDemo] = useState(false);

  useEffect(() => {
    if (user) {
      setName(user.name);
      setWeightKg(String(user.weightKg));
    }
  }, [user]);

  useEffect(() => {
    if (reminderSettings) {
      setEnabled(Boolean(reminderSettings.enabled));
      setStartHour(reminderSettings.startHour);
      setEndHour(reminderSettings.endHour);
      setIntervalMinutes(reminderSettings.intervalMinutes);
    }
  }, [reminderSettings]);

  const parsedWeight = Number(weightKg);
  const previewGoal =
    Number.isFinite(parsedWeight) && parsedWeight >= 25 && parsedWeight <= 250
      ? Math.round(parsedWeight * 35)
      : null;

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      await apiRequest<{ user: User }>('/api/auth/profile', {
        method: 'PATCH',
        body: JSON.stringify({ name, weightKg: Number(weightKg) }),
      });
      await refreshUser();
      pushToast({
        title: 'Profile updated',
        description: previewGoal
          ? `New daily hydration target: ${previewGoal.toLocaleString()} ml.`
          : 'Saved successfully.',
        tone: 'success',
      });
    } catch (err) {
      pushToast({
        title: 'Profile update failed',
        description: err instanceof ApiError ? err.message : 'Error',
        tone: 'error',
      });
    } finally {
      setSavingProfile(false);
    }
  };

  const handleRequestPermission = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setNotifPermission('unsupported');
      setNudgeResult('Browser Notifications API is unavailable; in-app toast fallback will be used.');
      return;
    }
    const result = await Notification.requestPermission();
    setNotifPermission(result);
    if (result === 'granted') {
      pushToast({ title: 'Browser notifications enabled', tone: 'success' });
    } else {
      pushToast({
        title: 'Using in-app nudge fallback',
        description: 'Browser notification permission was not granted.',
        tone: 'info',
      });
    }
  };

  const handleSaveReminders = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingReminders(true);
    try {
      await apiRequest<{ settings: ReminderSettings }>('/api/reminders', {
        method: 'PUT',
        body: JSON.stringify({
          enabled,
          startHour: Number(startHour),
          endHour: Number(endHour),
          intervalMinutes: Number(intervalMinutes),
        }),
      });
      await refreshReminders();
      pushToast({ title: 'Reminder schedule saved', tone: 'success' });
    } catch (err) {
      pushToast({
        title: 'Could not save reminder settings',
        description: err instanceof ApiError ? err.message : 'Error',
        tone: 'error',
      });
    } finally {
      setSavingReminders(false);
    }
  };

  const handleTestNudge = async (options?: { forceTest?: boolean; simulateHour?: number }) => {
    const res = await triggerHydrationNudge(options);
    setNudgeResult(res.reason);
  };

  const handleResetDemo = async () => {
    setResettingDemo(true);
    try {
      const res = await apiRequest<{ token: string; user: User }>('/api/demo/reset', {
        method: 'POST',
      });
      applySession(res.token, res.user);
      pushToast({
        title: 'Hackathon Demo Reset Complete',
        description: 'Signed in as Rohan Verma (Hostel Block B · Rank #2 at 72%).',
        tone: 'success',
      });
      navigate('/squad');
    } finally {
      setResettingDemo(false);
    }
  };

  return (
    <AppShell
      title="Profile, Target Calculator & Nudges"
      subtitle="Configure your Weight × 35 ml estimate and hourly daytime hydration reminders"
    >
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Profile & Body Weight Goal Engine */}
        <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-6">
          <h2 className="font-display text-lg font-bold text-slate-900">
            Personal Profile & Goal Engine
          </h2>
          <p className="mt-1 text-xs text-slate-500">
            Formula: <code className="font-mono">TargetMl = WeightKg × 35 ml</code>. General tracking
            estimate only, not a medical prescription.
          </p>

          <form onSubmit={handleSaveProfile} className="mt-5 space-y-4">
            <div>
              <label htmlFor="prof-name" className="block text-xs font-semibold text-slate-700">
                Display Name
              </label>
              <input
                id="prof-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-sky-600 focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="prof-weight" className="block text-xs font-semibold text-slate-700">
                Body Weight (kg)
              </label>
              <input
                id="prof-weight"
                type="number"
                required
                min={25}
                max={250}
                step="0.5"
                value={weightKg}
                onChange={(e) => setWeightKg(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 tabular-nums focus:border-sky-600 focus:outline-none"
              />
            </div>

            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs tabular-nums">
              <div className="text-slate-500">Calculated Daily Hydration Target</div>
              <div className="mt-1 font-display text-2xl font-extrabold text-sky-700">
                {previewGoal ? `${previewGoal.toLocaleString()} ml / day` : 'Enter weight (25–250 kg)'}
              </div>
            </div>

            <button
              type="submit"
              disabled={savingProfile}
              className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-60"
            >
              <Save className="h-4 w-4" />
              {savingProfile ? 'Saving...' : 'Save & Recalculate Target'}
            </button>
          </form>

          {/* Hackathon Demo Reset Box */}
          <div className="mt-8 border-t border-slate-200 pt-6">
            <h3 className="font-display text-sm font-bold text-slate-900">
              Hackathon Demonstration Reset
            </h3>
            <p className="mt-1 text-xs text-slate-600">
              Restore the 4 seeded campus teams so Hostel Block B starts at Rank #2 (72%) and Rohan
              Verma starts at 64% (1350/2100 ml).
            </p>
            <button
              type="button"
              onClick={handleResetDemo}
              disabled={resettingDemo}
              className="mt-3 inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              {resettingDemo ? 'Resetting Demo...' : 'Reset Demo State & Open Squad Dashboard'}
            </button>
          </div>
        </section>

        {/* Hourly Hydration Nudge Simulator */}
        <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900">
                Hourly Hydration Nudge Simulator
              </h2>
              <p className="mt-0.5 text-xs text-slate-500">
                Active while this browser tab is open; reminders do not fire when the browser is completely closed.
              </p>
            </div>
            {enabled ? (
              <Bell className="h-5 w-5 text-sky-600 shrink-0" />
            ) : (
              <BellOff className="h-5 w-5 text-slate-400 shrink-0" />
            )}
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs">
            <div>
              <div className="font-semibold text-slate-900">
                Browser Notification Permission: <span className="font-mono">{notifPermission}</span>
              </div>
              <div className="mt-0.5 text-slate-600">
                If unavailable or denied, nudges seamlessly display via in-app toast alerts.
              </div>
            </div>
            <button
              type="button"
              onClick={handleRequestPermission}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-semibold text-slate-800 hover:bg-slate-100 whitespace-nowrap"
            >
              Request Permission
            </button>
          </div>

          <form onSubmit={handleSaveReminders} className="mt-5 space-y-4">
            <label className="flex items-center gap-3 text-sm font-medium text-slate-900 cursor-pointer">
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => setEnabled(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-sky-600"
              />
              Enable daytime hourly hydration reminders
            </label>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label htmlFor="rem-start" className="block text-xs font-semibold text-slate-700">
                  Start Hour
                </label>
                <input
                  id="rem-start"
                  type="number"
                  min={0}
                  max={22}
                  value={startHour}
                  onChange={(e) => setStartHour(Number(e.target.value))}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
                />
              </div>
              <div>
                <label htmlFor="rem-end" className="block text-xs font-semibold text-slate-700">
                  End Hour
                </label>
                <input
                  id="rem-end"
                  type="number"
                  min={1}
                  max={23}
                  value={endHour}
                  onChange={(e) => setEndHour(Number(e.target.value))}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
                />
              </div>
              <div>
                <label htmlFor="rem-int" className="block text-xs font-semibold text-slate-700">
                  Interval (min)
                </label>
                <input
                  id="rem-int"
                  type="number"
                  min={1}
                  max={240}
                  value={intervalMinutes}
                  onChange={(e) => setIntervalMinutes(Number(e.target.value))}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={savingReminders}
              className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-60"
            >
              {savingReminders ? 'Saving...' : 'Save Schedule'}
            </button>
          </form>

          {/* Simulator Controls */}
          <div className="mt-6 border-t border-slate-200 pt-5 space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Simulator Controls
            </h3>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => handleTestNudge({ forceTest: true })}
                className="rounded-lg bg-sky-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-sky-700"
              >
                Send Test Notification
              </button>
              <button
                type="button"
                onClick={() => handleTestNudge({ forceTest: false, simulateHour: 14 })}
                className="rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50"
              >
                Simulate Daytime Check (14:00)
              </button>
              <button
                type="button"
                onClick={() => handleTestNudge({ forceTest: false, simulateHour: 23 })}
                className="rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50"
              >
                Simulate Nighttime Check (23:00)
              </button>
            </div>

            {nudgeResult && (
              <div className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs text-slate-700">
                {nudgeResult}
              </div>
            )}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
