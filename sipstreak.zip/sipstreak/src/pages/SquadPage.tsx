import React, { useCallback, useEffect, useState } from 'react';
import {
  Check,
  Copy,
  Droplets,
  Flame,
  LogOut,
  Plus,
  Trophy,
  UserPlus,
  Users,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { AppShell } from '../components/AppShell';
import { WaterBottleGraphic } from '../components/WaterBottleGraphic';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { ApiError, apiRequest } from '../lib/api';
import { DashboardPayload, LeaderboardResponse, RankTransition, SquadSummary } from '../types';

export default function SquadPage() {
  const { refreshUser } = useAuth();
  const { pushToast, triggerCelebration } = useToast();

  const [dashboard, setDashboard] = useState<DashboardPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [isLogging, setIsLogging] = useState(false);
  const [rippleKey, setRippleKey] = useState(0);

  const [joinCode, setJoinCode] = useState('');
  const [newTeamName, setNewTeamName] = useState('');
  const [squadError, setSquadError] = useState<string | null>(null);
  const [submittingSquad, setSubmittingSquad] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const res = await apiRequest<DashboardPayload>('/api/hydration/dashboard');
      setDashboard(res);
    } catch (err) {
      pushToast({
        title: 'Failed to load squad data',
        description: err instanceof ApiError ? err.message : 'Unexpected error',
        tone: 'error',
      });
    } finally {
      setLoading(false);
    }
  }, [pushToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleQuickLog = async (amountMl: number, drinkType: string) => {
    if (isLogging) return;
    setIsLogging(true);
    const clientRequestId = `squad-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    try {
      const res = await apiRequest<{
        todayStats: DashboardPayload['todayStats'];
        squad: SquadSummary | null;
        leaderboard: LeaderboardResponse;
        rankTransition: RankTransition | null;
      }>('/api/hydration/log', {
        method: 'POST',
        body: JSON.stringify({ amountMl, drinkType, clientRequestId }),
      });

      setRippleKey((k) => k + 1);
      setDashboard((prev) =>
        prev
          ? {
              ...prev,
              todayStats: res.todayStats,
              squad: res.squad,
            }
          : prev,
      );

      pushToast({
        title: `Logged +${amountMl} ml for your squad`,
        description: res.squad
          ? `${res.squad.teamName} score updated to ${res.squad.teamScore}% (Rank #${res.squad.rank ?? '—'}).`
          : `Personal completion is now ${res.todayStats.completionPct}%.`,
        tone: 'success',
      });

      if (res.rankTransition?.improved) {
        triggerCelebration(res.rankTransition);
      }
    } catch (err) {
      pushToast({
        title: 'Water log failed',
        description: err instanceof ApiError ? err.message : 'Error',
        tone: 'error',
      });
    } finally {
      setIsLogging(false);
    }
  };

  const handleJoinSquad = async (e: React.FormEvent) => {
    e.preventDefault();
    setSquadError(null);
    setSubmittingSquad(true);
    try {
      const res = await apiRequest<{ squad: SquadSummary }>('/api/squads/join', {
        method: 'POST',
        body: JSON.stringify({ inviteCode: joinCode }),
      });
      setJoinCode('');
      await refreshUser();
      await loadData();
      pushToast({
        title: `Joined ${res.squad.teamName}`,
        description: `Invite code ${res.squad.inviteCode} accepted.`,
        tone: 'success',
      });
    } catch (err) {
      setSquadError(err instanceof ApiError ? err.message : 'Could not join squad.');
    } finally {
      setSubmittingSquad(false);
    }
  };

  const handleCreateSquad = async (e: React.FormEvent) => {
    e.preventDefault();
    setSquadError(null);
    setSubmittingSquad(true);
    try {
      const res = await apiRequest<{ squad: SquadSummary }>('/api/squads/create', {
        method: 'POST',
        body: JSON.stringify({ teamName: newTeamName }),
      });
      setNewTeamName('');
      await refreshUser();
      await loadData();
      pushToast({
        title: `Created ${res.squad.teamName}`,
        description: `Share invite code ${res.squad.inviteCode} with 3–7 teammates to qualify for rankings.`,
        tone: 'success',
      });
    } catch (err) {
      setSquadError(err instanceof ApiError ? err.message : 'Could not create squad.');
    } finally {
      setSubmittingSquad(false);
    }
  };

  const handleLeaveSquad = async () => {
    setSubmittingSquad(true);
    try {
      await apiRequest('/api/squads/leave', { method: 'POST' });
      await refreshUser();
      await loadData();
      pushToast({ title: 'Left squad', tone: 'info' });
    } catch (err) {
      pushToast({
        title: 'Could not leave squad',
        description: err instanceof ApiError ? err.message : 'Error',
        tone: 'error',
      });
    } finally {
      setSubmittingSquad(false);
    }
  };

  const copyInviteCode = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCode(true);
      window.setTimeout(() => setCopiedCode(false), 2000);
    } catch {
      pushToast({ title: `Invite code: ${code}`, tone: 'info' });
    }
  };

  if (loading || !dashboard) {
    return (
      <AppShell title="Hydration Squad Dashboard" subtitle="Loading squad roster and telemetry...">
        <div className="h-96 animate-pulse rounded-2xl border border-slate-200 bg-white" />
      </AppShell>
    );
  }

  const { user, todayStats, squad } = dashboard;

  return (
    <AppShell
      title="Hydration Squad Dashboard"
      subtitle={
        squad
          ? `${squad.teamName} · ${squad.memberCount}/8 members · Invite code ${squad.inviteCode}`
          : 'Join an existing squad or create a new 4–8 member squad'
      }
      action={
        <Link
          to="/leaderboard"
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap"
        >
          <Trophy className="h-3.5 w-3.5 text-sky-600" />
          Live Leaderboard
        </Link>
      }
    >
      {squad ? (
        <>
          {/* Squad KPI Strip */}
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <div className="rounded-xl border border-slate-200 bg-white p-5">
              <div className="text-xs font-medium text-slate-500">Current Squad Rank</div>
              <div className="mt-1 font-display text-3xl font-extrabold text-slate-900 tabular-nums">
                {squad.rank ? `#${squad.rank}` : 'Forming'}
              </div>
              <div className="mt-1 text-xs text-slate-500">
                {squad.qualifiesForRanking
                  ? 'Qualifies for ranked challenge (4–8 members)'
                  : `Needs ${Math.max(0, 4 - squad.memberCount)} more members to rank`}
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-5">
              <div className="text-xs font-medium text-slate-500">Team Hydration Score</div>
              <div className="mt-1 font-display text-3xl font-extrabold text-sky-700 tabular-nums">
                {squad.teamScore}%
              </div>
              <div className="mt-1 text-xs text-slate-500 tabular-nums">
                Fair average (capped 100% / member)
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-5">
              <div className="text-xs font-medium text-slate-500">Collective Water Today</div>
              <div className="mt-1 font-display text-3xl font-extrabold text-slate-900 tabular-nums">
                {squad.totalIntakeMl.toLocaleString()} ml
              </div>
              <div className="mt-1 text-xs text-slate-500 tabular-nums">
                Target {squad.collectiveTargetMl.toLocaleString()} ml
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-5">
              <div className="text-xs font-medium text-slate-500">Squad Streak & Invite</div>
              <div className="mt-1 flex items-center gap-2 font-display text-2xl font-extrabold text-slate-900 tabular-nums">
                <Flame className="h-5 w-5 text-amber-500" />
                {squad.teamStreak ?? 0}d
              </div>
              <button
                type="button"
                onClick={() => copyInviteCode(squad.inviteCode)}
                className="mt-1 inline-flex items-center gap-1.5 font-mono text-xs font-semibold text-sky-700 hover:text-sky-800"
              >
                {copiedCode ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                Code: {squad.inviteCode}
              </button>
            </div>
          </div>

          {/* Central Bottle Graphic + Squad Member Contributions */}
          <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-12">
            <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-5 flex flex-col justify-between">
              <div>
                <h2 className="font-display text-lg font-bold text-slate-900">
                  Your Contribution Bottle
                </h2>
                <p className="mt-0.5 text-xs text-slate-500 tabular-nums">
                  {user.name} · {todayStats.totalIntakeMl.toLocaleString()} /{' '}
                  {todayStats.baseGoalMl.toLocaleString()} ml ({todayStats.completionPct}%)
                </p>
              </div>

              <div className="my-6 flex justify-center">
                <WaterBottleGraphic
                  percentage={todayStats.completionPct}
                  intakeMl={todayStats.totalIntakeMl}
                  targetMl={todayStats.baseGoalMl}
                  rippleKey={rippleKey}
                />
              </div>

              <div className="space-y-2.5">
                <button
                  type="button"
                  disabled={isLogging}
                  onClick={() => handleQuickLog(500, 'bottle')}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-sky-600 px-4 py-3 text-sm font-semibold text-white hover:bg-sky-700 transition-colors disabled:opacity-60"
                >
                  <Droplets className="h-4 w-4" />
                  +500 ml Water Bottle
                </button>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={isLogging}
                    onClick={() => handleQuickLog(250, 'cup')}
                    className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-100 disabled:opacity-60"
                  >
                    +250 ml Cup
                  </button>
                  <button
                    type="button"
                    disabled={isLogging}
                    onClick={() => handleQuickLog(750, 'tumbler')}
                    className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-100 disabled:opacity-60"
                  >
                    +750 ml Tumbler
                  </button>
                </div>
              </div>
            </section>

            <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-7 flex flex-col justify-between">
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-4">
                  <div>
                    <h2 className="font-display text-lg font-bold text-slate-900">
                      {squad.teamName} Members
                    </h2>
                    <p className="text-xs text-slate-500">
                      Each teammate’s leaderboard contribution is capped at 100% of their daily goal.
                    </p>
                  </div>
                  <span className="font-mono text-xs font-semibold text-slate-600 tabular-nums">
                    {squad.memberCount} / 8 Members
                  </span>
                </div>

                <div className="mt-4 space-y-4">
                  {squad.members.map((member) => (
                    <div key={member.id} className="space-y-1.5">
                      <div className="flex items-center justify-between text-sm">
                        <div className="font-semibold text-slate-900">
                          {member.name}
                          {member.id === user.id && (
                            <span className="ml-2 text-xs font-medium text-sky-700">(You)</span>
                          )}
                        </div>
                        <div className="font-mono text-xs text-slate-600 tabular-nums">
                          {member.intakeMl.toLocaleString()} / {member.goalMl.toLocaleString()} ml ·{' '}
                          <span className="font-semibold text-slate-900">
                            {member.cappedContributionPct}%
                          </span>
                          {member.rawPct > 100 && (
                            <span className="ml-1 text-slate-400">({member.rawPct}% raw, capped)</span>
                          )}
                        </div>
                      </div>
                      <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            member.cappedContributionPct >= 100 ? 'bg-emerald-600' : 'bg-sky-600'
                          }`}
                          style={{ width: `${member.cappedContributionPct}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4">
                <span className="text-xs text-slate-500">
                  Team completion milestone: {squad.teamScore}% of 100% collective goal
                </span>
                <button
                  type="button"
                  disabled={submittingSquad}
                  onClick={handleLeaveSquad}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-red-50 hover:border-red-200 hover:text-red-700"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  Leave Squad
                </button>
              </div>
            </section>
          </div>
        </>
      ) : (
        <div className="rounded-2xl border border-slate-200 bg-white p-6">
          <div className="flex items-start gap-3">
            <Users className="h-5 w-5 text-sky-600 shrink-0 mt-0.5" />
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900">
                You are not currently in a squad
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                Join an existing 4–8 member squad with an invite code or create a new squad for your
                hostel wing, department, or study group.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Join or Create Squad Management */}
      <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <div className="flex items-center gap-2">
            <UserPlus className="h-4 w-4 text-sky-600" />
            <h2 className="font-display text-base font-bold text-slate-900">
              Join Squad via Invite Code
            </h2>
          </div>
          <p className="mt-1 text-xs text-slate-500">
            Campus invite codes: <code className="font-mono">HBLA26</code>,{' '}
            <code className="font-mono">HBLB26</code>, <code className="font-mono">AQUA26</code>,{' '}
            <code className="font-mono">HYDR26</code>. Max 8 members per squad.
          </p>
          <form onSubmit={handleJoinSquad} className="mt-4 flex gap-3">
            <input
              type="text"
              required
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
              placeholder="Enter 6-char invite code"
              className="flex-1 rounded-lg border border-slate-300 px-3.5 py-2 font-mono text-sm uppercase text-slate-900 focus:border-sky-600 focus:outline-none"
            />
            <button
              type="submit"
              disabled={submittingSquad}
              className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-60 whitespace-nowrap"
            >
              Join Squad
            </button>
          </form>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <div className="flex items-center gap-2">
            <Plus className="h-4 w-4 text-sky-600" />
            <h2 className="font-display text-base font-bold text-slate-900">Create New Squad</h2>
          </div>
          <p className="mt-1 text-xs text-slate-500">
            New squads start in forming mode until 4–8 members join to qualify for ranked challenges.
          </p>
          <form onSubmit={handleCreateSquad} className="mt-4 flex gap-3">
            <input
              type="text"
              required
              minLength={3}
              maxLength={40}
              value={newTeamName}
              onChange={(e) => setNewTeamName(e.target.value)}
              placeholder="e.g., Robotics Lab Crew"
              className="flex-1 rounded-lg border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-sky-600 focus:outline-none"
            />
            <button
              type="submit"
              disabled={submittingSquad}
              className="rounded-lg bg-sky-600 px-4 py-2 text-xs font-semibold text-white hover:bg-sky-700 disabled:opacity-60 whitespace-nowrap"
            >
              Create Squad
            </button>
          </form>
        </section>
      </div>

      {squadError && (
        <div
          role="alert"
          className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
        >
          {squadError}
        </div>
      )}
    </AppShell>
  );
}
