import React, { useCallback, useEffect, useState } from 'react';
import { Droplets, Flame, Sprout } from 'lucide-react';
import { AppShell } from '../components/AppShell';
import { PlantIllustration } from '../components/PlantIllustration';
import { useToast } from '../context/ToastContext';
import { ApiError, apiRequest } from '../lib/api';
import { PlantState, RankTransition } from '../types';

const GROWTH_STAGES = [
  { stage: 'wilting', num: 1, name: 'Wilting', rule: '0 logs past noon or <20% hydration' },
  { stage: 'sprout', num: 2, name: 'Fresh Sprout', rule: 'Morning moisture detected (<35%)' },
  { stage: 'growing', num: 3, name: 'Growing Sapling', rule: '35%–69% daily progress' },
  { stage: 'thriving', num: 4, name: 'Thriving Canopy', rule: '70%+ daily goal or steady streak' },
  { stage: 'blooming', num: 5, name: 'Peak Hydro-Fern', rule: '100% daily goal or 85%+ with 3d streak' },
];

export default function PlantPage() {
  const { pushToast, triggerCelebration } = useToast();
  const [plant, setPlant] = useState<PlantState | null>(null);
  const [loading, setLoading] = useState(true);
  const [watering, setWatering] = useState(false);

  const loadPlant = useCallback(async () => {
    try {
      const res = await apiRequest<{ plant: PlantState }>('/api/plant');
      setPlant(res.plant);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPlant();
  }, [loadPlant]);

  const handleWaterPlant = async (amountMl: number) => {
    if (watering) return;
    setWatering(true);
    try {
      const res = await apiRequest<{
        plant: PlantState;
        rankTransition: RankTransition | null;
      }>('/api/hydration/log', {
        method: 'POST',
        body: JSON.stringify({
          amountMl,
          drinkType: amountMl === 500 ? 'bottle' : 'cup',
          clientRequestId: `plant-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        }),
      });
      setPlant(res.plant);
      pushToast({
        title: `Watered +${amountMl} ml`,
        description: `Your plant is now ${res.plant.title} (${res.plant.healthLabel}).`,
        tone: 'success',
      });
      if (res.rankTransition?.improved) {
        triggerCelebration(res.rankTransition);
      }
    } catch (err) {
      pushToast({
        title: 'Could not log water',
        description: err instanceof ApiError ? err.message : 'Error',
        tone: 'error',
      });
    } finally {
      setWatering(false);
    }
  };

  if (loading || !plant) {
    return (
      <AppShell title="Virtual Plant Companion" subtitle="Loading botanical hydration state...">
        <div className="h-96 animate-pulse rounded-2xl border border-slate-200 bg-white" />
      </AppShell>
    );
  }

  return (
    <AppShell
      title="Virtual Plant Companion"
      subtitle="Reactive botanical stage computed directly from your daily hydration and streak consistency"
    >
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-7 flex flex-col items-center text-center">
          <div className="w-full flex items-center justify-between border-b border-slate-100 pb-4 text-left">
            <div>
              <h2 className="font-display text-xl font-bold text-slate-900">{plant.title}</h2>
              <p className="text-xs text-slate-500">
                Stage {plant.stageNumber} of 5 · Health: {plant.healthLabel}
              </p>
            </div>
            <Sprout className="h-5 w-5 text-emerald-600" />
          </div>

          <div className="my-6">
            <PlantIllustration plant={plant} size="lg" />
          </div>

          <p className="max-w-md text-sm text-slate-600">{plant.statusMessage}</p>

          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <button
              type="button"
              disabled={watering}
              onClick={() => handleWaterPlant(250)}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm font-semibold text-slate-900 hover:bg-slate-100 disabled:opacity-60"
            >
              <Droplets className="h-4 w-4 text-sky-600" />
              Water +250 ml
            </button>
            <button
              type="button"
              disabled={watering}
              onClick={() => handleWaterPlant(500)}
              className="inline-flex items-center gap-2 rounded-lg bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-sky-700 disabled:opacity-60"
            >
              <Droplets className="h-4 w-4" />
              Water +500 ml Bottle
            </button>
          </div>
        </section>

        <div className="space-y-6 lg:col-span-5">
          <section className="rounded-2xl border border-slate-200 bg-white p-6">
            <h3 className="font-display text-base font-bold text-slate-900">
              Live Botanical Drivers
            </h3>
            <dl className="mt-4 space-y-3 text-sm tabular-nums">
              <div className="flex items-center justify-between">
                <dt className="text-slate-600">Today’s completion</dt>
                <dd className="font-mono font-bold text-slate-900">
                  {plant.todayPct}% ({plant.todayIntakeMl.toLocaleString()} / {plant.dailyGoalMl.toLocaleString()} ml)
                </dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-slate-600">Active streak</dt>
                <dd className="inline-flex items-center gap-1 font-mono font-bold text-slate-900">
                  <Flame className="h-4 w-4 text-amber-500" />
                  {plant.currentStreak} days
                </dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-slate-600">7-day consistency</dt>
                <dd className="font-mono font-bold text-slate-900">{plant.weeklyAvgPct}%</dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-slate-600">Computed vitality index</dt>
                <dd className="font-mono font-bold text-emerald-700">{plant.hydrationFactor} / 100</dd>
              </div>
            </dl>
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white p-6">
            <h3 className="font-display text-base font-bold text-slate-900">Growth Stages</h3>
            <div className="mt-4 space-y-2.5">
              {GROWTH_STAGES.map((s) => {
                const active = plant.stage === s.stage;
                return (
                  <div
                    key={s.stage}
                    className={`rounded-xl border px-3.5 py-2.5 text-xs ${
                      active
                        ? 'border-emerald-300 bg-emerald-50/70 text-slate-900'
                        : 'border-slate-100 bg-slate-50 text-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between font-semibold">
                      <span>
                        0{s.num}. {s.name}
                      </span>
                      {active && <span className="text-emerald-700">Current</span>}
                    </div>
                    <div className="mt-0.5 text-slate-500">{s.rule}</div>
                  </div>
                );
              })}
            </div>
          </section>
        </div>
      </div>
    </AppShell>
  );
}
