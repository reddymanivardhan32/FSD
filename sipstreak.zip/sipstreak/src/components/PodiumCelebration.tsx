import React from 'react';
import { Award, ArrowUpRight, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '../context/ToastContext';

export function PodiumCelebration() {
  const { celebration, clearCelebration } = useToast();
  if (!celebration) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/55 p-4 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="podium-celebration-title"
    >
      <div className="relative w-full max-w-lg rounded-2xl border border-slate-200 bg-white p-6 shadow-xl">
        <button
          type="button"
          onClick={clearCelebration}
          aria-label="Close podium celebration"
          className="absolute right-4 top-4 rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700 focus-visible:outline-2 focus-visible:outline-sky-600"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-sky-50 text-sky-600">
            <Award className="h-6 w-6" />
          </div>
          <p className="text-xs font-semibold tracking-wide text-sky-600">
            Leaderboard Rank Update
          </p>
          <h2
            id="podium-celebration-title"
            className="mt-1 font-display text-2xl font-bold text-slate-900"
          >
            {celebration.becameFirst
              ? `${celebration.teamName ?? 'Your Squad'} claimed 1st Place`
              : `${celebration.teamName ?? 'Your Squad'} climbed to #${celebration.newRank}`}
          </h2>
          <p className="mt-2 text-sm text-slate-600 tabular-nums">
            Moved from Rank #{celebration.previousRank} ({celebration.previousScore ?? '—'}%) to Rank #
            {celebration.newRank} ({celebration.newScore ?? '—'}%).
          </p>
        </div>

        {/* Animated Podium Visualization */}
        <div className="mt-6 flex items-end justify-center gap-3 rounded-xl border border-slate-100 bg-slate-50 px-6 pt-8 pb-4">
          <div className="flex w-24 flex-col items-center">
            <span className="mb-2 text-xs font-medium text-slate-500">2nd</span>
            <div className="flex h-16 w-full items-center justify-center rounded-t-lg bg-slate-300 font-display text-sm font-bold text-slate-800">
              #2
            </div>
          </div>
          <div className="flex w-28 flex-col items-center">
            <span className="mb-2 text-xs font-semibold text-sky-700">
              {celebration.becameFirst ? celebration.teamName : '1st Place'}
            </span>
            <div className="flex h-24 w-full items-center justify-center rounded-t-lg bg-sky-600 font-display text-lg font-bold text-white shadow-sm transition-transform duration-300">
              #1
            </div>
          </div>
          <div className="flex w-24 flex-col items-center">
            <span className="mb-2 text-xs font-medium text-slate-500">3rd</span>
            <div className="flex h-12 w-full items-center justify-center rounded-t-lg bg-slate-200 font-display text-sm font-bold text-slate-700">
              #3
            </div>
          </div>
        </div>

        <div className="mt-6 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={clearCelebration}
            className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
          >
            Keep Hydrating
          </button>
          <Link
            to="/leaderboard"
            onClick={clearCelebration}
            className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 whitespace-nowrap shrink-0"
          >
            View Leaderboard
            <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
