import React from 'react';

interface HydrationRingProps {
  percentage: number;
  intakeMl: number;
  targetMl: number;
  remainingMl: number;
}

export function HydrationRing({
  percentage,
  intakeMl,
  targetMl,
  remainingMl,
}: HydrationRingProps) {
  const capped = Math.max(0, Math.min(100, percentage));
  const radius = 66;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (capped / 100) * circumference;

  return (
    <div className="flex flex-col items-center">
      <div className="relative h-44 w-44">
        <svg viewBox="0 0 160 160" className="h-full w-full -rotate-90">
          <circle
            cx="80"
            cy="80"
            r={radius}
            fill="none"
            stroke="#E2E8F0"
            strokeWidth="12"
          />
          <circle
            cx="80"
            cy="80"
            r={radius}
            fill="none"
            stroke={capped >= 100 ? '#059669' : '#0284C7'}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            style={{ transition: 'stroke-dashoffset 500ms cubic-bezier(0.16, 1, 0.3, 1)' }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="font-display text-3xl font-bold tracking-tight text-slate-900 tabular-nums">
            {capped}%
          </span>
          <span className="text-xs font-medium text-slate-500 tabular-nums">
            {intakeMl.toLocaleString()} / {targetMl.toLocaleString()} ml
          </span>
        </div>
      </div>

      <div className="mt-3 text-center text-xs text-slate-600 tabular-nums">
        {remainingMl > 0
          ? `${remainingMl.toLocaleString()} ml remaining for today’s base goal`
          : 'Daily hydration target completed'}
      </div>
    </div>
  );
}
