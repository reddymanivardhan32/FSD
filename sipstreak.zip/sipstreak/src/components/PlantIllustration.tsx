import React from 'react';
import { PlantState } from '../types';

interface PlantIllustrationProps {
  plant: PlantState;
  size?: 'sm' | 'lg';
}

export function PlantIllustration({ plant, size = 'lg' }: PlantIllustrationProps) {
  const isWilting = plant.stage === 'wilting';
  const showMidLeaves = plant.stageNumber >= 3;
  const showUpperCanopy = plant.stageNumber >= 4;
  const showBloom = plant.stage === 'blooming';

  const leafColor = isWilting ? '#CA8A04' : '#10B981';
  const darkLeafColor = isWilting ? '#A16207' : '#059669';
  const stemColor = isWilting ? '#92400E' : '#047857';

  return (
    <div className="relative flex items-center justify-center select-none">
      <svg
        viewBox="0 0 220 220"
        className={size === 'sm' ? 'h-32 w-32' : 'h-60 w-60'}
        role="img"
        aria-label={`${plant.title} (${plant.healthLabel})`}
      >
        {/* Soft moisture halo */}
        <circle
          cx="110"
          cy="108"
          r="82"
          fill={isWilting ? '#FEF3C7' : '#E0F2FE'}
          opacity="0.55"
        />

        {/* Ambient moisture droplets when hydrating */}
        {!isWilting && (
          <g className="animate-droplet">
            <path d="M52,72 C52,66 56,60 56,60 C56,60 60,66 60,72 A4,4 0 1,1 52,72 Z" fill="#38BDF8" opacity="0.7" />
            <path d="M164,62 C164,57 167,52 167,52 C167,52 170,57 170,62 A3,3 0 1,1 164,62 Z" fill="#0EA5E9" opacity="0.6" />
          </g>
        )}

        {/* Ceramic terracotta-slate pot */}
        <polygon points="74,158 146,158 136,198 84,198" fill="#0F172A" />
        <rect x="68" y="148" width="84" height="14" rx="4" fill="#1E293B" />
        <ellipse cx="110" cy="148" rx="34" ry="5" fill={isWilting ? '#78350F' : '#065F46'} opacity="0.55" />

        {/* Plant stem and leaves */}
        <g className={isWilting ? '' : 'animate-plant-sway'} style={{ transformOrigin: '110px 148px' }}>
          {/* Main stem */}
          {isWilting ? (
            <path d="M110,148 Q106,120 124,108" fill="none" stroke={stemColor} strokeWidth="5" strokeLinecap="round" />
          ) : (
            <path
              d={
                plant.stageNumber >= 4
                  ? 'M110,148 Q108,110 110,66'
                  : plant.stageNumber === 3
                    ? 'M110,148 Q109,118 110,88'
                    : 'M110,148 Q110,130 110,114'
              }
              fill="none"
              stroke={stemColor}
              strokeWidth="5"
              strokeLinecap="round"
            />
          )}

          {/* Base leaves */}
          {isWilting ? (
            <>
              <path d="M113,124 Q94,132 88,144 Q104,138 113,124 Z" fill={leafColor} />
              <path d="M122,109 Q142,118 146,132 Q128,124 122,109 Z" fill={darkLeafColor} />
            </>
          ) : (
            <>
              <path d="M110,126 C92,126 78,114 74,100 C92,102 104,112 110,126 Z" fill={leafColor} />
              <path d="M110,122 C128,122 142,110 146,96 C128,98 116,108 110,122 Z" fill={darkLeafColor} />
            </>
          )}

          {/* Stage 3+ mid leaves */}
          {showMidLeaves && !isWilting && (
            <>
              <path d="M110,98 C88,96 72,82 68,66 C88,68 102,80 110,98 Z" fill={darkLeafColor} />
              <path d="M110,94 C132,92 148,78 152,62 C132,64 118,76 110,94 Z" fill={leafColor} />
            </>
          )}

          {/* Stage 4+ upper canopy */}
          {showUpperCanopy && !isWilting && (
            <>
              <path d="M110,74 C94,68 84,54 84,42 C98,46 106,58 110,74 Z" fill={leafColor} />
              <path d="M110,74 C126,68 136,54 136,42 C122,46 114,58 110,74 Z" fill={darkLeafColor} />
            </>
          )}

          {/* Stage 5 Blooming Hydro-Fern crown */}
          {showBloom && !isWilting && (
            <g transform="translate(110, 44)">
              <circle cx="0" cy="0" r="10" fill="#38BDF8" />
              <circle cx="-11" cy="3" r="7" fill="#0EA5E9" />
              <circle cx="11" cy="3" r="7" fill="#0EA5E9" />
              <circle cx="0" cy="-10" r="7" fill="#7DD3FC" />
              <circle cx="0" cy="0" r="4.5" fill="#FFFFFF" />
            </g>
          )}
        </g>
      </svg>
    </div>
  );
}
