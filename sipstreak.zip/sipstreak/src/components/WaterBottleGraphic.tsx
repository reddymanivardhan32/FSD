import React from 'react';

interface WaterBottleGraphicProps {
  percentage: number;
  intakeMl: number;
  targetMl: number;
  rippleKey: number;
  compact?: boolean;
}

export function WaterBottleGraphic({
  percentage,
  intakeMl,
  targetMl,
  rippleKey,
  compact = false,
}: WaterBottleGraphicProps) {
  const clamped = Math.max(0, Math.min(100, percentage));
  // Bottle interior spans y=54 to y=268 (height=214)
  const fillHeight = (clamped / 100) * 214;
  const surfaceY = 268 - fillHeight;

  return (
    <div className="relative flex flex-col items-center justify-center select-none">
      {rippleKey > 0 && (
        <div
          key={rippleKey}
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 flex items-center justify-center"
        >
          <div className="h-48 w-36 rounded-full border-2 border-sky-400/70 animate-bottle-ripple" />
        </div>
      )}

      <svg
        viewBox="0 0 180 300"
        className={compact ? 'h-52 w-32' : 'h-64 w-40'}
        role="img"
        aria-label={`Water bottle filled to ${clamped}% (${intakeMl} of ${targetMl} ml)`}
      >
        <defs>
          <linearGradient id="bottleWaterGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#38BDF8" />
            <stop offset="55%" stopColor="#0284C7" />
            <stop offset="100%" stopColor="#0C4A6E" />
          </linearGradient>
          <linearGradient id="bottleWaterBack" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#7DD3FC" stopOpacity="0.65" />
            <stop offset="100%" stopColor="#0369A1" stopOpacity="0.7" />
          </linearGradient>
          <clipPath id="bottleInteriorClip">
            <path d="M52,58 C44,64 40,74 40,86 L40,254 C40,264 48,272 58,272 L122,272 C132,272 140,264 140,254 L140,86 C140,74 136,64 128,58 L118,50 L118,38 L62,38 L62,50 Z" />
          </clipPath>
        </defs>

        {/* Bottle cap */}
        <rect x="64" y="14" width="52" height="16" rx="4" fill="#0B1F3A" />
        <rect x="60" y="28" width="60" height="8" rx="3" fill="#1E3A5F" />

        {/* Bottle glass backdrop */}
        <path
          d="M52,58 C44,64 40,74 40,86 L40,254 C40,264 48,272 58,272 L122,272 C132,272 140,264 140,254 L140,86 C140,74 136,64 128,58 L118,50 L118,38 L62,38 L62,50 Z"
          fill="#F0F9FF"
        />

        {/* Animated water inside clipped bottle interior */}
        <g clipPath="url(#bottleInteriorClip)">
          {clamped > 0 && (
            <g style={{ transform: `translateY(${surfaceY}px)`, transition: 'transform 500ms cubic-bezier(0.16, 1, 0.3, 1)' }}>
              {/* Back wave */}
              <g className="animate-wave-back">
                <path
                  d="M0,0 Q30,-8 60,0 T120,0 T180,0 T240,0 T300,0 T360,0 L360,260 L0,260 Z"
                  fill="url(#bottleWaterBack)"
                />
              </g>
              {/* Front wave */}
              <g className="animate-wave-front">
                <path
                  d="M0,3 Q30,11 60,3 T120,3 T180,3 T240,3 T300,3 T360,3 L360,260 L0,260 Z"
                  fill="url(#bottleWaterGrad)"
                />
              </g>
            </g>
          )}

          {/* Specular glass reflection */}
          <rect x="49" y="80" width="8" height="170" rx="4" fill="#FFFFFF" opacity="0.32" />
        </g>

        {/* Measurement graduation marks */}
        {[
          { y: 100, label: '75%' },
          { y: 155, label: '50%' },
          { y: 210, label: '25%' },
        ].map((mark) => (
          <g key={mark.label}>
            <line x1="124" y1={mark.y} x2="136" y2={mark.y} stroke="#0B1F3A" strokeOpacity="0.28" strokeWidth="1.5" />
          </g>
        ))}

        {/* Bottle outer contour */}
        <path
          d="M52,58 C44,64 40,74 40,86 L40,254 C40,264 48,272 58,272 L122,272 C132,272 140,264 140,254 L140,86 C140,74 136,64 128,58 L118,50 L118,38 L62,38 L62,50 Z"
          fill="none"
          stroke="#0B1F3A"
          strokeWidth="2.5"
          strokeOpacity="0.85"
        />

        {/* Percentage readout centered cleanly */}
        <text
          x="90"
          y="168"
          textAnchor="middle"
          className="font-display font-bold tabular-nums"
          fontSize="26"
          fill={clamped >= 48 ? '#FFFFFF' : '#0B1F3A'}
        >
          {clamped}%
        </text>
        <text
          x="90"
          y="188"
          textAnchor="middle"
          className="font-mono tabular-nums"
          fontSize="11"
          fill={clamped >= 42 ? '#E0F2FE' : '#475569'}
        >
          {intakeMl} ml
        </text>
      </svg>
    </div>
  );
}
