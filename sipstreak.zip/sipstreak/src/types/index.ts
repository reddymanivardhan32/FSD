export interface User {
  id: string;
  name: string;
  email: string;
  weightKg: number;
  dailyGoalMl: number;
  squadId: string | null;
  isDemo: boolean;
  createdAt: string;
}

export interface HydrationLog {
  id: string;
  amountMl: number;
  drinkType: string;
  timestampUtc: string;
}

export interface CaffeineLog {
  id: string;
  beverageType: 'coffee' | 'energy_drink';
  offsetMl: number;
  timestampUtc: string;
}

export interface TodayStats {
  todayDate: string;
  baseGoalMl: number;
  caffeineCount: number;
  caffeineOffsetMl: number;
  adjustedGoalMl: number;
  totalIntakeMl: number;
  remainingBaseMl: number;
  remainingAdjustedMl: number;
  completionPct: number;
  rawPct: number;
  adjustedCompletionPct: number;
  todayLogs: HydrationLog[];
  todayCaffeineLogs: CaffeineLog[];
}

export interface SquadMemberProgress {
  id: string;
  name: string;
  intakeMl: number;
  goalMl: number;
  rawPct: number;
  cappedContributionPct: number;
}

export interface SquadDayHistory {
  date: string;
  totalIntakeMl: number;
  teamScore: number;
  rawTeamScore: number;
}

export interface SquadSummary {
  squadId: string;
  teamName: string;
  inviteCode: string;
  memberCount: number;
  qualifiesForRanking: boolean;
  teamScore: number;
  rawTeamScore: number;
  totalIntakeMl: number;
  collectiveTargetMl: number;
  members: SquadMemberProgress[];
  previousRank: number | null;
  rank: number | null;
  rankDelta: number;
  teamStreak?: number;
  history?: SquadDayHistory[];
}

export interface LeaderboardResponse {
  date: string;
  rankedTeams: SquadSummary[];
  formingTeams: SquadSummary[];
  mySquadId: string | null;
}

export interface PlantState {
  stage: 'wilting' | 'sprout' | 'growing' | 'thriving' | 'blooming';
  stageNumber: number;
  title: string;
  healthLabel: string;
  statusMessage: string;
  hydrationFactor: number;
  todayPct: number;
  todayIntakeMl: number;
  dailyGoalMl: number;
  currentStreak: number;
  weeklyAvgPct: number;
  logsTodayCount: number;
}

export interface Achievement {
  id: string;
  code: string;
  title: string;
  description: string;
  unlockedAt: string;
}

export interface ReminderSettings {
  enabled: number | boolean;
  startHour: number;
  endHour: number;
  intervalMinutes: number;
  lastNotifiedAt: string | null;
}

export interface DashboardPayload {
  user: User;
  todayStats: TodayStats;
  streak: {
    currentStreak: number;
    longestStreak: number;
    weeklyAvgPct: number;
  };
  squad: SquadSummary | null;
  plant: PlantState;
  achievements: Achievement[];
  reminders: ReminderSettings;
}

export interface RankTransition {
  previousRank: number | null;
  newRank: number | null;
  previousScore?: number | null;
  newScore?: number | null;
  improved: boolean;
  becameFirst: boolean;
  teamName: string | null;
}

export interface PersonalDayHistory {
  date: string;
  intakeMl: number;
  goalMl: number;
  percentage: number;
  rawPercentage: number;
  metGoal: boolean;
}

export interface HistoryPayload {
  personal: {
    currentStreak: number;
    longestStreak: number;
    lastCompletedDate: string | null;
    weeklyAvgPct: number;
    weeklyTotalMl: number;
    days: PersonalDayHistory[];
  };
  squad: {
    squadId: string;
    teamName: string;
    teamStreak: number;
    history: SquadDayHistory[];
  } | null;
}

export interface FountainLocation {
  id: string;
  name: string;
  building: string;
  floor: string;
  latitude: number;
  longitude: number;
  waterType: 'chilled_filtered' | 'bottle_refill' | 'standard';
  status: 'sample_active' | 'sample_maintenance';
  notes: string;
  isSample: boolean;
}
