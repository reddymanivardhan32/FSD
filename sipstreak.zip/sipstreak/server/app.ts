import Database from 'better-sqlite3';
import express, { Express } from 'express';
import { createDatabase } from './db';
import { attachTimezone } from './middleware/auth';
import { createAuthRouter } from './routes/auth';
import { createFeaturesRouter } from './routes/features';
import { createHydrationRouter } from './routes/hydration';
import { createSquadsRouter } from './routes/squads';
import { ensureSeeded } from './seed';

export interface AppInstance {
  app: Express;
  db: Database.Database;
}

export function createApp(options?: { dbPath?: string }): AppInstance {
  const db = createDatabase(options?.dbPath);
  ensureSeeded(db);

  const app = express();
  app.use(express.json({ limit: '1mb' }));
  app.use(attachTimezone);

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'sipstreak-api' });
  });

  app.use('/api/auth', createAuthRouter(db));
  app.use('/api/hydration', createHydrationRouter(db));
  app.use('/api/squads', createSquadsRouter(db));
  app.use('/api', createFeaturesRouter(db));

  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  return { app, db };
}
