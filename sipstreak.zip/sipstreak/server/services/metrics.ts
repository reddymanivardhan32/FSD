import Database from 'better-sqlite3';
import crypto from 'crypto';
import {
  CAFFEINE_OFFSET_ML,
  MAX_SQUAD_MEMBERS,
  MIN_SQUAD_MEMBERS,
  calculateCappedHydrationPct,
  calculateFairTeamScore,
  calculateRawHydrationPct,
  calculateStreak,
  computePlantState,
  getLastNDates,
  getLocalDateString,
  getLocalHour,
} from '../utils/hydration';

export interface UserRow {
  id: string;
  name: string;
  email: string;
  password_hash: string;
  weight_kg: number;
  daily_goal_ml: number;
  squad_id: string | null;
  is_demo: number;
  created_at: string;
}

export interface SquadRow {
  id: string;
  team_name: string;
  invite_code: string;
  created_by: string | null;
  created_at: string;
}

export interface HydrationLogRow {
  id: string;
  user_id: string;
  amount_ml: number;
  drink_type: string;
  client_request_id: string | null;
  timestamp_utc: string;
}

export interface CaffeineLogRow {
  id: string;
  user_id: string;
  beverage_type: 'coffee' | 'energy_drink';
  offset_ml: number;
  timestamp_utc: string;
}

export function sanitizeUser(user: UserRow) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    weightKg: user.weight_kg,
    dailyGoalMl: user.daily_goal_ml,
    squadId: user.squad_id,
    isDemo: Boolean(user.is_demo),
    createdAt: user.created_at,
  };
}

export function getUserTodayStats(db: Database.Database, user: UserRow, timeZone: string) {
  const todayStr = getLocalDateString(new Date(), timeZone);
  // Query last 48h window from DB then filter strictly by local calendar date in user's timezone
  const cutoff = new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString();

  const hydrationLogs = db
    .prepare(
      `SELECT id, user_id, amount_ml, drink_type, client_request_id, timestamp_utc
       FROM hydration_logs
       WHERE user_id = ? AND timestamp_utc >= ?
       ORDER BY timestamp_utc DESC`,
    )
    .all(user.id, cutoff) as HydrationLogRow[];

  const todayLogs = hydrationLogs.filter(
    (log) => getLocalDateString(log.timestamp_utc, timeZone) === todayStr,
  );
  const totalIntakeMl = todayLogs.reduce((sum, l) => sum + l.amount_ml, 0);

  const caffeineLogsAll = db
    .prepare(
      `SELECT id, user_id, beverage_type, offset_ml, timestamp_utc
       FROM caffeine_logs
       WHERE user_id = ? AND timestamp_utc >= ?
       ORDER BY timestamp_utc DESC`,
    )
    .all(user.id, cutoff) as CaffeineLogRow[];

  const todayCaffeineLogs = caffeineLogsAll.filter(
    (log) => getLocalDateString(log.timestamp_utc, timeZone) === todayStr,
  );
  const caffeineCount = todayCaffeineLogs.length;
  const caffeineOffsetMl = caffeineCount * CAFFEINE_OFFSET_ML;

  const baseGoalMl = user.daily_goal_ml;
  const adjustedGoalMl = baseGoalMl + caffeineOffsetMl;
  const remainingBaseMl = Math.max(0, baseGoalMl - totalIntakeMl);
  const remainingAdjustedMl = Math.max(0, adjustedGoalMl - totalIntakeMl);

  const completionPct = calculateCappedHydrationPct(totalIntakeMl, baseGoalMl);
  const rawPct = calculateRawHydrationPct(totalIntakeMl, baseGoalMl);
  const adjustedCompletionPct = calculateCappedHydrationPct(totalIntakeMl, adjustedGoalMl);

  return {
    todayDate: todayStr,
    baseGoalMl,
    caffeineCount,
    caffeineOffsetMl,
    adjustedGoalMl,
    totalIntakeMl,
    remainingBaseMl,
    remainingAdjustedMl,
    completionPct,
    rawPct,
    adjustedCompletionPct,
    todayLogs: todayLogs.map((l) => ({
      id: l.id,
      amountMl: l.amount_ml,
      drinkType: l.drink_type,
      timestampUtc: l.timestamp_utc,
    })),
    todayCaffeineLogs: todayCaffeineLogs.map((c) => ({
      id: c.id,
      beverageType: c.beverage_type,
      offsetMl: c.offset_ml,
      timestampUtc: c.timestamp_utc,
    })),
  };
}

export function getUserStreakAndHistory(db: Database.Database, user: UserRow, timeZone: string) {
  const dates7 = getLastNDates(7, timeZone);
  const cutoff = new Date(Date.now() - 32 * 24 * 60 * 60 * 1000).toISOString();

  const logs = db
    .prepare(
      `SELECT amount_ml, timestamp_utc
       FROM hydration_logs
       WHERE user_id = ? AND timestamp_utc >= ?`,
    )
    .all(user.id, cutoff) as Array<{ amount_ml: number; timestamp_utc: string }>;

  const dailyTotals: Record<string, number> = {};
  for (const l of logs) {
    const dStr = getLocalDateString(l.timestamp_utc, timeZone);
    dailyTotals[dStr] = (dailyTotals[dStr] ?? 0) + l.amount_ml;
  }

  const streakInfo = calculateStreak(dailyTotals, user.daily_goal_ml, timeZone);

  db.prepare(
    `INSERT INTO user_streaks (user_id, current_streak, longest_streak, last_completed_date, updated_at)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET
       current_streak = excluded.current_streak,
       longest_streak = MAX(user_streaks.longest_streak, excluded.longest_streak),
       last_completed_date = excluded.last_completed_date,
       updated_at = excluded.updated_at`,
  ).run(
    user.id,
    streakInfo.currentStreak,
    streakInfo.longestStreak,
    streakInfo.lastCompletedDate,
    new Date().toISOString(),
  );

  const days = dates7.map((dateStr) => {
    const intakeMl = dailyTotals[dateStr] ?? 0;
    const pct = calculateCappedHydrationPct(intakeMl, user.daily_goal_ml);
    return {
      date: dateStr,
      intakeMl,
      goalMl: user.daily_goal_ml,
      percentage: pct,
      rawPercentage: calculateRawHydrationPct(intakeMl, user.daily_goal_ml),
      metGoal: intakeMl >= user.daily_goal_ml,
    };
  });

  const weeklyAvgPct = Math.round(days.reduce((s, d) => s + d.percentage, 0) / days.length);
  const weeklyTotalMl = days.reduce((s, d) => s + d.intakeMl, 0);

  return {
    ...streakInfo,
    weeklyAvgPct,
    weeklyTotalMl,
    days,
  };
}

export function evaluateAchievements(
  db: Database.Database,
  user: UserRow,
  todayIntakeMl: number,
  currentStreak: number,
  squadRank: number | null,
) {
  const candidates: Array<{ code: string; title: string; description: string; met: boolean }> = [
    {
      code: 'FIRST_SIP',
      title: 'First Hydro Sip',
      description: 'Logged your first water intake record.',
      met: todayIntakeMl > 0,
    },
    {
      code: 'DAILY_GOAL_100',
      title: 'Daily Goal Reached',
      description: 'Reached 100% of your daily hydration target.',
      met: todayIntakeMl >= user.daily_goal_ml,
    },
    {
      code: 'STREAK_3',
      title: 'Three-Day Flow',
      description: 'Maintained a 3-day consecutive hydration streak.',
      met: currentStreak >= 3,
    },
    {
      code: 'SQUAD_LEADER',
      title: 'Campus Pacesetter',
      description: 'Part of a qualifying squad ranked #1 on the leaderboard.',
      met: squadRank === 1,
    },
  ];

  const now = new Date().toISOString();
  const insert = db.prepare(
    `INSERT OR IGNORE INTO achievements (id, user_id, code, title, description, unlocked_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
  );

  for (const c of candidates) {
    if (c.met) {
      insert.run(crypto.randomUUID(), user.id, c.code, c.title, c.description, now);
    }
  }

  return db
    .prepare(
      `SELECT id, code, title, description, unlocked_at as unlockedAt
       FROM achievements
       WHERE user_id = ?
       ORDER BY unlocked_at DESC`,
    )
    .all(user.id);
}

export function computeLeaderboard(db: Database.Database, timeZone: string) {
  const todayStr = getLocalDateString(new Date(), timeZone);
  const dates7 = getLastNDates(7, timeZone);
  const yesterdayStr = dates7[dates7.length - 2];
  const cutoff = new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString();

  const squads = db
    .prepare(`SELECT id, team_name, invite_code, created_at FROM hydration_squads ORDER BY created_at ASC`)
    .all() as SquadRow[];

  const users = db
    .prepare(`SELECT id, name, weight_kg, daily_goal_ml, squad_id FROM users WHERE squad_id IS NOT NULL`)
    .all() as Array<{ id: string; name: string; weight_kg: number; daily_goal_ml: number; squad_id: string }>;

  const recentLogs = db
    .prepare(`SELECT user_id, amount_ml, timestamp_utc FROM hydration_logs WHERE timestamp_utc >= ?`)
    .all(cutoff) as Array<{ user_id: string; amount_ml: number; timestamp_utc: string }>;

  const todayUserTotals: Record<string, number> = {};
  for (const log of recentLogs) {
    if (getLocalDateString(log.timestamp_utc, timeZone) === todayStr) {
      todayUserTotals[log.user_id] = (todayUserTotals[log.user_id] ?? 0) + log.amount_ml;
    }
  }

  // Fetch yesterday's saved ranks for rank delta calculation
  const yesterdayScores = db
    .prepare(`SELECT squad_id, rank, team_score FROM daily_team_scores WHERE date = ?`)
    .all(yesterdayStr) as Array<{ squad_id: string; rank: number; team_score: number }>;
  const prevRankMap = new Map(yesterdayScores.map((r) => [r.squad_id, r.rank]));

  const evaluated = squads.map((squad) => {
    const members = users.filter((u) => u.squad_id === squad.id);
    const memberSnapshots = members.map((m) => {
      const intakeMl = todayUserTotals[m.id] ?? 0;
      const rawPct = calculateRawHydrationPct(intakeMl, m.daily_goal_ml);
      const cappedContributionPct = Math.min(rawPct, 100);
      return {
        id: m.id,
        name: m.name,
        intakeMl,
        goalMl: m.daily_goal_ml,
        rawPct,
        cappedContributionPct,
      };
    });

    const fair = calculateFairTeamScore(
      memberSnapshots.map((m) => ({ intakeMl: m.intakeMl, goalMl: m.goalMl })),
    );
    const totalIntakeMl = memberSnapshots.reduce((sum, m) => sum + m.intakeMl, 0);
    const collectiveTargetMl = memberSnapshots.reduce((sum, m) => sum + m.goalMl, 0);
    const qualifies = members.length >= MIN_SQUAD_MEMBERS && members.length <= MAX_SQUAD_MEMBERS;

    return {
      squadId: squad.id,
      teamName: squad.team_name,
      inviteCode: squad.invite_code,
      memberCount: members.length,
      qualifiesForRanking: qualifies,
      teamScore: fair.roundedScore,
      rawTeamScore: fair.rawScore,
      totalIntakeMl,
      collectiveTargetMl,
      members: memberSnapshots,
      previousRank: prevRankMap.get(squad.id) ?? null,
    };
  });

  // Sort qualifying teams by rawTeamScore desc, then totalIntakeMl desc, then teamName asc
  const qualifyingTeams = evaluated
    .filter((t) => t.qualifiesForRanking)
    .sort((a, b) => {
      if (b.rawTeamScore !== a.rawTeamScore) return b.rawTeamScore - a.rawTeamScore;
      if (b.totalIntakeMl !== a.totalIntakeMl) return b.totalIntakeMl - a.totalIntakeMl;
      return a.teamName.localeCompare(b.teamName);
    })
    .map((t, idx) => {
      const rank = idx + 1;
      const rankDelta = t.previousRank !== null ? t.previousRank - rank : 0;
      return {
        ...t,
        rank,
        rankDelta,
      };
    });

  // Persist today's snapshot into daily_team_scores
  const upsertDailyScore = db.prepare(
    `INSERT INTO daily_team_scores (id, squad_id, date, total_intake_ml, team_score, rank)
     VALUES (?, ?, ?, ?, ?, ?)
     ON CONFLICT(squad_id, date) DO UPDATE SET
       total_intake_ml = excluded.total_intake_ml,
       team_score = excluded.team_score,
       rank = excluded.rank`,
  );

  for (const team of qualifyingTeams) {
    upsertDailyScore.run(
      crypto.randomUUID(),
      team.squadId,
      todayStr,
      team.totalIntakeMl,
      team.rawTeamScore,
      team.rank,
    );
  }

  const formingTeams = evaluated
    .filter((t) => !t.qualifiesForRanking)
    .map((t) => ({
      ...t,
      rank: null as number | null,
      rankDelta: 0,
    }));

  return {
    date: todayStr,
    rankedTeams: qualifyingTeams,
    formingTeams,
  };
}

export function getSquadDetails(db: Database.Database, squadId: string, timeZone: string) {
  const leaderboard = computeLeaderboard(db, timeZone);
  const found =
    leaderboard.rankedTeams.find((t) => t.squadId === squadId) ??
    leaderboard.formingTeams.find((t) => t.squadId === squadId) ??
    null;

  if (!found) return null;

  // Compute squad 7-day history from daily_team_scores or real logs
  const dates7 = getLastNDates(7, timeZone);
  const cutoff = new Date(Date.now() - 9 * 24 * 60 * 60 * 1000).toISOString();
  const members = db
    .prepare(`SELECT id, daily_goal_ml FROM users WHERE squad_id = ?`)
    .all(squadId) as Array<{ id: string; daily_goal_ml: number }>;

  const memberIds = members.map((m) => m.id);
  let logs: Array<{ user_id: string; amount_ml: number; timestamp_utc: string }> = [];
  if (memberIds.length > 0) {
    const placeholders = memberIds.map(() => '?').join(',');
    logs = db
      .prepare(
        `SELECT user_id, amount_ml, timestamp_utc
         FROM hydration_logs
         WHERE user_id IN (${placeholders}) AND timestamp_utc >= ?`,
      )
      .all(...memberIds, cutoff) as Array<{ user_id: string; amount_ml: number; timestamp_utc: string }>;
  }

  const history = dates7.map((dateStr) => {
    const userDayTotals: Record<string, number> = {};
    let dayTotalMl = 0;
    for (const l of logs) {
      if (getLocalDateString(l.timestamp_utc, timeZone) === dateStr) {
        userDayTotals[l.user_id] = (userDayTotals[l.user_id] ?? 0) + l.amount_ml;
        dayTotalMl += l.amount_ml;
      }
    }
    const fair = calculateFairTeamScore(
      members.map((m) => ({ intakeMl: userDayTotals[m.id] ?? 0, goalMl: m.daily_goal_ml })),
    );
    return {
      date: dateStr,
      totalIntakeMl: dayTotalMl,
      teamScore: fair.roundedScore,
      rawTeamScore: fair.rawScore,
    };
  });

  // Team streak: consecutive days with teamScore >= 70%
  let teamStreak = 0;
  for (let i = history.length - 1; i >= 0; i--) {
    if (history[i].teamScore >= 70) {
      teamStreak += 1;
    } else if (i === history.length - 1 && history.length > 1 && history[history.length - 2].teamScore >= 70) {
      continue;
    } else {
      break;
    }
  }

  return {
    ...found,
    teamStreak,
    history,
  };
}

export function getUserPlantStatus(db: Database.Database, user: UserRow, timeZone: string) {
  const todayStats = getUserTodayStats(db, user, timeZone);
  const streakHistory = getUserStreakAndHistory(db, user, timeZone);
  const localHour = getLocalHour(new Date(), timeZone);

  const plant = computePlantState({
    todayPct: todayStats.completionPct,
    streak: streakHistory.currentStreak,
    recentAvgPct: streakHistory.weeklyAvgPct,
    logsTodayCount: todayStats.todayLogs.length,
    localHour,
  });

  return {
    ...plant,
    todayPct: todayStats.completionPct,
    todayIntakeMl: todayStats.totalIntakeMl,
    dailyGoalMl: todayStats.baseGoalMl,
    currentStreak: streakHistory.currentStreak,
    weeklyAvgPct: streakHistory.weeklyAvgPct,
    logsTodayCount: todayStats.todayLogs.length,
  };
}
