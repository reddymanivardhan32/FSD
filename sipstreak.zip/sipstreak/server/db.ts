import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';

export function createDatabase(dbPath?: string): Database.Database {
  const targetPath = dbPath ?? process.env.DB_PATH ?? './data/sipstreak.db';

  if (targetPath !== ':memory:') {
    const dir = path.dirname(path.resolve(targetPath));
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  const db = new Database(targetPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS hydration_squads (
      id TEXT PRIMARY KEY,
      team_name TEXT NOT NULL UNIQUE,
      invite_code TEXT NOT NULL UNIQUE,
      created_by TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      weight_kg REAL NOT NULL CHECK (weight_kg >= 25 AND weight_kg <= 250),
      daily_goal_ml INTEGER NOT NULL CHECK (daily_goal_ml >= 875),
      squad_id TEXT REFERENCES hydration_squads(id) ON DELETE SET NULL,
      is_demo INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS hydration_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      amount_ml INTEGER NOT NULL CHECK (amount_ml > 0 AND amount_ml <= 5000),
      drink_type TEXT NOT NULL,
      client_request_id TEXT UNIQUE,
      timestamp_utc TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_hydration_logs_user_time
      ON hydration_logs(user_id, timestamp_utc);

    CREATE TABLE IF NOT EXISTS caffeine_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      beverage_type TEXT NOT NULL CHECK (beverage_type IN ('coffee', 'energy_drink')),
      offset_ml INTEGER NOT NULL DEFAULT 200,
      timestamp_utc TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_caffeine_logs_user_time
      ON caffeine_logs(user_id, timestamp_utc);

    CREATE TABLE IF NOT EXISTS daily_team_scores (
      id TEXT PRIMARY KEY,
      squad_id TEXT NOT NULL REFERENCES hydration_squads(id) ON DELETE CASCADE,
      date TEXT NOT NULL,
      total_intake_ml INTEGER NOT NULL,
      team_score REAL NOT NULL,
      rank INTEGER NOT NULL,
      UNIQUE(squad_id, date)
    );

    CREATE TABLE IF NOT EXISTS user_streaks (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      current_streak INTEGER NOT NULL DEFAULT 0,
      longest_streak INTEGER NOT NULL DEFAULT 0,
      last_completed_date TEXT,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS achievements (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      code TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      unlocked_at TEXT NOT NULL,
      UNIQUE(user_id, code)
    );

    CREATE TABLE IF NOT EXISTS fountain_locations (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      building TEXT NOT NULL,
      floor TEXT NOT NULL,
      latitude REAL NOT NULL,
      longitude REAL NOT NULL,
      water_type TEXT NOT NULL CHECK (water_type IN ('chilled_filtered', 'bottle_refill', 'standard')),
      status TEXT NOT NULL CHECK (status IN ('sample_active', 'sample_maintenance')),
      notes TEXT NOT NULL,
      is_sample INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS user_reminder_settings (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      enabled INTEGER NOT NULL DEFAULT 1,
      start_hour INTEGER NOT NULL DEFAULT 8 CHECK (start_hour >= 0 AND start_hour <= 23),
      end_hour INTEGER NOT NULL DEFAULT 21 CHECK (end_hour >= 0 AND end_hour <= 23),
      interval_minutes INTEGER NOT NULL DEFAULT 60 CHECK (interval_minutes >= 1 AND interval_minutes <= 240),
      last_notified_at TEXT
    );

    CREATE TABLE IF NOT EXISTS app_meta (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);

  return db;
}
