export interface MemberIntakeSnapshot {
  intakeMl: number;
  goalMl: number;
}

export interface FairTeamScoreResult {
  rawScore: number;
  roundedScore: number;
  memberContributions: number[];
}

export interface PlantStateResult {
  stage: 'wilting' | 'sprout' | 'growing' | 'thriving' | 'blooming';
  stageNumber: number;
  title: string;
  healthLabel: string;
  statusMessage: string;
  hydrationFactor: number;
}

export const MIN_SQUAD_MEMBERS = 4;
export const MAX_SQUAD_MEMBERS = 8;
export const CAFFEINE_OFFSET_ML = 200;

export function calculateDailyGoalMl(weightKg: number): number {
  return Math.round(weightKg * 35);
}

/**
 * Computes completion percentage for the primary hydration ring.
 * Capped at 100% per Challenge / Feature 2 specification.
 */
export function calculateCappedHydrationPct(intakeMl: number, targetMl: number): number {
  if (targetMl <= 0) return 0;
  const pct = (intakeMl / targetMl) * 100;
  return Math.min(Math.round(pct), 100);
}

export function calculateRawHydrationPct(intakeMl: number, targetMl: number): number {
  if (targetMl <= 0) return 0;
  return Math.round((intakeMl / targetMl) * 100);
}

/**
 * Fair-Participation Team Scoring Algorithm (Challenge A):
 * MemberContribution = min(Member_Intake / Member_Goal, 1)
 * TeamScore = (sum(MemberContribution) / Team_Size) * 100
 * Prevents a single heavy drinker from carrying the entire team.
 */
export function calculateFairTeamScore(members: MemberIntakeSnapshot[]): FairTeamScoreResult {
  if (members.length === 0) {
    return { rawScore: 0, roundedScore: 0, memberContributions: [] };
  }

  const memberContributions = members.map((m) => {
    if (m.goalMl <= 0) return 0;
    return Math.min(m.intakeMl / m.goalMl, 1);
  });

  const sum = memberContributions.reduce((acc, val) => acc + val, 0);
  const rawScore = (sum / members.length) * 100;
  return {
    rawScore: Number(rawScore.toFixed(2)),
    roundedScore: Math.round(rawScore),
    memberContributions,
  };
}

export function normalizeTimezone(tz?: string): string {
  if (!tz) return 'UTC';
  try {
    Intl.DateTimeFormat('en-CA', { timeZone: tz }).format(new Date());
    return tz;
  } catch {
    return 'UTC';
  }
}

/**
 * Converts a UTC ISO timestamp into YYYY-MM-DD in the user's local timezone.
 */
export function getLocalDateString(timestampUtc: string | Date, timeZone = 'UTC'): string {
  const safeTz = normalizeTimezone(timeZone);
  const date = typeof timestampUtc === 'string' ? new Date(timestampUtc) : timestampUtc;
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: safeTz,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
}

export function getLocalHour(date: Date, timeZone = 'UTC'): number {
  const safeTz = normalizeTimezone(timeZone);
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: safeTz,
    hour: 'numeric',
    hour12: false,
  }).formatToParts(date);
  const hourPart = parts.find((p) => p.type === 'hour')?.value ?? '12';
  const parsed = Number(hourPart);
  return parsed === 24 ? 0 : parsed;
}

/**
 * Returns an ordered array of N YYYY-MM-DD local calendar dates ending on referenceDate.
 */
export function getLastNDates(n: number, timeZone = 'UTC', referenceDate = new Date()): string[] {
  const safeTz = normalizeTimezone(timeZone);
  const todayStr = getLocalDateString(referenceDate, safeTz);
  const [y, m, d] = todayStr.split('-').map(Number);
  const dates: string[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const dt = new Date(Date.UTC(y, m - 1, d - i, 12, 0, 0));
    const yy = dt.getUTCFullYear();
    const mm = String(dt.getUTCMonth() + 1).padStart(2, '0');
    const dd = String(dt.getUTCDate()).padStart(2, '0');
    dates.push(`${yy}-${mm}-${dd}`);
  }
  return dates;
}

/**
 * Computes a UTC ISO timestamp corresponding to a given local date (YYYY-MM-DD) and local HH:MM
 * in the target IANA timezone.
 */
export function utcIsoForLocalTime(
  localDateStr: string,
  hour: number,
  minute: number,
  timeZone = 'UTC',
): string {
  const safeTz = normalizeTimezone(timeZone);
  const [y, m, d] = localDateStr.split('-').map(Number);
  // Start with a UTC guess at the same clock fields
  let candidate = new Date(Date.UTC(y, m - 1, d, hour, minute, 0, 0));

  // Refine twice to account for timezone offset and DST transitions
  for (let i = 0; i < 2; i++) {
    const formatted = new Intl.DateTimeFormat('en-CA', {
      timeZone: safeTz,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    }).formatToParts(candidate);

    const getVal = (type: string) => Number(formatted.find((p) => p.type === type)?.value ?? 0);
    const cy = getVal('year');
    const cm = getVal('month');
    const cd = getVal('day');
    let ch = getVal('hour');
    if (ch === 24) ch = 0;
    const cmin = getVal('minute');

    const targetMs = Date.UTC(y, m - 1, d, hour, minute, 0, 0);
    const actualMs = Date.UTC(cy, cm - 1, cd, ch, cmin, 0, 0);
    candidate = new Date(candidate.getTime() + (targetMs - actualMs));
  }

  return candidate.toISOString();
}

/**
 * Calculates consecutive completed local calendar days.
 * A day counts as completed when totalIntakeMl >= dailyGoalMl.
 * Active streaks remain intact during the current day prior to hitting today's target if yesterday was completed.
 */
export function calculateStreak(
  dailyTotalsByDate: Record<string, number>,
  dailyGoalMl: number,
  timeZone = 'UTC',
  referenceDate = new Date(),
): { currentStreak: number; longestStreak: number; lastCompletedDate: string | null } {
  const dates30 = getLastNDates(30, timeZone, referenceDate);
  const todayStr = dates30[dates30.length - 1];
  const yesterdayStr = dates30[dates30.length - 2];

  const isCompleted = (dateStr: string) => (dailyTotalsByDate[dateStr] ?? 0) >= dailyGoalMl;

  let longestStreak = 0;
  let running = 0;
  let lastCompletedDate: string | null = null;

  for (const dateStr of dates30) {
    if (isCompleted(dateStr)) {
      running += 1;
      lastCompletedDate = dateStr;
      if (running > longestStreak) longestStreak = running;
    } else {
      running = 0;
    }
  }

  let currentStreak = 0;
  let anchorIdx = dates30.length - 1;
  if (!isCompleted(todayStr)) {
    // Allow ongoing day before midnight if yesterday was completed
    if (isCompleted(yesterdayStr)) {
      anchorIdx = dates30.length - 2;
    } else {
      return { currentStreak: 0, longestStreak, lastCompletedDate };
    }
  }

  for (let i = anchorIdx; i >= 0; i--) {
    if (isCompleted(dates30[i])) {
      currentStreak += 1;
    } else {
      break;
    }
  }

  return { currentStreak, longestStreak, lastCompletedDate };
}

/**
 * Deterministic Virtual Plant Companion state driven by actual hydration metrics.
 */
export function computePlantState(params: {
  todayPct: number;
  streak: number;
  recentAvgPct: number;
  logsTodayCount: number;
  localHour: number;
}): PlantStateResult {
  const { todayPct, streak, recentAvgPct, logsTodayCount, localHour } = params;
  const hydrationFactor = Math.round(todayPct * 0.65 + Math.min(recentAvgPct, 100) * 0.25 + Math.min(streak * 5, 10));

  // Wilting if neglected late in the day or very low consistency
  if ((logsTodayCount === 0 && localHour >= 12) || (todayPct < 20 && recentAvgPct < 45)) {
    return {
      stage: 'wilting',
      stageNumber: 1,
      title: 'Thirsty Seedling',
      healthLabel: 'Needs Water',
      statusMessage: 'Soil moisture is low. Log a glass of water to perk up the leaves.',
      hydrationFactor: Math.max(10, hydrationFactor),
    };
  }

  if (todayPct >= 100 || (todayPct >= 85 && streak >= 3)) {
    return {
      stage: 'blooming',
      stageNumber: 5,
      title: 'Radiant Hydro-Fern',
      healthLabel: 'Peak Bloom',
      statusMessage: 'Your daily hydration target and consistency brought the plant into full bloom.',
      hydrationFactor: Math.min(100, Math.max(92, hydrationFactor)),
    };
  }

  if (todayPct >= 70 || (todayPct >= 55 && streak >= 2)) {
    return {
      stage: 'thriving',
      stageNumber: 4,
      title: 'Thriving Canopy',
      healthLabel: 'Healthy',
      statusMessage: 'Steady hydration keeps every leaf vibrant. One more bottle reaches full bloom.',
      hydrationFactor: Math.min(91, Math.max(72, hydrationFactor)),
    };
  }

  if (todayPct >= 35 || logsTodayCount >= 2) {
    return {
      stage: 'growing',
      stageNumber: 3,
      title: 'Growing Sapling',
      healthLabel: 'Hydrating',
      statusMessage: 'New shoots are unfurling as your intake climbs toward today’s goal.',
      hydrationFactor: Math.min(71, Math.max(45, hydrationFactor)),
    };
  }

  return {
    stage: 'sprout',
    stageNumber: 2,
    title: 'Fresh Sprout',
    healthLabel: 'Awakening',
    statusMessage: 'Early morning moisture detected. Keep sipping regularly to grow new leaves.',
    hydrationFactor: Math.min(44, Math.max(25, hydrationFactor)),
  };
}
