import Database from 'better-sqlite3';
import crypto from 'crypto';
import { hashPassword } from './middleware/auth';
import {
  calculateDailyGoalMl,
  getLastNDates,
  getLocalDateString,
  getLocalHour,
  utcIsoForLocalTime,
} from './utils/hydration';
import { computeLeaderboard } from './services/metrics';

export const DEMO_EMAIL = 'rohan@sipstreak.edu';
export const DEMO_PASSWORD = 'HydroHero2026!';

interface SeedMember {
  name: string;
  email: string;
  weightKg: number;
  todayLogsMl: number[];
  pastDayFactors: number[]; // 6 days: Day -6 .. Day -1 as fraction of dailyGoalMl
  isDemo?: boolean;
}

interface SeedSquad {
  teamName: string;
  inviteCode: string;
  members: SeedMember[];
}

const SEED_SQUADS: SeedSquad[] = [
  {
    teamName: 'Hostel Block A',
    inviteCode: 'HBLA26',
    members: [
      {
        name: 'Aarav Mehta',
        email: 'aarav@sipstreak.edu',
        weightKg: 60, // goal 2100 -> today 3000 (143% capped at 100%)
        todayLogsMl: [750, 750, 750, 750],
        pastDayFactors: [0.95, 1.0, 0.85, 1.05, 0.9, 1.0],
      },
      {
        name: 'Priya Nair',
        email: 'priya@sipstreak.edu',
        weightKg: 65, // goal 2275 -> today 1750 (0.7692)
        todayLogsMl: [500, 500, 500, 250],
        pastDayFactors: [0.8, 0.75, 0.9, 0.85, 0.78, 0.82],
      },
      {
        name: 'Devansh Kulkarni',
        email: 'devansh@sipstreak.edu',
        weightKg: 70, // goal 2450 -> today 1500 (0.6122)
        todayLogsMl: [500, 500, 250, 250],
        pastDayFactors: [0.7, 0.82, 0.65, 0.75, 0.8, 0.68],
      },
      {
        name: 'Sneha Rao',
        email: 'sneha@sipstreak.edu',
        weightKg: 60, // goal 2100 -> today 1300 (0.6190)
        todayLogsMl: [500, 300, 250, 250],
        pastDayFactors: [0.75, 0.68, 0.8, 0.72, 0.78, 0.65],
      },
    ],
  },
  {
    teamName: 'Hostel Block B',
    inviteCode: 'HBLB26',
    members: [
      {
        name: 'Rohan Verma',
        email: DEMO_EMAIL,
        weightKg: 60, // goal 2100 -> today 1350 (64%) -> +500ml => 1850 (88%)
        todayLogsMl: [500, 500, 250, 100],
        // 4-day streak into yesterday (Day -4..-1 >= 1.0)
        pastDayFactors: [0.76, 0.86, 1.0, 1.05, 1.0, 1.04],
        isDemo: true,
      },
      {
        name: 'Ananya Iyer',
        email: 'ananya@sipstreak.edu',
        weightKg: 60, // goal 2100 -> today 1650 (0.7857)
        todayLogsMl: [750, 500, 250, 150],
        pastDayFactors: [0.82, 0.9, 0.75, 0.88, 0.72, 0.78],
      },
      {
        name: 'Kabir Singh',
        email: 'kabir@sipstreak.edu',
        weightKg: 70, // goal 2450 -> today 1750 (0.7143)
        todayLogsMl: [750, 500, 250, 250],
        pastDayFactors: [0.72, 0.85, 0.8, 0.78, 0.7, 0.68],
      },
      {
        name: 'Meera Joshi',
        email: 'meera@sipstreak.edu',
        weightKg: 50, // goal 1750 -> today 1300 (0.7429)
        todayLogsMl: [500, 500, 300],
        pastDayFactors: [0.85, 0.78, 0.88, 0.92, 0.65, 0.56],
      },
    ],
  },
  {
    teamName: 'Aqua Knights',
    inviteCode: 'AQUA26',
    members: [
      {
        name: 'Vikram Patel',
        email: 'vikram@sipstreak.edu',
        weightKg: 72, // goal 2520 -> today 1750 (0.6944)
        todayLogsMl: [750, 500, 500],
        pastDayFactors: [0.7, 0.65, 0.72, 0.68, 0.74, 0.7],
      },
      {
        name: 'Neha Kapoor',
        email: 'neha@sipstreak.edu',
        weightKg: 58, // goal 2030 -> today 1300 (0.6404)
        todayLogsMl: [500, 500, 300],
        pastDayFactors: [0.68, 0.72, 0.66, 0.7, 0.64, 0.68],
      },
      {
        name: 'Siddharth Das',
        email: 'siddharth@sipstreak.edu',
        weightKg: 68, // goal 2380 -> today 1500 (0.6303)
        todayLogsMl: [500, 500, 250, 250],
        pastDayFactors: [0.6, 0.68, 0.74, 0.62, 0.69, 0.65],
      },
      {
        name: 'Tanya Gupta',
        email: 'tanya@sipstreak.edu',
        weightKg: 56, // goal 1960 -> today 1350 (0.6888)
        todayLogsMl: [500, 500, 350],
        pastDayFactors: [0.75, 0.7, 0.65, 0.72, 0.66, 0.69],
      },
    ],
  },
  {
    teamName: 'Hydration Homies',
    inviteCode: 'HYDR26',
    members: [
      {
        name: 'Arjun Reddy',
        email: 'arjun@sipstreak.edu',
        weightKg: 75, // goal 2625 -> today 1500 (0.5714)
        todayLogsMl: [500, 500, 500],
        pastDayFactors: [0.55, 0.62, 0.58, 0.65, 0.6, 0.64],
      },
      {
        name: 'Ishita Bose',
        email: 'ishita@sipstreak.edu',
        weightKg: 54, // goal 1890 -> today 1150 (0.6085)
        todayLogsMl: [500, 400, 250],
        pastDayFactors: [0.6, 0.65, 0.58, 0.62, 0.66, 0.6],
      },
      {
        name: 'Karan Malhotra',
        email: 'karan@sipstreak.edu',
        weightKg: 66, // goal 2310 -> today 1400 (0.6061)
        todayLogsMl: [500, 500, 400],
        pastDayFactors: [0.62, 0.58, 0.64, 0.6, 0.62, 0.65],
      },
      {
        name: 'Riya Menon',
        email: 'riya@sipstreak.edu',
        weightKg: 52, // goal 1820 -> today 1050 (0.5769)
        todayLogsMl: [500, 300, 250],
        pastDayFactors: [0.58, 0.62, 0.54, 0.6, 0.56, 0.59],
      },
    ],
  },
];

const SAMPLE_FOUNTAINS = [
  {
    id: 'fountain-lib-01',
    name: 'Central Library Atrium Refill Station',
    building: 'Main Academic Library',
    floor: 'Ground Floor, East Wing',
    latitude: 37.4275,
    longitude: -122.1697,
    water_type: 'chilled_filtered',
    status: 'sample_active',
    notes: 'Sensor-activated chilled bottle filler with digital filter life indicator.',
  },
  {
    id: 'fountain-eng-02',
    name: 'Engineering Quad Breeze Station',
    building: 'Huang Engineering Center',
    floor: 'Level 1, Main Lobby',
    latitude: 37.4283,
    longitude: -122.1743,
    water_type: 'bottle_refill',
    status: 'sample_active',
    notes: 'High-flow stainless steel refill spout near lecture hall doors.',
  },
  {
    id: 'fountain-hostel-b',
    name: 'Hostel Block B Courtyard Dispenser',
    building: 'Hostel Block B',
    floor: 'Ground Courtyard',
    latitude: 37.4249,
    longitude: -122.1669,
    water_type: 'chilled_filtered',
    status: 'sample_active',
    notes: '24/7 accessible RO + UV chilled hydration station for Block B residents.',
  },
  {
    id: 'fountain-hostel-a',
    name: 'Hostel Block A Common Room Tap',
    building: 'Hostel Block A',
    floor: 'Floor 1 Lounge',
    latitude: 37.4256,
    longitude: -122.1652,
    water_type: 'chilled_filtered',
    status: 'sample_active',
    notes: 'Filtered bottle filler adjacent to study lounge.',
  },
  {
    id: 'fountain-union-05',
    name: 'Student Union Food Court Hydro Hub',
    building: 'Tresidder Memorial Union',
    floor: 'Level 1, Patio Entrance',
    latitude: 37.4241,
    longitude: -122.1708,
    water_type: 'bottle_refill',
    status: 'sample_active',
    notes: 'Dual fountain + tall insulated bottle filler near outdoor seating.',
  },
  {
    id: 'fountain-sports-06',
    name: 'Recreation & Gym Track Fountain',
    building: 'Arrillaga Recreation Center',
    floor: 'Track Level, North Wall',
    latitude: 37.4292,
    longitude: -122.1628,
    water_type: 'chilled_filtered',
    status: 'sample_active',
    notes: 'Extra-cold hydration tap designed for post-workout bottle refills.',
  },
  {
    id: 'fountain-science-07',
    name: 'Biotech & Science Wing Fountain',
    building: 'Clark Center',
    floor: 'Level 2, Courtyard Bridge',
    latitude: 37.4301,
    longitude: -122.1731,
    water_type: 'standard',
    status: 'sample_active',
    notes: 'Standard drinking fountain and bottle nozzle near lab lockers.',
  },
  {
    id: 'fountain-arts-08',
    name: 'Arts & Design Annex Station',
    building: 'McMurtry Building',
    floor: 'Ground Studio Corridor',
    latitude: 37.4316,
    longitude: -122.1684,
    water_type: 'bottle_refill',
    status: 'sample_maintenance',
    notes: 'Scheduled filter cartridge replacement (sample maintenance state).',
  },
];

function buildTodayLogTimestamps(localDateStr: string, count: number, timeZone: string): string[] {
  const now = new Date();
  const localHour = getLocalHour(now, timeZone);
  const minutePart = now.getMinutes();
  const minsSinceMidnight = Math.max(20, localHour * 60 + minutePart - 4);

  const timestamps: string[] = [];
  for (let i = 0; i < count; i++) {
    const fraction = (i + 1) / (count + 1);
    const totalMins = Math.max(1, Math.floor(minsSinceMidnight * fraction));
    const hh = Math.min(23, Math.floor(totalMins / 60));
    const mm = totalMins % 60;
    timestamps.push(utcIsoForLocalTime(localDateStr, hh, mm, timeZone));
  }
  return timestamps;
}

function drinkTypeForMl(amountMl: number): string {
  if (amountMl === 250) return 'cup';
  if (amountMl === 500) return 'bottle';
  if (amountMl === 750) return 'tumbler';
  return 'custom';
}

export function seedFountains(db: Database.Database): void {
  const insertFountain = db.prepare(`
    INSERT OR IGNORE INTO fountain_locations
      (id, name, building, floor, latitude, longitude, water_type, status, notes, is_sample)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
  `);
  for (const f of SAMPLE_FOUNTAINS) {
    insertFountain.run(
      f.id,
      f.name,
      f.building,
      f.floor,
      f.latitude,
      f.longitude,
      f.water_type,
      f.status,
      f.notes,
    );
  }
}

export function seedAllDemoData(db: Database.Database, timeZone = 'UTC'): void {
  const dates7 = getLastNDates(7, timeZone);
  const todayStr = dates7[dates7.length - 1];
  const pastDates = dates7.slice(0, 6);
  const nowIso = new Date().toISOString();
  const sharedDemoHash = hashPassword(DEMO_PASSWORD);

  const tx = db.transaction(() => {
    seedFountains(db);

    const insertSquad = db.prepare(`
      INSERT INTO hydration_squads (id, team_name, invite_code, created_by, created_at)
      VALUES (?, ?, ?, ?, ?)
    `);
    const insertUser = db.prepare(`
      INSERT INTO users (id, name, email, password_hash, weight_kg, daily_goal_ml, squad_id, is_demo, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)
    `);
    const insertLog = db.prepare(`
      INSERT INTO hydration_logs (id, user_id, amount_ml, drink_type, client_request_id, timestamp_utc)
      VALUES (?, ?, ?, ?, NULL, ?)
    `);
    const insertReminder = db.prepare(`
      INSERT INTO user_reminder_settings (user_id, enabled, start_hour, end_hour, interval_minutes, last_notified_at)
      VALUES (?, 1, 8, 21, 60, NULL)
    `);

    for (const squad of SEED_SQUADS) {
      const squadId = crypto.randomUUID();
      insertSquad.run(squadId, squad.teamName, squad.inviteCode, null, nowIso);

      for (const member of squad.members) {
        const userId = crypto.randomUUID();
        const dailyGoalMl = calculateDailyGoalMl(member.weightKg);
        insertUser.run(
          userId,
          member.name,
          member.email,
          sharedDemoHash,
          member.weightKg,
          dailyGoalMl,
          squadId,
          nowIso,
        );
        insertReminder.run(userId);

        // Seed past 6 days of logs
        pastDates.forEach((dateStr: string, idx: number) => {
          const factor = member.pastDayFactors[idx] ?? 0.75;
          const dayTotal = Math.round((dailyGoalMl * factor) / 50) * 50;
          const chunks = [
            Math.round(dayTotal * 0.25),
            Math.round(dayTotal * 0.3),
            Math.round(dayTotal * 0.25),
            dayTotal - (Math.round(dayTotal * 0.25) + Math.round(dayTotal * 0.3) + Math.round(dayTotal * 0.25)),
          ];
          const hours = [9, 12, 15, 19];
          chunks.forEach((ml, cIdx) => {
            if (ml > 0) {
              insertLog.run(
                crypto.randomUUID(),
                userId,
                ml,
                drinkTypeForMl(ml),
                utcIsoForLocalTime(dateStr, hours[cIdx], 15, timeZone),
              );
            }
          });
        });

        // Seed today's logs strictly on todayStr in timeZone before current clock time
        const todayTimestamps = buildTodayLogTimestamps(todayStr, member.todayLogsMl.length, timeZone);
        member.todayLogsMl.forEach((ml, lIdx) => {
          insertLog.run(
            crypto.randomUUID(),
            userId,
            ml,
            drinkTypeForMl(ml),
            todayTimestamps[lIdx],
          );
        });
      }
    }

    // Seed yesterday's daily_team_scores so rank deltas work immediately
    const yesterdayStr = dates7[dates7.length - 2];
    const yesterdayTarget = [
      { teamName: 'Hostel Block A', score: 78.5, totalIntakeMl: 7200, rank: 1 },
      { teamName: 'Hostel Block B', score: 74.2, totalIntakeMl: 6850, rank: 2 },
      { teamName: 'Aqua Knights', score: 68.1, totalIntakeMl: 6100, rank: 3 },
      { teamName: 'Hydration Homies', score: 61.8, totalIntakeMl: 5450, rank: 4 },
    ];

    const findSquad = db.prepare(`SELECT id FROM hydration_squads WHERE team_name = ?`);
    const insertDailyTeamScore = db.prepare(`
      INSERT OR REPLACE INTO daily_team_scores (id, squad_id, date, total_intake_ml, team_score, rank)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    for (const row of yesterdayTarget) {
      const sq = findSquad.get(row.teamName) as { id: string } | undefined;
      if (sq) {
        insertDailyTeamScore.run(
          crypto.randomUUID(),
          sq.id,
          yesterdayStr,
          row.totalIntakeMl,
          row.score,
          row.rank,
        );
      }
    }

    db.prepare(
      `INSERT INTO app_meta (key, value) VALUES ('demo_seed_timezone', ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
    ).run(timeZone);
  });

  tx();
  computeLeaderboard(db, timeZone);
}

export function resetDemoEnvironment(db: Database.Database, timeZone = 'UTC'): void {
  const tx = db.transaction(() => {
    db.prepare(`DELETE FROM achievements WHERE user_id IN (SELECT id FROM users WHERE is_demo = 1)`).run();
    db.prepare(`DELETE FROM user_streaks WHERE user_id IN (SELECT id FROM users WHERE is_demo = 1)`).run();
    db.prepare(`DELETE FROM user_reminder_settings WHERE user_id IN (SELECT id FROM users WHERE is_demo = 1)`).run();
    db.prepare(`DELETE FROM caffeine_logs WHERE user_id IN (SELECT id FROM users WHERE is_demo = 1)`).run();
    db.prepare(`DELETE FROM hydration_logs WHERE user_id IN (SELECT id FROM users WHERE is_demo = 1)`).run();
    db.prepare(`DELETE FROM users WHERE is_demo = 1`).run();
    db.prepare(
      `DELETE FROM daily_team_scores WHERE squad_id IN (SELECT id FROM hydration_squads WHERE invite_code IN ('HBLA26', 'HBLB26', 'AQUA26', 'HYDR26'))`,
    ).run();
    db.prepare(
      `DELETE FROM hydration_squads WHERE invite_code IN ('HBLA26', 'HBLB26', 'AQUA26', 'HYDR26')`,
    ).run();
  });
  tx();
  seedAllDemoData(db, timeZone);
}

export function ensureSeeded(db: Database.Database, timeZone = 'UTC'): void {
  seedFountains(db);
  const countRow = db.prepare(`SELECT COUNT(*) as cnt FROM users`).get() as { cnt: number };
  if (countRow.cnt === 0) {
    seedAllDemoData(db, timeZone);
  }
}

/**
 * Ensures demo today logs align with the caller's browser timezone if the server initially seeded in UTC
 * and the browser is on a different local calendar day (e.g. PST evening vs UTC next day),
 * ONLY if no new logs were added manually after seeding.
 */
export function ensureDemoTodayAligned(db: Database.Database, timeZone: string): void {
  const rohan = db.prepare(`SELECT id FROM users WHERE email = ?`).get(DEMO_EMAIL) as { id: string } | undefined;
  if (!rohan) return;

  const meta = db
    .prepare(`SELECT value FROM app_meta WHERE key = 'demo_seed_timezone'`)
    .get() as { value: string } | undefined;

  const hasManualLog = db
    .prepare(
      `SELECT 1 FROM hydration_logs
       WHERE user_id IN (SELECT id FROM users WHERE is_demo = 1)
         AND client_request_id IS NOT NULL
       LIMIT 1`,
    )
    .get();
  if (hasManualLog) return;

  const todayStr = getLocalDateString(new Date(), timeZone);
  const logs = db
    .prepare(`SELECT timestamp_utc FROM hydration_logs WHERE user_id = ?`)
    .all(rohan.id) as Array<{ timestamp_utc: string }>;
  const todayCount = logs.filter((l) => getLocalDateString(l.timestamp_utc, timeZone) === todayStr).length;

  if (meta?.value !== timeZone || todayCount === 0) {
    resetDemoEnvironment(db, timeZone);
  }
}
