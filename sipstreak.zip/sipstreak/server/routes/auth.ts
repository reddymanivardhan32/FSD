import Database from 'better-sqlite3';
import crypto from 'crypto';
import { Router } from 'express';
import {
  AuthenticatedRequest,
  hashPassword,
  requireAuth,
  signToken,
  verifyPassword,
} from '../middleware/auth';
import { DEMO_EMAIL, ensureDemoTodayAligned } from '../seed';
import { UserRow, computeLeaderboard, sanitizeUser } from '../services/metrics';
import { MAX_SQUAD_MEMBERS, calculateDailyGoalMl } from '../utils/hydration';

export function createAuthRouter(db: Database.Database): Router {
  const router = Router();

  router.post('/register', (req, res) => {
    const { name, email, password, weightKg, inviteCode } = req.body ?? {};

    if (typeof name !== 'string' || name.trim().length < 2 || name.trim().length > 60) {
      res.status(400).json({ error: 'Name must be between 2 and 60 characters.' });
      return;
    }

    if (typeof email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }

    if (typeof password !== 'string' || password.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters long.' });
      return;
    }

    const parsedWeight = Number(weightKg);
    if (!Number.isFinite(parsedWeight) || parsedWeight < 25 || parsedWeight > 250) {
      res.status(400).json({ error: 'Body weight must be between 25 kg and 250 kg.' });
      return;
    }

    const normalizedEmail = email.trim().toLowerCase();
    const existing = db.prepare(`SELECT id FROM users WHERE email = ?`).get(normalizedEmail);
    if (existing) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    let squadId: string | null = null;
    if (typeof inviteCode === 'string' && inviteCode.trim().length > 0) {
      const code = inviteCode.trim().toUpperCase();
      const squad = db.prepare(`SELECT id FROM hydration_squads WHERE invite_code = ?`).get(code) as
        | { id: string }
        | undefined;
      if (!squad) {
        res.status(404).json({ error: `No squad found with invite code "${code}".` });
        return;
      }
      const memberCountRow = db
        .prepare(`SELECT COUNT(*) as cnt FROM users WHERE squad_id = ?`)
        .get(squad.id) as { cnt: number };
      if (memberCountRow.cnt >= MAX_SQUAD_MEMBERS) {
        res.status(409).json({
          error: `Squad "${code}" is already full (maximum ${MAX_SQUAD_MEMBERS} members).`,
        });
        return;
      }
      squadId = squad.id;
    }

    const userId = crypto.randomUUID();
    const dailyGoalMl = calculateDailyGoalMl(parsedWeight);
    const nowIso = new Date().toISOString();
    const passwordHash = hashPassword(password);

    db.prepare(
      `INSERT INTO users (id, name, email, password_hash, weight_kg, daily_goal_ml, squad_id, is_demo, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)`,
    ).run(userId, name.trim(), normalizedEmail, passwordHash, parsedWeight, dailyGoalMl, squadId, nowIso);

    db.prepare(
      `INSERT INTO user_reminder_settings (user_id, enabled, start_hour, end_hour, interval_minutes, last_notified_at)
       VALUES (?, 1, 8, 21, 60, NULL)`,
    ).run(userId);

    const createdUser = db.prepare(`SELECT * FROM users WHERE id = ?`).get(userId) as UserRow;
    const token = signToken({ userId: createdUser.id, email: createdUser.email });

    res.status(201).json({ token, user: sanitizeUser(createdUser) });
  });

  router.post('/login', (req, res) => {
    const { email, password } = req.body ?? {};
    if (typeof email !== 'string' || typeof password !== 'string') {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const normalizedEmail = email.trim().toLowerCase();
    const user = db.prepare(`SELECT * FROM users WHERE email = ?`).get(normalizedEmail) as UserRow | undefined;
    if (!user || !verifyPassword(password, user.password_hash)) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const token = signToken({ userId: user.id, email: user.email });
    res.json({ token, user: sanitizeUser(user) });
  });

  router.post('/demo-login', (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const requestedEmail =
      typeof req.body?.email === 'string' && req.body.email.trim().length > 0
        ? req.body.email.trim().toLowerCase()
        : DEMO_EMAIL;

    ensureDemoTodayAligned(db, authReq.timeZone);

    const user = db
      .prepare(`SELECT * FROM users WHERE email = ? AND is_demo = 1`)
      .get(requestedEmail) as UserRow | undefined;

    if (!user) {
      res.status(404).json({ error: 'Demo account not found.' });
      return;
    }

    const token = signToken({ userId: user.id, email: user.email });
    res.json({ token, user: sanitizeUser(user) });
  });

  router.get('/me', requireAuth, (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(authReq.auth!.userId) as
      | UserRow
      | undefined;
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    res.json({ user: sanitizeUser(user) });
  });

  router.patch('/profile', requireAuth, (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const { name, weightKg } = req.body ?? {};

    const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(authReq.auth!.userId) as
      | UserRow
      | undefined;
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    let nextName = user.name;
    if (name !== undefined) {
      if (typeof name !== 'string' || name.trim().length < 2 || name.trim().length > 60) {
        res.status(400).json({ error: 'Name must be between 2 and 60 characters.' });
        return;
      }
      nextName = name.trim();
    }

    let nextWeight = user.weight_kg;
    let nextGoal = user.daily_goal_ml;
    if (weightKg !== undefined) {
      const parsed = Number(weightKg);
      if (!Number.isFinite(parsed) || parsed < 25 || parsed > 250) {
        res.status(400).json({ error: 'Body weight must be between 25 kg and 250 kg.' });
        return;
      }
      nextWeight = parsed;
      nextGoal = calculateDailyGoalMl(parsed);
    }

    db.prepare(`UPDATE users SET name = ?, weight_kg = ?, daily_goal_ml = ? WHERE id = ?`).run(
      nextName,
      nextWeight,
      nextGoal,
      user.id,
    );

    const updated = db.prepare(`SELECT * FROM users WHERE id = ?`).get(user.id) as UserRow;
    computeLeaderboard(db, authReq.timeZone);
    res.json({ user: sanitizeUser(updated) });
  });

  return router;
}
