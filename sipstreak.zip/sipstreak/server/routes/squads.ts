import Database from 'better-sqlite3';
import crypto from 'crypto';
import { Router } from 'express';
import { AuthenticatedRequest, requireAuth, verifyToken } from '../middleware/auth';
import { UserRow, computeLeaderboard, getSquadDetails } from '../services/metrics';
import { MAX_SQUAD_MEMBERS } from '../utils/hydration';

function generateInviteCode(db: Database.Database): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (let attempt = 0; attempt < 20; attempt++) {
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    const exists = db.prepare(`SELECT id FROM hydration_squads WHERE invite_code = ?`).get(code);
    if (!exists) return code;
  }
  return `SQ${Date.now().toString(36).toUpperCase().slice(-4)}`;
}

export function createSquadsRouter(db: Database.Database): Router {
  const router = Router();

  router.get('/leaderboard', (req, res) => {
    const authReq = req as AuthenticatedRequest;
    let mySquadId: string | null = null;

    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      try {
        const payload = verifyToken(authHeader.slice(7).trim());
        const user = db.prepare(`SELECT squad_id FROM users WHERE id = ?`).get(payload.userId) as
          | { squad_id: string | null }
          | undefined;
        mySquadId = user?.squad_id ?? null;
      } catch {
        // Optional auth on leaderboard preview
      }
    }

    const leaderboard = computeLeaderboard(db, authReq.timeZone);
    res.json({
      ...leaderboard,
      mySquadId,
    });
  });

  router.get('/mine', requireAuth, (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(authReq.auth!.userId) as
      | UserRow
      | undefined;

    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    if (!user.squad_id) {
      res.json({ squad: null });
      return;
    }

    const squad = getSquadDetails(db, user.squad_id, authReq.timeZone);
    res.json({ squad });
  });

  router.post('/create', requireAuth, (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const teamName = typeof req.body?.teamName === 'string' ? req.body.teamName.trim() : '';

    if (teamName.length < 3 || teamName.length > 40) {
      res.status(400).json({ error: 'Team name must be between 3 and 40 characters.' });
      return;
    }

    const existing = db
      .prepare(`SELECT id FROM hydration_squads WHERE LOWER(team_name) = LOWER(?)`)
      .get(teamName);
    if (existing) {
      res.status(409).json({ error: `A squad named "${teamName}" already exists.` });
      return;
    }

    const squadId = crypto.randomUUID();
    const inviteCode = generateInviteCode(db);
    const nowIso = new Date().toISOString();

    db.prepare(
      `INSERT INTO hydration_squads (id, team_name, invite_code, created_by, created_at)
       VALUES (?, ?, ?, ?, ?)`,
    ).run(squadId, teamName, inviteCode, authReq.auth!.userId, nowIso);

    db.prepare(`UPDATE users SET squad_id = ? WHERE id = ?`).run(squadId, authReq.auth!.userId);

    const squad = getSquadDetails(db, squadId, authReq.timeZone);
    res.status(201).json({ squad });
  });

  router.post('/join', requireAuth, (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const rawCode = typeof req.body?.inviteCode === 'string' ? req.body.inviteCode.trim().toUpperCase() : '';

    if (!rawCode) {
      res.status(400).json({ error: 'Invite code is required.' });
      return;
    }

    const squadRow = db
      .prepare(`SELECT id, team_name FROM hydration_squads WHERE invite_code = ?`)
      .get(rawCode) as { id: string; team_name: string } | undefined;

    if (!squadRow) {
      res.status(404).json({ error: `Invalid invite code "${rawCode}". No matching squad found.` });
      return;
    }

    const user = db.prepare(`SELECT squad_id FROM users WHERE id = ?`).get(authReq.auth!.userId) as
      | { squad_id: string | null }
      | undefined;

    if (user?.squad_id === squadRow.id) {
      res.status(409).json({ error: `You are already a member of ${squadRow.team_name}.` });
      return;
    }

    const memberCount = db
      .prepare(`SELECT COUNT(*) as cnt FROM users WHERE squad_id = ?`)
      .get(squadRow.id) as { cnt: number };

    if (memberCount.cnt >= MAX_SQUAD_MEMBERS) {
      res.status(409).json({
        error: `${squadRow.team_name} is full (${MAX_SQUAD_MEMBERS}/${MAX_SQUAD_MEMBERS} members).`,
      });
      return;
    }

    db.prepare(`UPDATE users SET squad_id = ? WHERE id = ?`).run(squadRow.id, authReq.auth!.userId);
    const squad = getSquadDetails(db, squadRow.id, authReq.timeZone);
    res.json({ squad });
  });

  router.post('/leave', requireAuth, (req, res) => {
    const authReq = req as AuthenticatedRequest;
    db.prepare(`UPDATE users SET squad_id = NULL WHERE id = ?`).run(authReq.auth!.userId);
    computeLeaderboard(db, authReq.timeZone);
    res.json({ left: true });
  });

  return router;
}
