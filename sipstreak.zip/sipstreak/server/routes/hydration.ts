import Database from 'better-sqlite3';
import crypto from 'crypto';
import { Router } from 'express';
import { AuthenticatedRequest, requireAuth } from '../middleware/auth';
import {
  UserRow,
  computeLeaderboard,
  evaluateAchievements,
  getSquadDetails,
  getUserPlantStatus,
  getUserStreakAndHistory,
  getUserTodayStats,
  sanitizeUser,
} from '../services/metrics';

const ALLOWED_DRINK_TYPES = new Set(['cup', 'bottle', 'tumbler', 'custom', 'qr_bottle']);

export function createHydrationRouter(db: Database.Database): Router {
  const router = Router();

  router.use(requireAuth);

  router.get('/dashboard', (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(authReq.auth!.userId) as
      | UserRow
      | undefined;

    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    const todayStats = getUserTodayStats(db, user, authReq.timeZone);
    const history = getUserStreakAndHistory(db, user, authReq.timeZone);
    const leaderboard = computeLeaderboard(db, authReq.timeZone);
    const mySquadRank = user.squad_id
      ? leaderboard.rankedTeams.find((t) => t.squadId === user.squad_id)?.rank ?? null
      : null;
    const squad = user.squad_id ? getSquadDetails(db, user.squad_id, authReq.timeZone) : null;
    const plant = getUserPlantStatus(db, user, authReq.timeZone);
    const achievements = evaluateAchievements(
      db,
      user,
      todayStats.totalIntakeMl,
      history.currentStreak,
      mySquadRank,
    );

    const reminders = db
      .prepare(
        `SELECT enabled, start_hour as startHour, end_hour as endHour,
                interval_minutes as intervalMinutes, last_notified_at as lastNotifiedAt
         FROM user_reminder_settings WHERE user_id = ?`,
      )
      .get(user.id);

    res.json({
      user: sanitizeUser(user),
      todayStats,
      streak: {
        currentStreak: history.currentStreak,
        longestStreak: history.longestStreak,
        weeklyAvgPct: history.weeklyAvgPct,
      },
      squad,
      plant,
      achievements,
      reminders,
    });
  });

  router.post('/log', (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(authReq.auth!.userId) as
      | UserRow
      | undefined;

    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    const { amountMl, drinkType, clientRequestId } = req.body ?? {};
    const parsedAmount = Number(amountMl);

    if (!Number.isInteger(parsedAmount) || parsedAmount < 10 || parsedAmount > 3000) {
      res.status(400).json({
        error: 'Water intake amount must be a whole number between 10 ml and 3000 ml.',
      });
      return;
    }

    const safeDrinkType =
      typeof drinkType === 'string' && ALLOWED_DRINK_TYPES.has(drinkType) ? drinkType : 'custom';

    const safeReqId =
      typeof clientRequestId === 'string' && clientRequestId.trim().length > 0
        ? clientRequestId.trim().slice(0, 128)
        : null;

    if (safeReqId) {
      const existingLog = db
        .prepare(`SELECT id, amount_ml as amountMl, drink_type as drinkType, timestamp_utc as timestampUtc FROM hydration_logs WHERE client_request_id = ?`)
        .get(safeReqId);
      if (existingLog) {
        const todayStats = getUserTodayStats(db, user, authReq.timeZone);
        const leaderboard = computeLeaderboard(db, authReq.timeZone);
        res.status(200).json({
          duplicatePrevented: true,
          log: existingLog,
          todayStats,
          leaderboard,
          rankTransition: null,
        });
        return;
      }
    }

    const beforeLeaderboard = computeLeaderboard(db, authReq.timeZone);
    const previousTeam = user.squad_id
      ? beforeLeaderboard.rankedTeams.find((t) => t.squadId === user.squad_id)
      : undefined;
    const previousRank = previousTeam?.rank ?? null;
    const previousScore = previousTeam?.teamScore ?? null;

    const logId = crypto.randomUUID();
    const nowUtc = new Date().toISOString();

    db.prepare(
      `INSERT INTO hydration_logs (id, user_id, amount_ml, drink_type, client_request_id, timestamp_utc)
       VALUES (?, ?, ?, ?, ?, ?)`,
    ).run(logId, user.id, parsedAmount, safeDrinkType, safeReqId, nowUtc);

    const todayStats = getUserTodayStats(db, user, authReq.timeZone);
    const history = getUserStreakAndHistory(db, user, authReq.timeZone);
    const afterLeaderboard = computeLeaderboard(db, authReq.timeZone);
    const newTeam = user.squad_id
      ? afterLeaderboard.rankedTeams.find((t) => t.squadId === user.squad_id)
      : undefined;
    const newRank = newTeam?.rank ?? null;
    const newScore = newTeam?.teamScore ?? null;

    const achievements = evaluateAchievements(
      db,
      user,
      todayStats.totalIntakeMl,
      history.currentStreak,
      newRank,
    );

    const improved = previousRank !== null && newRank !== null && newRank < previousRank;
    const becameFirst = improved && newRank === 1;

    res.status(201).json({
      duplicatePrevented: false,
      log: {
        id: logId,
        amountMl: parsedAmount,
        drinkType: safeDrinkType,
        timestampUtc: nowUtc,
      },
      todayStats,
      streak: {
        currentStreak: history.currentStreak,
        longestStreak: history.longestStreak,
      },
      squad: user.squad_id ? getSquadDetails(db, user.squad_id, authReq.timeZone) : null,
      leaderboard: afterLeaderboard,
      plant: getUserPlantStatus(db, user, authReq.timeZone),
      achievements,
      rankTransition: {
        previousRank,
        newRank,
        previousScore,
        newScore,
        improved,
        becameFirst,
        teamName: newTeam?.teamName ?? null,
      },
    });
  });

  router.delete('/log/:id', (req, res) => {
    const authReq = req as unknown as AuthenticatedRequest;
    const log = db
      .prepare(`SELECT id, user_id FROM hydration_logs WHERE id = ?`)
      .get(req.params.id) as { id: string; user_id: string } | undefined;

    if (!log) {
      res.status(404).json({ error: 'Hydration log entry not found.' });
      return;
    }

    if (log.user_id !== authReq.auth!.userId) {
      res.status(403).json({ error: 'You cannot modify or delete another user’s hydration log.' });
      return;
    }

    db.prepare(`DELETE FROM hydration_logs WHERE id = ? AND user_id = ?`).run(
      log.id,
      authReq.auth!.userId,
    );

    const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(authReq.auth!.userId) as UserRow;
    const todayStats = getUserTodayStats(db, user, authReq.timeZone);
    const leaderboard = computeLeaderboard(db, authReq.timeZone);

    res.json({ deletedId: log.id, todayStats, leaderboard });
  });

  router.post('/caffeine', (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(authReq.auth!.userId) as
      | UserRow
      | undefined;
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    const beverageType = req.body?.beverageType;
    if (beverageType !== 'coffee' && beverageType !== 'energy_drink') {
      res.status(400).json({ error: 'Beverage type must be "coffee" or "energy_drink".' });
      return;
    }

    const id = crypto.randomUUID();
    const nowUtc = new Date().toISOString();
    db.prepare(
      `INSERT INTO caffeine_logs (id, user_id, beverage_type, offset_ml, timestamp_utc)
       VALUES (?, ?, ?, 200, ?)`,
    ).run(id, user.id, beverageType, nowUtc);

    const todayStats = getUserTodayStats(db, user, authReq.timeZone);
    res.status(201).json({
      entry: { id, beverageType, offsetMl: 200, timestampUtc: nowUtc },
      todayStats,
    });
  });

  router.delete('/caffeine/:id', (req, res) => {
    const authReq = req as unknown as AuthenticatedRequest;
    const entry = db
      .prepare(`SELECT id, user_id FROM caffeine_logs WHERE id = ?`)
      .get(req.params.id) as { id: string; user_id: string } | undefined;

    if (!entry) {
      res.status(404).json({ error: 'Caffeine log entry not found.' });
      return;
    }

    if (entry.user_id !== authReq.auth!.userId) {
      res.status(403).json({ error: 'You cannot delete another user’s caffeine record.' });
      return;
    }

    db.prepare(`DELETE FROM caffeine_logs WHERE id = ? AND user_id = ?`).run(
      entry.id,
      authReq.auth!.userId,
    );

    const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(authReq.auth!.userId) as UserRow;
    const todayStats = getUserTodayStats(db, user, authReq.timeZone);
    res.json({ deletedId: entry.id, todayStats });
  });

  router.get('/history', (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(authReq.auth!.userId) as
      | UserRow
      | undefined;
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    const personal = getUserStreakAndHistory(db, user, authReq.timeZone);
    const squad = user.squad_id ? getSquadDetails(db, user.squad_id, authReq.timeZone) : null;

    res.json({
      personal,
      squad: squad
        ? {
            squadId: squad.squadId,
            teamName: squad.teamName,
            teamStreak: squad.teamStreak,
            history: squad.history,
          }
        : null,
    });
  });

  return router;
}
