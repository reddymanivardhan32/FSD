import Database from 'better-sqlite3';
import crypto from 'crypto';
import { Router } from 'express';
import { AuthenticatedRequest, requireAuth, signToken } from '../middleware/auth';
import { DEMO_EMAIL, resetDemoEnvironment } from '../seed';
import {
  UserRow,
  computeLeaderboard,
  getSquadDetails,
  getUserPlantStatus,
  getUserStreakAndHistory,
  getUserTodayStats,
  sanitizeUser,
} from '../services/metrics';

const recentQrScans = new Map<string, number>();

export function createFeaturesRouter(db: Database.Database): Router {
  const router = Router();

  router.get('/fountains', (req, res) => {
    const q = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';
    const waterType = typeof req.query.waterType === 'string' ? req.query.waterType : 'all';
    const status = typeof req.query.status === 'string' ? req.query.status : 'all';

    let rows = db
      .prepare(
        `SELECT id, name, building, floor, latitude, longitude, water_type as waterType,
                status, notes, is_sample as isSample
         FROM fountain_locations
         ORDER BY name ASC`,
      )
      .all() as Array<{
      id: string;
      name: string;
      building: string;
      floor: string;
      latitude: number;
      longitude: number;
      waterType: string;
      status: string;
      notes: string;
      isSample: number;
    }>;

    if (q) {
      rows = rows.filter(
        (r) =>
          r.name.toLowerCase().includes(q) ||
          r.building.toLowerCase().includes(q) ||
          r.floor.toLowerCase().includes(q),
      );
    }

    if (waterType !== 'all') {
      rows = rows.filter((r) => r.waterType === waterType);
    }

    if (status !== 'all') {
      rows = rows.filter((r) => r.status === status);
    }

    res.json({
      datasetNotice: 'Sample campus refill dataset for demonstration until independently verified.',
      fountains: rows.map((r) => ({ ...r, isSample: Boolean(r.isSample) })),
    });
  });

  router.get('/plant', requireAuth, (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(authReq.auth!.userId) as
      | UserRow
      | undefined;
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    res.json({ plant: getUserPlantStatus(db, user, authReq.timeZone) });
  });

  router.get('/reminders', requireAuth, (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const row = db
      .prepare(
        `SELECT enabled, start_hour as startHour, end_hour as endHour,
                interval_minutes as intervalMinutes, last_notified_at as lastNotifiedAt
         FROM user_reminder_settings WHERE user_id = ?`,
      )
      .get(authReq.auth!.userId);
    res.json({
      settings: row ?? {
        enabled: 1,
        startHour: 8,
        endHour: 21,
        intervalMinutes: 60,
        lastNotifiedAt: null,
      },
    });
  });

  router.put('/reminders', requireAuth, (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const { enabled, startHour, endHour, intervalMinutes } = req.body ?? {};
    const parsedStart = Number(startHour ?? 8);
    const parsedEnd = Number(endHour ?? 21);
    const parsedInterval = Number(intervalMinutes ?? 60);

    if (
      !Number.isInteger(parsedStart) ||
      parsedStart < 0 ||
      parsedStart > 23 ||
      !Number.isInteger(parsedEnd) ||
      parsedEnd < 0 ||
      parsedEnd > 23 ||
      parsedStart >= parsedEnd
    ) {
      res.status(400).json({ error: 'Daytime reminder window must have start hour < end hour (0–23).' });
      return;
    }

    if (!Number.isInteger(parsedInterval) || parsedInterval < 1 || parsedInterval > 240) {
      res.status(400).json({ error: 'Interval must be between 1 and 240 minutes.' });
      return;
    }

    db.prepare(
      `INSERT INTO user_reminder_settings (user_id, enabled, start_hour, end_hour, interval_minutes)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(user_id) DO UPDATE SET
         enabled = excluded.enabled,
         start_hour = excluded.start_hour,
         end_hour = excluded.end_hour,
         interval_minutes = excluded.interval_minutes`,
    ).run(authReq.auth!.userId, enabled ? 1 : 0, parsedStart, parsedEnd, parsedInterval);

    const updated = db
      .prepare(
        `SELECT enabled, start_hour as startHour, end_hour as endHour,
                interval_minutes as intervalMinutes, last_notified_at as lastNotifiedAt
         FROM user_reminder_settings WHERE user_id = ?`,
      )
      .get(authReq.auth!.userId);

    res.json({ settings: updated });
  });

  router.post('/reminders/notified', requireAuth, (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const forceTest = Boolean(req.body?.forceTest);

    const current = db
      .prepare(
        `SELECT interval_minutes as intervalMinutes, last_notified_at as lastNotifiedAt
         FROM user_reminder_settings WHERE user_id = ?`,
      )
      .get(authReq.auth!.userId) as
      | { intervalMinutes: number; lastNotifiedAt: string | null }
      | undefined;

    if (!forceTest && current?.lastNotifiedAt) {
      const elapsedMs = Date.now() - new Date(current.lastNotifiedAt).getTime();
      const intervalMs = current.intervalMinutes * 60 * 1000;
      if (elapsedMs < intervalMs) {
        res.status(429).json({
          suppressed: true,
          error: 'Notification already delivered within the current reminder interval.',
        });
        return;
      }
    }

    const nowUtc = new Date().toISOString();
    db.prepare(`UPDATE user_reminder_settings SET last_notified_at = ? WHERE user_id = ?`).run(
      nowUtc,
      authReq.auth!.userId,
    );

    res.json({ suppressed: false, lastNotifiedAt: nowUtc });
  });

  router.get('/qr/payload', requireAuth, (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const user = db.prepare(`SELECT id, name FROM users WHERE id = ?`).get(authReq.auth!.userId) as
      | { id: string; name: string }
      | undefined;
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    const origin = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
    const qrToken = crypto.createHash('sha256').update(`${user.id}:bottle500`).digest('hex').slice(0, 12);
    const qrUrl = `${origin.replace(/\/$/, '')}/qr?action=bottle500&uid=${encodeURIComponent(user.id)}&sig=${qrToken}`;

    res.json({
      qrUrl,
      userId: user.id,
      userName: user.name,
      presetMl: 500,
      signature: qrToken,
    });
  });

  router.post('/qr/scan-log', requireAuth, (req, res) => {
    const authReq = req as AuthenticatedRequest;
    const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(authReq.auth!.userId) as
      | UserRow
      | undefined;
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    const { scanNonce, scannedUserId } = req.body ?? {};
    if (scannedUserId && scannedUserId !== user.id) {
      res.status(403).json({ error: 'This bottle QR sticker belongs to another HydroHero account.' });
      return;
    }

    const nowMs = Date.now();
    const lastScan = recentQrScans.get(user.id) ?? 0;
    if (nowMs - lastScan < 10_000) {
      res.status(429).json({
        duplicatePrevented: true,
        error: 'Duplicate QR scan blocked. Please wait 10 seconds before scanning your bottle again.',
      });
      return;
    }

    const safeNonce =
      typeof scanNonce === 'string' && scanNonce.trim().length > 0 ? scanNonce.trim() : null;
    if (safeNonce) {
      const existing = db
        .prepare(`SELECT id FROM hydration_logs WHERE client_request_id = ?`)
        .get(`qr:${safeNonce}`);
      if (existing) {
        res.status(409).json({
          duplicatePrevented: true,
          error: 'This QR scan event has already been logged.',
        });
        return;
      }
    }

    recentQrScans.set(user.id, nowMs);

    const beforeLeaderboard = computeLeaderboard(db, authReq.timeZone);
    const previousRank = user.squad_id
      ? beforeLeaderboard.rankedTeams.find((t) => t.squadId === user.squad_id)?.rank ?? null
      : null;

    const logId = crypto.randomUUID();
    const nowUtc = new Date().toISOString();
    db.prepare(
      `INSERT INTO hydration_logs (id, user_id, amount_ml, drink_type, client_request_id, timestamp_utc)
       VALUES (?, ?, 500, 'qr_bottle', ?, ?)`,
    ).run(logId, user.id, safeNonce ? `qr:${safeNonce}` : null, nowUtc);

    const todayStats = getUserTodayStats(db, user, authReq.timeZone);
    const history = getUserStreakAndHistory(db, user, authReq.timeZone);
    const afterLeaderboard = computeLeaderboard(db, authReq.timeZone);
    const newTeam = user.squad_id
      ? afterLeaderboard.rankedTeams.find((t) => t.squadId === user.squad_id)
      : undefined;
    const newRank = newTeam?.rank ?? null;

    res.status(201).json({
      log: { id: logId, amountMl: 500, drinkType: 'qr_bottle', timestampUtc: nowUtc },
      todayStats,
      streak: { currentStreak: history.currentStreak, longestStreak: history.longestStreak },
      squad: user.squad_id ? getSquadDetails(db, user.squad_id, authReq.timeZone) : null,
      leaderboard: afterLeaderboard,
      rankTransition: {
        previousRank,
        newRank,
        improved: previousRank !== null && newRank !== null && newRank < previousRank,
        becameFirst: previousRank !== null && newRank === 1 && newRank < previousRank,
        teamName: newTeam?.teamName ?? null,
      },
    });
  });

  router.post('/demo/reset', (req, res) => {
    const authReq = req as AuthenticatedRequest;
    resetDemoEnvironment(db, authReq.timeZone);
    const rohan = db.prepare(`SELECT * FROM users WHERE email = ?`).get(DEMO_EMAIL) as UserRow;
    const token = signToken({ userId: rohan.id, email: rohan.email });
    const leaderboard = computeLeaderboard(db, authReq.timeZone);
    res.json({
      reset: true,
      token,
      user: sanitizeUser(rohan),
      leaderboard,
    });
  });

  return router;
}
