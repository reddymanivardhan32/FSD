import bcrypt from 'bcryptjs';
import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { normalizeTimezone } from '../utils/hydration';

const JWT_SECRET = process.env.JWT_SECRET || 'sipstreak-dev-secret-key-2026';

export interface AuthTokenPayload {
  userId: string;
  email: string;
}

export interface AuthenticatedRequest extends Request {
  auth?: AuthTokenPayload;
  timeZone: string;
}

export function hashPassword(password: string): string {
  return bcrypt.hashSync(password, 10);
}

export function verifyPassword(password: string, hash: string): boolean {
  return bcrypt.compareSync(password, hash);
}

export function signToken(payload: AuthTokenPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });
}

export function verifyToken(token: string): AuthTokenPayload {
  return jwt.verify(token, JWT_SECRET) as AuthTokenPayload;
}

export function attachTimezone(req: Request, _res: Response, next: NextFunction): void {
  const headerTz = req.headers['x-timezone'];
  const queryTz = typeof req.query.tz === 'string' ? req.query.tz : undefined;
  (req as AuthenticatedRequest).timeZone = normalizeTimezone(
    typeof headerTz === 'string' ? headerTz : queryTz,
  );
  next();
}

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required. Please sign in.' });
    return;
  }

  const token = authHeader.slice(7).trim();
  try {
    const payload = verifyToken(token);
    (req as AuthenticatedRequest).auth = payload;
    next();
  } catch {
    res.status(401).json({ error: 'Session expired or invalid token. Please sign in again.' });
  }
}
