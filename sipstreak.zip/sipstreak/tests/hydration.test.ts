import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { Server } from 'http';
import { AddressInfo } from 'net';
import fs from 'fs';
import path from 'path';
import { createApp } from '../server/app';
import { DEMO_EMAIL, DEMO_PASSWORD } from '../server/seed';
import {
  calculateCappedHydrationPct,
  calculateDailyGoalMl,
  calculateFairTeamScore,
  calculateStreak,
  computePlantState,
  getLocalDateString,
  utcIsoForLocalTime,
} from '../server/utils/hydration';

describe('SipStreak Domain Calculations', () => {
  it('calculates daily hydration target as WeightKg * 35 ml', () => {
    expect(calculateDailyGoalMl(60)).toBe(2100);
    expect(calculateDailyGoalMl(72)).toBe(2520);
  });

  it('caps primary hydration ring completion at 100%', () => {
    expect(calculateCappedHydrationPct(1850, 2100)).toBe(88);
    expect(calculateCappedHydrationPct(3000, 2100)).toBe(100);
  });

  it('caps individual member contributions at 100% in fair team scoring', () => {
    // 1 heavy drinker at 200% (4200/2100) + 3 members at 50% -> average = (1 + 0.5 + 0.5 + 0.5)/4 = 62.5% -> 63%
    const score = calculateFairTeamScore([
      { intakeMl: 4200, goalMl: 2100 },
      { intakeMl: 1050, goalMl: 2100 },
      { intakeMl: 1050, goalMl: 2100 },
      { intakeMl: 1050, goalMl: 2100 },
    ]);
    expect(score.memberContributions[0]).toBe(1);
    expect(score.rawScore).toBe(62.5);
    expect(score.roundedScore).toBe(63);
  });

  it('handles local midnight timezone boundaries accurately', () => {
    // 2026-11-20T04:10:00Z is 2026-11-19 20:10 in America/Los_Angeles (-08:00)
    const utc = '2026-11-20T04:10:00.000Z';
    expect(getLocalDateString(utc, 'UTC')).toBe('2026-11-20');
    expect(getLocalDateString(utc, 'America/Los_Angeles')).toBe('2026-11-19');
  });

  it('computes consecutive daily streaks from local calendar totals', () => {
    const ref = new Date('2026-11-19T18:00:00.000Z');
    const streak = calculateStreak(
      {
        '2026-11-16': 2100,
        '2026-11-17': 2200,
        '2026-11-18': 2100,
        '2026-11-19': 1350, // today still in progress
      },
      2100,
      'UTC',
      ref,
    );
    expect(streak.currentStreak).toBe(3);
    expect(streak.longestStreak).toBe(3);
  });

  it('updates plant growth stages based on real hydration metrics', () => {
    expect(
      computePlantState({
        todayPct: 0,
        streak: 0,
        recentAvgPct: 20,
        logsTodayCount: 0,
        localHour: 15,
      }).stage,
    ).toBe('wilting');

    expect(
      computePlantState({
        todayPct: 100,
        streak: 4,
        recentAvgPct: 90,
        logsTodayCount: 4,
        localHour: 16,
      }).stage,
    ).toBe('blooming');
  });
});

describe('SipStreak Full-Stack API & Hackathon Demo Scenarios', () => {
  const testDbPath = path.resolve(process.cwd(), 'data', 'test-sipstreak.db');
  let server: Server;
  let baseUrl = '';

  beforeAll(async () => {
    if (fs.existsSync(testDbPath)) {
      fs.unlinkSync(testDbPath);
    }
    const { app } = createApp({ dbPath: testDbPath });
    await new Promise<void>((resolve) => {
      server = app.listen(0, '127.0.0.1', () => {
        const addr = server.address() as AddressInfo;
        baseUrl = `http://127.0.0.1:${addr.port}`;
        resolve();
      });
    });
  });

  afterAll(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    if (fs.existsSync(testDbPath)) {
      fs.unlinkSync(testDbPath);
    }
  });

  async function api(route: string, options: RequestInit = {}, token?: string) {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'x-timezone': 'America/Los_Angeles',
      ...(options.headers as Record<string, string>),
    };
    if (token) headers.Authorization = `Bearer ${token}`;
    const res = await fetch(`${baseUrl}${route}`, { ...options, headers });
    const json = await res.json();
    return { status: res.status, json };
  }

  it('executes the exact Hackathon Demonstration: 72% (#2) -> +500ml -> 88% personal, 78% team (#1)', async () => {
    // 1. Demo login as Rohan Verma (Hostel Block B)
    const loginRes = await api('/api/auth/demo-login', {
      method: 'POST',
      body: JSON.stringify({ email: DEMO_EMAIL }),
    });
    expect(loginRes.status).toBe(200);
    const rohanToken = loginRes.json.token as string;
    expect(loginRes.json.user.dailyGoalMl).toBe(2100);

    // 2. Verify initial leaderboard state
    const lbBefore = await api('/api/squads/leaderboard', {}, rohanToken);
    expect(lbBefore.status).toBe(200);
    const rankedBefore = lbBefore.json.rankedTeams;
    expect(rankedBefore[0].teamName).toBe('Hostel Block A');
    expect(rankedBefore[0].teamScore).toBe(75);
    expect(rankedBefore[1].teamName).toBe('Hostel Block B');
    expect(rankedBefore[1].teamScore).toBe(72);

    // 3. Log +500 ml Water Bottle
    const logRes = await api(
      '/api/hydration/log',
      {
        method: 'POST',
        body: JSON.stringify({
          amountMl: 500,
          drinkType: 'bottle',
          clientRequestId: 'demo-test-req-1',
        }),
      },
      rohanToken,
    );
    expect(logRes.status).toBe(201);
    expect(logRes.json.todayStats.completionPct).toBe(88);
    expect(logRes.json.squad.teamScore).toBe(78);
    expect(logRes.json.rankTransition.previousRank).toBe(2);
    expect(logRes.json.rankTransition.newRank).toBe(1);
    expect(logRes.json.rankTransition.becameFirst).toBe(true);
    expect(logRes.json.leaderboard.rankedTeams[0].teamName).toBe('Hostel Block B');

    // 4. Duplicate clientRequestId prevention
    const dupRes = await api(
      '/api/hydration/log',
      {
        method: 'POST',
        body: JSON.stringify({
          amountMl: 500,
          drinkType: 'bottle',
          clientRequestId: 'demo-test-req-1',
        }),
      },
      rohanToken,
    );
    expect(dupRes.status).toBe(200);
    expect(dupRes.json.duplicatePrevented).toBe(true);
    expect(dupRes.json.todayStats.completionPct).toBe(88);
  });

  it('enforces auth, ownership protection, caffeine offset, custom validation, and 4-8 squad limits', async () => {
    // Unauthenticated blocked
    const unauth = await api('/api/hydration/dashboard');
    expect(unauth.status).toBe(401);

    // Register new user
    const reg = await api('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({
        name: 'Test Student',
        email: 'student.test@sipstreak.edu',
        password: DEMO_PASSWORD,
        weightKg: 70,
      }),
    });
    expect(reg.status).toBe(201);
    expect(reg.json.user.dailyGoalMl).toBe(2450);
    const studentToken = reg.json.token as string;

    // Invalid custom amount rejected
    const badCustom = await api(
      '/api/hydration/log',
      { method: 'POST', body: JSON.stringify({ amountMl: 9999, drinkType: 'custom' }) },
      studentToken,
    );
    expect(badCustom.status).toBe(400);

    // Caffeine adds +200 ml compensatory target without counting as water
    const caf = await api(
      '/api/hydration/caffeine',
      { method: 'POST', body: JSON.stringify({ beverageType: 'coffee' }) },
      studentToken,
    );
    expect(caf.status).toBe(201);
    expect(caf.json.todayStats.caffeineOffsetMl).toBe(200);
    expect(caf.json.todayStats.adjustedGoalMl).toBe(2650);
    expect(caf.json.todayStats.totalIntakeMl).toBe(0);

    // Create new squad (<4 members -> forming, not ranked)
    const sq = await api(
      '/api/squads/create',
      { method: 'POST', body: JSON.stringify({ teamName: 'Test Lab Squad' }) },
      studentToken,
    );
    expect(sq.status).toBe(201);
    expect(sq.json.squad.qualifiesForRanking).toBe(false);
    expect(sq.json.squad.rank).toBeNull();

    // Prevent joining invalid invite code
    const badJoin = await api(
      '/api/squads/join',
      { method: 'POST', body: JSON.stringify({ inviteCode: 'NOPE99' }) },
      studentToken,
    );
    expect(badJoin.status).toBe(404);

    // Join existing squad (HBLB26 has 4 members -> now 5) and test 8-member cap
    const joinRes = await api(
      '/api/squads/join',
      { method: 'POST', body: JSON.stringify({ inviteCode: 'HBLB26' }) },
      studentToken,
    );
    expect(joinRes.status).toBe(200);
    expect(joinRes.json.squad.memberCount).toBe(5);

    // Fill HBLB26 to 8 and verify 9th is rejected with 409
    for (let i = 6; i <= 8; i++) {
      const extra = await api('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({
          name: `Extra Member ${i}`,
          email: `extra${i}@sipstreak.edu`,
          password: DEMO_PASSWORD,
          weightKg: 60,
          inviteCode: 'HBLB26',
        }),
      });
      expect(extra.status).toBe(201);
    }

    const overflow = await api('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({
        name: 'Member Nine',
        email: 'member9@sipstreak.edu',
        password: DEMO_PASSWORD,
        weightKg: 60,
        inviteCode: 'HBLB26',
      }),
    });
    expect(overflow.status).toBe(409);

    // QR scan logging + duplicate cooldown protection
    const qr1 = await api(
      '/api/qr/scan-log',
      { method: 'POST', body: JSON.stringify({ scanNonce: 'qr-unit-1' }) },
      studentToken,
    );
    expect(qr1.status).toBe(201);
    expect(qr1.json.log.amountMl).toBe(500);

    const qrDup = await api(
      '/api/qr/scan-log',
      { method: 'POST', body: JSON.stringify({ scanNonce: 'qr-unit-2' }) },
      studentToken,
    );
    expect(qrDup.status).toBe(429);

    // Prevent deleting another user's log
    const rohanLogin = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: DEMO_EMAIL, password: DEMO_PASSWORD }),
    });
    const rohanDash = await api('/api/hydration/dashboard', {}, rohanLogin.json.token);
    const rohanLogId = rohanDash.json.todayStats.todayLogs[0].id;

    const forbiddenDelete = await api(
      `/api/hydration/log/${rohanLogId}`,
      { method: 'DELETE' },
      studentToken,
    );
    expect(forbiddenDelete.status).toBe(403);

    // Verify sample campus fountains endpoint
    const fountains = await api('/api/fountains?waterType=chilled_filtered');
    expect(fountains.status).toBe(200);
    expect(fountains.json.fountains.length).toBeGreaterThan(0);

    // Ensure timestamp helper produces valid UTC ISO strings
    expect(utcIsoForLocalTime('2026-11-19', 9, 15, 'America/Los_Angeles')).toMatch(/Z$/);
  });
});
