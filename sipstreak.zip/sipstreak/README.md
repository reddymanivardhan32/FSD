# SipStreak — HydroHero Hunt

Collaborative team hydration challenge web application built with React, TypeScript, Tailwind CSS, Express, SQLite, Chart.js, Leaflet, and QR bottle logging.

## Key Features

- **Quick-Tap Water Logging**: One-tap `+250 ml Cup`, `+500 ml Water Bottle`, `+750 ml Tumbler`, and validated custom amount logging with duplicate-click protection.
- **Personal Hydration Ring & Goal Engine**: Calculates daily hydration estimates via `TargetMl = WeightKg × 35 ml`, paired with an animated SVG water bottle (CSS wave translations + ripple animation) and a completion ring capped at 100%.
- **Hydration Squads (4–8 Members)**: Create squads, join with unique invite codes, inspect member progress, and enforce 4–8 member challenge rules.
- **Fair-Participation Team Leaderboard**:
  - `MemberContribution = min(Member_Intake / Member_Goal, 1)`
  - `TeamScore = (sum(MemberContribution) / Team_Size) × 100`
  - Prevents a single heavy drinker from carrying an entire squad; triggers an animated podium celebration when your squad climbs in rank.
- **7-Day Personal & Team History**: Interactive Chart.js bar charts with Personal/Team switching, local calendar day alignment, and streak tracking.
- **Hourly Hydration Nudge Simulator**: Daytime-window reminder configuration with Browser Notification API integration and automatic in-app toast fallback.
- **Virtual Plant Companion**: 5-stage reactive SVG plant driven by real daily intake, streak consistency, and time of day.
- **Caffeine Dehydration Offset Calculator**: Logs coffee and energy drinks with `+200 ml` compensatory water demand while keeping plain water intake separate.
- **Campus Water Fountain Map**: Interactive Leaflet map with search, water-type filtering, and sample campus refill stations.
- **Water Bottle QR Sticker & Scanner**: Printable `+500 ml` bottle sticker generator (`qrcode`) and camera/image QR scanner (`jsQR`) with authentication and duplicate-scan cooldown protection.

## Project Structure

```
├── server.ts                  # Express + Vite full-stack server entrypoint (port 3000)
├── server/
│   ├── app.ts                 # Express app factory
│   ├── db.ts                  # SQLite schema & indexes (better-sqlite3)
│   ├── seed.ts                # Deterministic 4-team / 16-member / 7-day seed & demo reset
│   ├── middleware/auth.ts     # JWT auth & timezone header extraction
│   ├── routes/                # auth, hydration, squads, features REST endpoints
│   ├── services/metrics.ts    # Leaderboard, streaks, plant, & dashboard aggregations
│   └── utils/hydration.ts     # Pure domain math & timezone conversion helpers
├── src/
│   ├── components/            # AppShell, WaterBottleGraphic, HydrationRing, PlantIllustration, PodiumCelebration
│   ├── context/               # AuthContext, ToastContext & Nudge Simulator
│   ├── lib/api.ts             # Typed API client
│   ├── pages/                 # Landing, Auth, Dashboard, Squad, Leaderboard, History, Plant, Map, QR, Profile
│   └── types/index.ts         # Shared TypeScript interfaces
└── tests/hydration.test.ts    # Vitest domain & API integration test suite
```

## Setup & Startup

1. Copy `.env.example` to `.env` if customizing configuration (`PORT=3000`, `JWT_SECRET`, `DB_PATH`).
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start development server (Express API + Vite frontend on port 3000):
   ```bash
   npm run dev
   ```
4. Build & run in production:
   ```bash
   npm run build
   NODE_ENV=production npm start
   ```
5. Run automated test suite and typecheck:
   ```bash
   npm test
   npm run lint
   ```

## Demo Login Credentials

- **Presenter Demo Account (Hostel Block B)**: `rohan@sipstreak.edu` / `HydroHero2026!`
- **Hostel Block A**: `aarav@sipstreak.edu` / `HydroHero2026!`
- **Aqua Knights**: `vikram@sipstreak.edu` / `HydroHero2026!`
- **Hydration Homies**: `arjun@sipstreak.edu` / `HydroHero2026!`

## Hackathon Demonstration Walkthrough

1. Click **Launch Hostel Block B Demo** on the landing page (or sign in as `rohan@sipstreak.edu`).
2. On the **Hydration Squad Dashboard**, verify:
   - Team Rank: **#2**
   - Team Score: **72%** (behind Hostel Block A at **75%**)
   - Rohan's Personal Progress: **64%** (`1,350 / 2,100 ml`)
3. Click **+500 ml Water Bottle**.
4. Observe the bottle ripple animation, personal completion jumping to **88%** (`1,850 / 2,100 ml`), team score increasing from **72% to 78%**, **Hostel Block B** overtaking **Hostel Block A** into **1st place**, and the animated podium celebration modal appearing.
5. Use **Reset Demo State** on the Leaderboard or Profile page to replay the demonstration anytime.

## REST API Overview

- `POST /api/auth/register` · `POST /api/auth/login` · `POST /api/auth/demo-login` · `GET /api/auth/me` · `PATCH /api/auth/profile`
- `GET /api/hydration/dashboard` · `POST /api/hydration/log` · `DELETE /api/hydration/log/:id` · `POST /api/hydration/caffeine` · `DELETE /api/hydration/caffeine/:id` · `GET /api/hydration/history`
- `GET /api/squads/leaderboard` · `GET /api/squads/mine` · `POST /api/squads/create` · `POST /api/squads/join` · `POST /api/squads/leave`
- `GET /api/fountains` · `GET /api/plant` · `GET /api/reminders` · `PUT /api/reminders` · `POST /api/reminders/notified` · `GET /api/qr/payload` · `POST /api/qr/scan-log` · `POST /api/demo/reset`
